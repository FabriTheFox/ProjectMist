#pragma once

#include "System.h"
#include <unordered_map>
#include "Layer.h"

class Renderable;

class GraphicSystem : public System 
{
	RTTI_DECLARATION(GraphicSystem)
	friend class Renderable;
	friend class RayTracerSystem;

public:
	void Initialize() override;
	void Update() override;
	void ShowDebug() override;
	void Shutdown() override;

	void CreateLayer(const std::string& name);
	Layer& GetLayer(const std::string name);

private:
	void ShowGUIWindow(bool& open);

	void RenderAllLayers();
	std::vector<Layer> mLayers;
};