#pragma once

void initCam();
void initSurface(int texId, ANativeWindow* window);