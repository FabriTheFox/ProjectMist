#pragma once

#include <unordered_map>
#include "FoxTracerEngine.h"

#include "ImGUIHeaders.h"

class IProperty;
using PropertyList = std::unordered_map<std::string, std::unordered_map<std::string, SHD_PTR<IProperty>>>;

class IProperty
{
public:
	std::string mName;
	std::string mClassName;
	size_t mClassType;

	virtual void Set(SerData& data, void* inst) { (void)(data); (void)(inst); }
	virtual void* GetPtr(void* inst) { (void)(inst); return nullptr; }
	virtual void ShowGUI(PropertyList& pl, void* inst) { UNUSED_PARAM(pl); UNUSED_PARAM(inst); }
};

template <typename T, typename S>
class Property : public IProperty
{
public:
	Property(S T::* pdata) : mProperty(pdata) {}

	void Set(SerData& data, void* inst) override
	{
		S* Val = (S*)&data.GetData<S>();
		T* Instance = (T*)inst;
		(*Instance).*mProperty = *Val;
	}

	void* GetPtr(void* inst) override
	{
		T* Instance = (T*)inst;
		return &((*Instance).*mProperty);
	}

	void ShowGUI(PropertyList& pl, void* inst) override
	{ 
		ShowGUI<S>(pl, inst);
	}

	S T::* mProperty;

private:
	template <typename T>
	void ShowGUI(PropertyList& pl, void* inst)
	{
		auto& parent = pl[mClassName];

		if (parent.empty())
			ImGui::Text("Property GUI not implemented.");

		for (auto& pr : parent)
		{
			if (ImGui::TreeNode(pr.second->mName.c_str()))
			{
				pr.second->ShowGUI(pl, GetPtr(inst));
				ImGui::TreePop();
			}
		}
	}

	template <> void ShowGUI<int>(PropertyList& pl, void* inst)
	{
		UNUSED_PARAM(pl);
	}

	template <> void ShowGUI<float>(PropertyList& pl, void* inst)
	{
		UNUSED_PARAM(pl);
		float* f = (float*)GetPtr(inst);
		ImGui::PushID((int)(this));
		ImGui::DragFloat(Utilities::AppendID(mName, (int)this).c_str(), f, 1.f);
		ImGui::PopID();
	}

	template <> void ShowGUI<Vec3>(PropertyList& pl, void* inst)
	{
		UNUSED_PARAM(pl);
		Vec3* f = (Vec3*)GetPtr(inst);
		ImGui::PushID((int)(this));
		ImGui::DragFloat3(Utilities::AppendID(mName, (int)this).c_str(), &f->x, 1.f);
		ImGui::PopID();
	}
};