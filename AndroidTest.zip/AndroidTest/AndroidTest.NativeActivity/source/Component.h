#pragma once

#include "DataTypes.h"
#include "RTTI.h"		
#include "Transform.h"
#include "Entity.h"

class Component : public Base
{
public:
	friend class Entity;

	Entity& GetOwner() { return *mpOwner.lock(); }
	Transform& GetTransform() { return mpOwner.lock()->mTransform; };

	virtual void AddToSystem() {}
	virtual void RemoveFromSystem() {}

private:
	WK_PTR<Entity> mpOwner;
};