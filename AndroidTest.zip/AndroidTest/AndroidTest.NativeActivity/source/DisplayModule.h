#pragma once

#include "DataTypes.h"

class DisplayModule
{
public:
	enum WINDOW_MODE
	{
		WINDOWED,
		FULLSCREEN,
		FULL_WINDOWED
	};

	DisplayModule();
	~DisplayModule();

	void Initialize(const IVec2& opengl_version = {4, 5});
	void Terminate();

	void SwapWindow();

	void SetWindowSize(const IVec2& size);
	const IVec2& GetWindowSize();

	void SetWindowPos(const IVec2& pos);
	const IVec2& GetWindowPos();
	void CenterWindow();

	const WINDOW_MODE& GetWindowMode() const;
	void SetWindowMode(WINDOW_MODE mode);

	bool GetWindowBordered();
	void SetWindowBordered(bool bordered);

	float GetWindowAspectRatio();
	IVec2 GetDesktopResolution();

	void SetDeveloperFullScreen();
	void SetDeveloperWindowed();

	void* GetWindow();

private:
	IVec2 CheckDesktopResolution();
	void InitializeImGUI();

	void* mpWindow{nullptr};
	void* mpGL_context{ nullptr };

	IVec2 mDesktopResolution{ 800, 600 };
	IVec2 mWindowSize{800, 600};
	IVec2 mWindosPos{ 0, 0 };
	WINDOW_MODE mWindowMode{ WINDOWED };
	bool mBordered{ true };
};

void InitializeGL3W();