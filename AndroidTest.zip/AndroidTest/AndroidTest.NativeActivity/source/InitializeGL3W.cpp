#include "DisplayModule.h"
#include "imgui/gl3w.h"

void InitializeGL3W()
{
	gl3wInit();
}