#include "FTEQuaternion.h"
#include "Utilities.h"

namespace FTE_Quat
{
	FTEQuat::FTEQuat(const Vector3& v)
	{
		// Convert euler rotation vector to matrix
		// By using the formula
		auto r = glm::radians(v);
		Vec3 c = glm::cos(r * 0.5f);
		Vec3 s = glm::sin(r * 0.5f);
		x = (s.x * c.y * c.z) - (c.x * s.y * s.z);
		y = (c.x * s.y * c.z) + (s.x * c.y * s.z);
		z = (c.x * c.y * s.z) - (s.x * s.y * c.z);
		w = (c.x * c.y * c.z) + (s.x * s.y * s.z);
	}

	Vector3 FTEQuat::GetEuler()
	{
		Vec3 euler;
		float y2 = y * y;

		float t0 = 2.f * (w * x + y * z);
		float t1 = 1.f - 2.f * (x * x + y2);
		euler.x = glm::degrees(glm::atan(t0, t1));

		float t2 = 2.f * (w * y - z * x);
		t2 = t2 > 1.f ? 1.f : t2;
		t2 = t2 < -1.f ? -1.f : t2;
		euler.y = glm::degrees(glm::asin(t2));

		float t3 = 2.f * (w * z + x * y);
		float t4 = 1.f - 2.f * (y2 + z * z);

		euler.z = glm::degrees(glm::atan(t3, t4));
		return euler;
	}

	FTEQuat& FTEQuat::Normalize()
	{
		// quat = quat / length 

		Vec4 v(x, y, z, w);
		// Just call glm::normalize() on a vector4
		auto n = glm::normalize(v);
		x = n.x;
		y = n.y;
		z = n.z;
		w = n.w;
		return *this;
	}

	FTEQuat FTEQuat::Conjugate() const { return FTEQuat(-x, -y, -z, w); }
	FTEQuat FTEQuat::Inverse() const { return Conjugate() * (1.f / Dot(*this, *this)); }

	Mat4 FTEQuat::GetRotationMatrix() const
	{
		// Apply the formula to get the rotation matrix of this quat
		Mat4 m;
		m[0][0] = 1 - (2 * y*y) - (2 * z*z);
		m[0][1] = (2 * x*y) + (2 * z*w);
		m[0][2] = (2 * x*z) - (2 * y*w);

		m[1][0] = (2 * x*y) - (2 * z*w);
		m[1][1] = 1 - (2 * x*x) - (2 * z*z);
		m[1][2] = (2 * y*z) + (2 * x*w);

		m[2][0] = (2 * x*z) + (2 * y*w);
		m[2][1] = (2 * y*z) - (2 * x*w);
		m[2][2] = 1 - (2 * x*x) - (2 * y*y);
		return m;
	}

	FTEQuat& FTEQuat::operator*= (const FTEQuat& r)
	{
		// Multiplication formula
		FTEQuat c(*this);
		x = c.w * r.x + c.x * r.w + c.y * r.z - c.z * r.y;
		y = c.w * r.y + c.y * r.w + c.z * r.x - c.x * r.z;
		z = c.w * r.z + c.z * r.w + c.x * r.y - c.y * r.x;
		w = c.w * r.w - c.x * r.x - c.y * r.y - c.z * r.z;
		return *this;
	}

	FTEQuat& FTEQuat::operator*= (const float& rhs)
	{
		x *= rhs;
		y *= rhs;
		z *= rhs;
		w *= rhs;
		return *this;
	}

	FTEQuat& FTEQuat::operator-= (const FTEQuat& rhs)
	{
		x -= rhs.x;
		y -= rhs.y;
		z -= rhs.z;
		w -= rhs.w;
		return *this;
	}

	FTEQuat& FTEQuat::operator+= (const FTEQuat& rhs)
	{
		x += rhs.x;
		y += rhs.y;
		z += rhs.z;
		w += rhs.w;
		return *this;
	}

	// This operators just call the member operators of FTEQuat
	FTEQuat operator* (const FTEQuat& lhs, const FTEQuat& rhs) { return FTEQuat(lhs) *= rhs; }
	FTEQuat operator* (const FTEQuat& lhs, const float& rhs) { return FTEQuat(lhs) *= rhs; }
	FTEQuat operator* (const float& lhs, const FTEQuat& rhs) { return FTEQuat(rhs) *= lhs; }
	FTEQuat operator- (const FTEQuat& lhs, const FTEQuat& rhs) { return FTEQuat(lhs) -= rhs; }
	FTEQuat operator+ (const FTEQuat& lhs, const FTEQuat& rhs) { return FTEQuat(lhs) += rhs; }
	
	float Dot(const FTEQuat& l, const FTEQuat& r) { return (l.x * r.x) + (l.y * r.y) + (l.z * r.z) + (l.w * r.w); }

	Vector3 operator* (const FTEQuat& lhs, const Vector3& rhs)
	{	
		// Multiply a vector by the rotation mtx representing this quaternion
		Mat3 m = Mat3(lhs.GetRotationMatrix());
		return m * rhs;
	}

	Vector3 operator* (const Vector3& lhs, const FTEQuat& rhs)
	{
		return rhs.Inverse() * lhs;
	}

	FTEQuat Slerp(FTEQuat q0, FTEQuat q1, float t)
	{
		// Cosine of the angle between the quats
		float dot = Dot(q0, q1);

		// Make sure the interpolation goes the short way
		if (dot < 0.0f) 
		{
			q1 *= -1;
			dot = -dot;
		}
		
		// If the rotations are very close, linearly interpolate, 
		// otherwise float values start spiking and mess the rotations
		if (dot > 1.f - glm::epsilon<float>())
		{
			return FTEQuat{ 
				Utilities::LERP(q0.x, q1.x, t),
				Utilities::LERP(q0.y, q1.y, t),
				Utilities::LERP(q0.z, q1.z, t),
				Utilities::LERP(q0.w, q1.w, t) };
		}

		// Make sure acos returns an actual value
		dot = glm::clamp(dot, -1.f, 1.f);

		// Angle between input vectors
		float th0 = glm::acos(dot);
		return (glm::sin((1 - t) * th0) * q0 + glm::sin(t * th0) * q1) * (1.f / glm::sin(th0));
	}
}



