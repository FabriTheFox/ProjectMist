#include "RT_PhotonMap.h"
#include "PointKDTree.h"
#include "RenderJob.h"
#include <glm/gtc/constants.hpp>

std::mutex RT_PhotonMap::mMutex;

typedef PointKDTree<RT_PhotonMap::PhotonData> photonmap;
typedef std::vector<PointKDTree<RT_PhotonMap::PhotonData>::KDTData> photonvec;

void RT_PhotonMap::Initialize()
{
	mMaxDistance = mRenderJob->mConfig.GetValue<float>("photon_radius");
	mSQmaxDistance = mMaxDistance * mMaxDistance;
	mArea = glm::pi<float>() * mSQmaxDistance;
}

RT_PhotonMap::RT_PhotonMap()
{
	mPhotonMap = new photonmap;
	mPhotonVec = new photonvec;
}

RT_PhotonMap::~RT_PhotonMap()
{
	delete mPhotonMap;
	delete mPhotonVec;
}

void RT_PhotonMap::AddPhoton(const Vec3& pos, const PhotonData& data)
{
	auto& res = mRenderJob->mResolution;
	auto& tex = mRenderJob->mTexelArray;
	IVec2 i_pos = Utilities::WorldToScreenCoords(pos, mRenderJob->mWorldToScreen, mRenderJob->mResolution);

	mMutex.lock();
	((photonvec*)mPhotonVec)->push_back({ {pos}, {data} });

	unsigned off = ((i_pos.y * res.x) + i_pos.x) * 4;
	if (off >= 0 && off < tex.size())
	{
		tex[off + 0] = (unsigned char)(data.mColor.x * 255);
		tex[off + 1] = (unsigned char)(data.mColor.y * 255);
		tex[off + 2] = (unsigned char)(data.mColor.z * 255);
		tex[off + 3] = (unsigned char)(1 * 255);
	}

	mMutex.unlock();
}

void RT_PhotonMap::Launch(RenderJob* renderjob)
{
	mRenderJob = renderjob;

	Initialize();
	TracePhotons();
	BuildKDTree();

	mStatus = PM_FINISHED;
}

RT_PhotonMap::PhotonData RT_PhotonMap::GetValueAt(const Vec3& pos, const Vec3& normal)
{
	auto nearest = ((photonmap*)mPhotonMap)->GetNearData(pos);
	
	PhotonData data;
	
	if (nearest.empty())
		return data;

	for (auto& n : nearest)
	{
		float dot = glm::max(glm::dot(normal, n.mData.mNormal), 0.f);
		data.mColor += ((n.mData.mColor * dot) / mArea);
	}
	
	data.mColor.x = glm::min(data.mColor.x, 1.f);
	data.mColor.y = glm::min(data.mColor.y, 1.f);
	data.mColor.z = glm::min(data.mColor.z, 1.f);

	return data;
}

void RT_PhotonMap::TracePhotons()
{
	mStatus = PM_TRACING_PHOTONS;

	RT_Renderer::RenderData data;
	data.mBounces = mRenderJob->mConfig.GetValue<unsigned>("photon_bounces");
	for (auto& l : mRenderJob->mRTLayer.mLights)
		l.EmitPhotons(mRenderJob->mRTLayer.mPhotonMap, data, mRenderJob->mConfig.GetValue<unsigned>("photons_per_light"), mRenderJob->mConfig.GetValue<unsigned>("photon_intensity"));
}

void RT_PhotonMap::BuildKDTree()
{
	mStatus = PM_BUILDING_KDTREE;

	((photonmap*)mPhotonMap)->GetIntersectionCost() = 1.f;
	((photonmap*)mPhotonMap)->GetTraverseCost() = 0.5f;
	((photonmap*)mPhotonMap)->GetMaxRadius() = mMaxDistance;
	((photonmap*)mPhotonMap)->BuildKDTree(*((photonvec*)mPhotonVec), 15);
}

float RT_PhotonMap::GetRadius() { return mMaxDistance; }
float RT_PhotonMap::GetArea() { return mArea; }
unsigned RT_PhotonMap::GetLevels() { return ((photonmap*)mPhotonMap)->GetLevel(); }
unsigned RT_PhotonMap::GetPhotonNum() { return ((photonmap*)mPhotonMap)->GetElementNum(); }
Utilities::Timer& RT_PhotonMap::GetTimer() { return mTimer; }