#pragma once

#include "EntitySystem.h"
#include "Property.h"
#include <fstream>

class Serializer
{
public:
	Serializer();
	Serializer& operator=(const Serializer&) = delete;

	void SaveScene(const std::string& name);
	void SaveConfigFile();

private:
	void RegisterBasicTypes();
	template <typename T>
	void RegisterBasicType() { mBasicTypes[typeid(T).hash_code()] = typeid(T).name(); }

	void WriteEntity(std::ofstream& file, SHD_PTR<Entity> entity);
	void WriteComponent(std::ofstream& file, RTTI& type, SHD_PTR<Entity> entity, unsigned tabs);
	void WriteProperty(std::ofstream& file, void* parent, SHD_PTR<IProperty> prop, unsigned tabs);

	bool WriteBasic(size_t type, std::string& str, void* data);
	void WriteVector(std::string& str, std::vector<float>& f);
	void WriteVectorInt(std::string& str, std::vector<int>& f);
	void WriteTabs(std::string& str, unsigned num);

	std::unordered_map<std::string, std::unordered_map<std::string, SHD_PTR<IProperty>>>& mProperties;
	std::unordered_map<size_t, std::string> mBasicTypes;
};