#include "Deserializer.h"
#include "SceneSystem.h"
#include "FoxTracerEngine.h"
#include "Entity.h"
#include "Component.h"
#include "FTESystems.h"

Deserializer::Deserializer() : mProperties(SceneSystem::GetProperties()) { RegisterBasicTypes(); }

void Deserializer::LoadConfigFile()
{
	std::ifstream file("config.cfg");
	std::string line;

	if (file.is_open())
	{
		SystemConfig* pcfg = nullptr;
		while (getline(file, line))
		{
			RemoveTabsAndSpaces(line);

			if (line == "")
				continue;

			if (line == "RayTracer:")
			{
				pcfg = &FoxTracerEngine::GetSystem<RayTracerSystem>().GetConfiguration();
				continue;
			}

			size_t eq = line.find_first_of('=');
			std::string name = line.substr(0, eq);
			std::string data = line.substr(eq + 1, std::string::npos);

			SerData d;
			if (LoadBasic(pcfg->mVariables.at(name).mType, data, d))
			{
				pcfg->mVariables.at(name).mData = d.mData;
				d.mAllocated = false;
			}
		}

		file.close();
	}
}

void Deserializer::LoadLevel(const std::string& level)
{
	std::ifstream file(level);
	std::string line;

	if (file.is_open())
	{
		InternalLoad(file);
		file.close();
	}
}

void Deserializer::RegisterBasicTypes()
{
	RegisterBasicType<int>();
	RegisterBasicType<float>();
	RegisterBasicType<unsigned>();
	RegisterBasicType<double>();
	RegisterBasicType<bool>();
	RegisterBasicType<std::string>();
	RegisterBasicType<IVec2>();
	RegisterBasicType<Vec3>();
	RegisterBasicType<Vec4>();
	RegisterBasicType<std::vector<float>>();
}

void Deserializer::InternalLoad(std::ifstream& file)
{
	std::string line;
	while (getline(file, line))
	{
		RemoveTabsAndCornerSpaces(line);

		if (mProperties.find(line) != mProperties.end())
		{
			auto parent = FoxTracerEngine::GetRTTIs().at(line).mCreateFun();
			LoadProperties(file, mProperties.at(line), parent.get());
		}
	}
}

void Deserializer::LoadProperties(std::ifstream& file, std::unordered_map<std::string, SHD_PTR<IProperty>>& parent_prop, void* parent)
{
	std::string line;
	SerDataPack datapack;

	while (getline(file, line))
	{
		RemoveTabsAndSpaces(line);

		if (line == "}")
			break;

		if (line == "" || line == "{")
			continue;

		if (line == ":Components:")
		{
			LoadComponents(file, parent);
			continue;
		}

		size_t eq = line.find_first_of('=');
		std::string name = line.substr(0, eq);
		std::string data = line.substr(eq + 1, std::string::npos);

		auto& property = parent_prop[name];
		auto type_hash = property->mClassType;

		SerData& dd = datapack.GetData(name);
		if (!LoadBasic(type_hash, data, dd))
		{
			dd.mData = property->GetPtr(parent);
			LoadProperties(file, mProperties[property->mClassName], dd.mData);
		}

		property->Set(dd, parent);
	}

	((Base*)parent)->Load(datapack);
}

void Deserializer::LoadComponents(std::ifstream& file, void* parent)
{
	std::string line;
	while (getline(file, line))
	{
		RemoveTabsAndCornerSpaces(line);

		if (line == "}")
			return;

		if (line == "" || line == "{")
			continue;

		auto& rttis = FoxTracerEngine::GetRTTIs();
		auto rtti = rttis.find(line);

		if (rtti != rttis.end())
		{
			auto comp = SHD_CAST(Component)(rtti->second.mCreateFun());
			auto prop = mProperties.find(line);
			if (prop != mProperties.end())
				LoadProperties(file, prop->second, comp.get());
			else
			{
				while (getline(file, line)) { 
					RemoveTabsAndCornerSpaces(line); 
					if (line == "}")
						break;
				}

			}
			((Entity*)(parent))->AddComponent(comp);
		}
	}
}

bool Deserializer::LoadBasic(size_t hash, const std::string& data, SerData& d)
{
	auto itr = mBasicTypes.find(hash);
	if (itr == mBasicTypes.end())
		return false;

	std::vector<float> f;
	if (hash == typeid(int).hash_code())
	{
		d.SetData<int>(std::stoi(data));
	}
	else if (hash == typeid(std::string).hash_code())
	{
		d.SetData<std::string>(data);
	}
	else if (hash == typeid(float).hash_code())
	{
		d.SetData<float>(std::stof(data));
	}
	else if (hash == typeid(unsigned).hash_code())
	{
		d.SetData<unsigned>(std::stoi(data));
	}
	else if (hash == typeid(double).hash_code())
	{
		d.SetData<double>(std::stod(data));
	}
	else if (hash == typeid(bool).hash_code())
	{
		if (data == "false")
			d.SetData<bool>(false);
		else
			d.SetData<bool>(true);
	}
	else if (hash == typeid(IVec2).hash_code())
	{
		ReadVector(data, f);
		IVec2 v{ f[0], f[1]};
		d.SetData<IVec2>(v);
	}
	else if (hash == typeid(Vec3).hash_code())
	{
		ReadVector(data, f);
		Vec3 v{ f[0], f[1], f[2] };
		d.SetData<Vec3>(v);
	}
	else if (hash == typeid(Vec4).hash_code())
	{
		ReadVector(data, f);
		Vec4 v{ f[0], f[1], f[2], f[3] };
		d.SetData<Vec4>(v);
	}
	else if (hash == typeid(std::vector<float>).hash_code())
	{
		ReadVector(data, f);
		d.SetData<std::vector<float>>(f);
	}
	return true;
}

void Deserializer::RemoveTabsAndSpaces(std::string& str)
{
	std::string clean;
	for (unsigned i = 0; i < str.size(); ++i)
	{
		if (str[i] != '\t' && str[i] != ' ' && str[i] != '\"')
			clean += str[i];
	}
	str = clean;

	if (str[0] == '/' && str[1] == '/')
		str.clear();
}

void Deserializer::RemoveTabsAndCornerSpaces(std::string& str)
{
	std::string clean;
	bool removespaces = true;
	for (unsigned i = 0; i < str.size(); ++i)
	{
		if (str[i] > 'A' && str[i] < 'z')
			removespaces = false;
		if (str[i] != '\t' && (!removespaces || str[i] != ' ' ))
			clean += str[i];
	}

	str.clear();
	removespaces = true;
	for (int i = (int)clean.size() - 1; i >= 0 ; --i)
	{
		if (clean[i] > 'A' && clean[i] < 'z')
			removespaces = false;
		if (clean[i] != '\t' && (!removespaces || clean[i] != ' '))
			str += clean[i];
	}

	for (unsigned i = 0; i < str.size() / 2; ++i)
	{
		char t = str[i];
		str[i] = str[str.size() - 1 - i];
		str[str.size() - 1 - i] = t;
	}

	if (str[0] == '/' && str[1] == '/')
		str.clear();
}

void Deserializer::ReadVector(const std::string& line, std::vector<float>& vec)
{
	std::string temp;
	for (unsigned i = 0; i < line.size(); ++i)
	{
		if (line[i] == '[')
			continue;

		if (line[i] == ',' || line[i] == ']')
		{
			vec.push_back(std::stof(temp));
			temp.clear();
			continue;
		}

		temp += line[i];
	}
}