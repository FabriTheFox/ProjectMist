#include "RT_Layer.h"
#include "Layer.h"

void RT_Layer::Initialize(Layer& layer)
{
	layer.FillRTData(*this);

	for (auto& r : mRenderers)
		r.mpLayer = this;
	for (auto& l : mLights)
		l.mpLayer = this;

	mpCamera = layer.GetCamera().get();
}

void RT_Layer::EmitPhoton(RT_PhotonMap& map, RT_PhotonMap::PhotonData& photon, const Vec3& start, const Vec3& dir, RT_Renderer::RenderData& data)
{
	if (data.mBounces == 0)
		return;

	FTEIntersection::IntersectionResult nearest;
	RT_Renderer* pren = nullptr;

	for (auto& r : mRenderers)
	{
		auto res = r.GetNearestIntersection_Shadow(start, dir, data);
		if (res.mDis < nearest.mDis)
		{
			nearest = res;
			pren = &r;
		}
	}

	if (nearest.HasCollided())
	{
		nearest.mOriginPoint = start;
		pren->EmitPhoton(map, photon, nearest, data);
	}
}

FTEIntersection::IntersectionResult RT_Layer::TraceRay(const Vec3& start, const Vec3& dir, RT_Renderer::RenderData& data)
{
	FTEIntersection::IntersectionResult nearest;
	for (auto& r : mRenderers)
	{
		auto res = r.GetNearestIntersection(start, dir, data);
		if (res.mDis < nearest.mDis)
			nearest = res;
	}
	nearest.mOriginPoint = start;
	return nearest;
}

FTEIntersection::IntersectionResult RT_Layer::TraceShadowRay(const Vec3& start, const Vec3& dir, RT_Renderer::RenderData& data)
{
	FTEIntersection::IntersectionResult nearest;
	for (auto& r : mRenderers)
	{
		auto res = r.GetNearestIntersection_Shadow(start, dir, data);
		if (res.mDis < nearest.mDis)
			nearest = res;
	}
	nearest.mOriginPoint = start;
	return nearest;
}

Vec4 RT_Layer::ComputeColor(const Vec3& start, const Vec3& dir, const Vec4 background, RT_Renderer::RenderData& data)
{
	if (data.mBounces == 0)
		return background;

	FTEIntersection::IntersectionResult nearest;
	RT_Renderer* pren = nullptr;

	for (auto& r : mRenderers)
	{
		auto res = r.GetNearestIntersection(start, dir, data);
		if (res.mDis < nearest.mDis)
		{
			nearest = res;
			pren = &r;
		}
	}

	if (nearest.HasCollided())
	{
		nearest.mOriginPoint = start;
		//auto ph = mPhotonMap.GetValueAt(nearest.mIntersectionPoint, nearest.mNormal);
		//return Vec4(ph.mColor, 1.f);

		//return pren->Render_GI(nearest, data);

		return pren->Render(nearest, data);
	}
	return background;
}

Vec4 RT_Layer::ComputeGI(const Vec3& start, const Vec3& dir, RT_Renderer::RenderData& data)
{
	FTEIntersection::IntersectionResult nearest;
	RT_Renderer* pren = nullptr;

	for (auto& r : mRenderers)
	{
		auto res = r.GetNearestIntersection(start, dir, data);
		if (res.mDis < nearest.mDis)
		{
			nearest = res;
			pren = &r;
		}
	}

	Color color = {0, 0, 0, 1};
	if (nearest.HasCollided())
	{
		nearest.mOriginPoint = start;
		nearest.mNormal = glm::normalize(nearest.mNormal);
		Vec3 irr = { 0, 0, 0 };

		if (!mScatterGather)
			irr = mPhotonMap.GetValueAt(nearest.mIntersectionPoint, nearest.mNormal).mColor;
		else
		{
			//for (unsigned i = 0; i < mGatherSamples; ++i)
			//{
			//	RT_Renderer::RenderData d;
			//	d.mBounces = 1;
			//	Vec3 dir = glm::normalize(Vec3{ Utilities::Random(-1.f, 1.f) , Utilities::Random(-1.f, 1.f) , Utilities::Random(-1.f, 1.f) });
			//	if (glm::dot(dir, nearest.mNormal) < 0)
			//		dir = -dir;
			//
			//	auto inter = TraceRay(nearest.mIntersectionPoint + (dir * 0.01f), dir, d);
			//	inter.mNormal = glm::normalize(inter.mNormal);
			//
			//	irr += mPhotonMap.GetValueAt(inter.mIntersectionPoint, inter.mNormal).mColor;
			//}
			//
			//irr /= mGatherSamples;
			irr = mPhotonMap.GetValueAt(nearest.mIntersectionPoint, nearest.mNormal).mColor;
		}

		color.mColor += Vec4(irr, 1.f);
		color.ClampMaxTo(1.f);
	}
	return color;
}

Vec3 RT_Layer::ComputeGIAt(FTEIntersection::IntersectionResult& at)
{
	if (!mScatterGather)
	{
		if (mIrradianceCacheEnabled)
			return mIrradianceCache.ComputeIrradianceAt(at.mIntersectionPoint, at.mNormal);
		return mPhotonMap.GetValueAt(at.mIntersectionPoint, at.mNormal).mColor;
	}

	if (mIrradianceCacheEnabled)
		return mIrradianceCache.ComputeIrradianceAt(at.mIntersectionPoint, at.mNormal);

	Vec3 gi;
	for (unsigned i = 0; i < mGatherSamples; ++i)
	{
		RT_Renderer::RenderData d;
		d.mBounces = 1;
		Vec3 dir = glm::normalize(Vec3{ Utilities::Random(-1.f, 1.f) , Utilities::Random(-1.f, 1.f) , Utilities::Random(-1.f, 1.f) });
		if (glm::dot(dir, at.mNormal) < 0)
			dir = -dir;

		auto inter = TraceRay(at.mIntersectionPoint + (dir * 0.01f), dir, d);
		inter.mNormal = glm::normalize(inter.mNormal);

		gi += mPhotonMap.GetValueAt(inter.mIntersectionPoint, inter.mNormal).mColor;;
	}

	gi /= mGatherSamples;
	return gi;
}

Vec4 RT_Layer::ComputeColorAt(FTEIntersection::IntersectionResult&, RT_Renderer::RenderData& data)
{
	if (data.mBounces == 0)
		return Vec4();
	return Vec4();
}

Vec4 RT_Layer::ComputeColorAndDis(const Vec3& start, const Vec3& dir, const Vec4 background, float& dis, RT_Renderer::RenderData& data)
{
	if (data.mBounces == 0)
		return background;

	FTEIntersection::IntersectionResult nearest;
	RT_Renderer* pren = nullptr;

	for (auto& r : mRenderers)
	{
		auto res = r.GetNearestIntersection(start, dir, data);
		if (res.mDis < nearest.mDis)
		{
			nearest = res;
			pren = &r;
		}
	}

	if (nearest.HasCollided())
	{
		dis = nearest.mDis;
		nearest.mOriginPoint = start;
		return pren->Render(nearest, data);
	}

	dis = 0;
	return background;
}