#include "Console.h"
#include "ImGUIHeaders.h"

void Console::WriteLine(const std::string& line, Vec3 color)
{
	if (line.empty())
		return;

	mEntries.push_back({});

	mEntries.back().mData = line;
	mEntries.back().mColor = color;

	mScrollToBottom = true;
}

void Console::Clear()
{
	mEntries.clear();
}

void Console::ShowGUI()
{
	if (ImGui::Button("Clear", { 250, 35 }))
		Clear();

	ImGui::SameLine();

	if (ImGui::Button("Go bottom", { 250, 35 }))
		mScrollToBottom = true;

	unsigned offset = (unsigned)ImGui::GetItemRectSize().y + ((unsigned)ImGui::GetStyle().ItemSpacing.y * 2);

	ImGui::Separator();

	auto wd = ImGui::GetContentRegionAvailWidth();
	auto hd = ImGui::GetWindowSize().y - offset - (unsigned)ImGui::GetStyle().ScrollbarSize;
	
	ImGui::BeginChild(std::to_string((int)this).c_str(), ImVec2(wd, hd), false, ImGuiWindowFlags_HorizontalScrollbar);
	
	std::string sp = " ";
	for (auto& e : mEntries)
	{
		ImVec4 c = { e.mColor.x, e.mColor.y, e.mColor.z, 1 };
		ImGui::TextColored(c, (sp + e.mData).c_str());
	}
	
	ImGui::Text("");
	
	if (mScrollToBottom)
	{
		ImGui::SetScrollHere();
		mScrollToBottom = false;
	}
	
	ImGui::EndChild();
}