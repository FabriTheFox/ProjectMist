#pragma once

#include <array>
#include <vector>
#include "DataTypes.h"

// Defines a polynomial of degree 4
class QuadCurve
{
public:
	QuadCurve() : mA(0), mB(0), mC(0), mD(0) {}
	QuadCurve(double a, double b, double c, double d) : mA(a), mB(b), mC(c), mD(d) {}

	// Evaluates the polynomial at t
	double EvaluateAt(float t) const;

	// Evaluates the first derivative of the polynomial at t
	double EvaluateDerivativeAt(float t) const;

	union
	{
		std::array<double, 4> mCoefficients;
		struct
		{
			double mA;	// t^4
			double mB;	// t^3
			double mC;	// t^2
			double mD;	// t^0
		};
	};
};

// Contains a polynomial of degree 4
class BezierCurve
{
public:
	// Constructs the polynomial as a bezier curve of degree 4
	void Construct(const double& p0, const double& p1, const double& p2, const double& p3);

	QuadCurve mCurve;
};

// Representation of a triplet of bezier curves, for each coordinate (x, y, z)
class BezierCurve3D
{
public:

	// Wrapper for Vec3 instead of float 
	void Construct(const Vec3& p0, const Vec3& p1, const Vec3& p2, const Vec3& p3);

	// Constructs the bezier curve matching with first order continuity respect to a previous curve
	void Construct(const BezierCurve3D& derivstart, const Vec3& p0, const Vec3& p1, const Vec3& next);

	// Simply evaluates at t
	Vec3 EvaluateAt(float t) const;

	// Evaluates at t, with t representing the arclength (between 0 and 1)
	Vec3 LinearSpeedEvaluateAt(float t) const;

	// Evaluates the curve at a certain distance
	Vec3 LinearSpeedEvaluateAtDistance(float dis) const;

	// Evaluates the first derivative at t
	Vec3 EvaluateDerivativeAt(float t) const;

	// Computes the arclength values at equally spaced t's
	void ConstructArcLengthTable(int precision);

	// Returns the total arclength of the curve
	float GetTotalArclength() const;

	// Returns the index of the table corresponding to an accumulated arclength
	int GetTCorrespondingToDistance(float dis) const;

	BezierCurve mCurveX;
	BezierCurve mCurveY;
	BezierCurve mCurveZ;

	// Represents an element on the arclength table
	struct Mark
	{
		Mark() = default;
		Mark(float t, float arcl) : mT(t), mArcLength(arcl){}

		float mT;			// T at which it was evaluated
		float mArcLength;	// Accumulated arclength at that T
	};

	std::vector<Mark> mArclengthMarks;
};

// Represents a collection of bezier curves joining together a set of 3D points
class MultiBezier3D
{
public:
	// Constructs n-1 curves interpolating n points in order
	void Construct(const std::vector<Vec3>& points);

	// Constructs n curves interpolating n points. The last joins the first
	void ConstructCircular(const std::vector<Vec3>& points);

	// Evaluates the curve at t
	Vec3 EvaluateAt(float t) const;

	// Evaluates the curve at a certain distance
	Vec3 EvaluateAtDistance(float dis) const;

	// Evaluates the curve linearly respect to the arclength at t
	Vec3 LinearSpeedEvaluateAt(float t) const;

	// return the sum of the arclength of the curves
	float GetTotalArcLength() const;

	// Constructs the arclength tables for all the curves
	void ConstructArcLengthTables(int precisionpersegment);

	std::vector<BezierCurve3D> mCurves;
};


