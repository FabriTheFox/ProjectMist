#pragma once

#include "DataTypes.h"
#include "Transform.h"
#include <vector>
#include <array>

#include "Asset.h"

// Template class of the keyframe for the animation curve
// T is the value to interpolate. Generally float or Quat
template <typename T>
class KeyFrameData
{
public:
	KeyFrameData(const float& fr, const T& val) : mFrame(fr), mValue(val) {}
	KeyFrameData() = default;
	bool operator< (const KeyFrameData& rhs) { return mFrame < rhs.mFrame; }

	float mFrame{0};	// The frame number of the key
	T mValue;			// The value at that frame
};

class Animation;

// Contains a collection of Keyframes. T is the type of value to interpolate.
template <typename T>
class AnimationCurve
{
public:

	// Returns the interpolated value at a given frame
	void Evaluate(float frame, T& val)
	{	
		if (mCurve.empty())
			return;

		// If the frame has not reached the first frame of the curve, return the first.
		if (frame < mStartKey.mFrame)
		{
			val = mStartKey.mValue;
			return;
		}

		// If the frame is beyond the last one, return the last one.
		if (frame >= mEndKey.mFrame)
		{
			val = mEndKey.mValue;
			return;
		}

		// Get the index of the keyframe corresponding to the frame. Ex:
		// [13, 15, 18] if the frame is 17, it will return index of 15.
		int index = FindCurrentIndex(frame);
		
		// Get the keys to interpolate, current and next
		auto key0 = mCurve[index];
		auto key1 = mCurve[index + 1];
		
		// Get the progress of the interp (a value between 0 and 1). If the frame is on key0, 0 if is on key1, 1. 
		float prog = (frame - key0.mFrame) / (key1.mFrame - key0.mFrame);

		// Call the overloaded LERP function for the actual instance type.
		// LERP for floats, SLERP for Quats.
		val = Utilities::LERP(key0.mValue, key1.mValue, prog);
	}

	// Returns the index corresponding to the keyframe with
	// closest frame  (on negative side) to the frame
	int FindCurrentIndex(float frame)
	{
		// Perform binary search on the keyframe vector, since
		// the frame values are ordered in ascending order.
		unsigned l = 0;
		unsigned r = (int)mCurve.size() - 1;
		while(r - l > 1)
		{
			unsigned i = l + ((r - l) / 2);
			if (mCurve[i].mFrame > frame)
				r = i;
			else if (mCurve[i].mFrame < frame)
				l = i;
			else
				return i;
		}
		return l;
	};

	std::vector<KeyFrameData<T>> mCurve;

	KeyFrameData<T> mStartKey;				// Store start and end keys to perform easy outs
	KeyFrameData<T> mEndKey;
};

class AnimationNode
{
public:
	// Update the the local transform of the node at the given frame
	VQS_Transform GetLocalTransform(float frame);
	AnimationNode* GetAnimationNode(const std::string& name);

	class Constraint
	{
	public:
		bool ApplyConstraint(Vec3& v);
		void Set(const Vec3& min, const Vec3& max);

		Vec3 mMin;
		Vec3 mMax;
	};

//private:
	std::array<AnimationCurve<float>, 3> mTranslation;	// 3 floats for position
	std::array<AnimationCurve<float>, 3> mScale;		// 3 floats for scale
	AnimationCurve<FTEQUAT> mRotation;					// 1 Quat for rotation (cannot be separated in channels)

	std::vector<AnimationNode> mChildren;				// Children nodes of this node

	VQS_Transform mLocalTransform;
	Constraint mRotationConstraint;

	std::string mName;
};


class AnimationInstanceNode
{
public:
	void UpdateNodeTransformRecurse(float fr, AnimationNode& node, const VQS_Transform& tr);
	void UpdateNodeTransformRecurse(const VQS_Transform& tr);
	void UpdateNodeTransform(const VQS_Transform& tr);

	const VQS_Transform& GetWorldTransform();
	const Vec3& GetWorldPos();

	VQS_Transform mLocalTransform;

	std::vector<AnimationInstanceNode> mChildren;
	AnimationInstanceNode* mParent{ nullptr };
	AnimationNode* mAnimationNode{nullptr};

private:
	VQS_Transform mWorldTransform;
};

class Animation;
class AnimationInstance
{
	NON_COPYABLE(AnimationInstance)
	friend class Animation;
public:
	AnimationInstance() = default;
	void UpdateAnimation(float fr, const VQS_Transform& parent);
	void UpdateAnimation(const VQS_Transform& parent);

	WK_PTR<Animation> GetAnimation();
	AnimationInstanceNode& GetAnimationNode(const std::string& name);

	AnimationInstanceNode mRootNode;

private:
	AnimationInstanceNode* FindAnimationNodeInternal(AnimationInstanceNode& node, const std::string& name);

	WK_PTR<Animation> mAnimation;
};


// Animation asset class. Contains a root node of an animation and duration in ms and frames of it.
class Animation : 
	public Asset,
	public std::enable_shared_from_this<Animation>
{
	ASSET_DECLARATION(Animation)

public:
	Animation() = default;
	void GetAnimationInstance(AnimationInstance& anim);

	unsigned mDuration{ 0 };	// Duration of the animation in ms
	unsigned mFrames{ 0 };		// Duration in frames

	AnimationNode mRootNode;	// Root node of the animation

private:
	void CopyAnimationInstanceNode(AnimationInstanceNode& instnode, AnimationInstanceNode* parent, AnimationNode& node);
};