#pragma once

#include "System.h"

class EventSystem : public System
{
public:

private:
};