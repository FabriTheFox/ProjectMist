#pragma once

#include "System.h"
#include "Entity.h"

#include "EntitySpace.h"

class EntitySystem : public System
{
	RTTI_DECLARATION(EntitySystem)

public:
	void Initialize() override;
	void Update() override;
	void Shutdown() override;
	void ShowDebug() override;

	Entity& GetEntity(const std::string& name, const std::string& space = "");
	EntitySpace& GetEntitySpace(const std::string& name);
	EntitySpace& GetDefaultSpace();
	std::vector<SHD_PTR<Entity>> GetAllEntities();

private:
	EntitySpace mDefaultEntitySpace;
};