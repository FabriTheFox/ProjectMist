#include "Layer.h"
#include "ImGUIHeaders.h"
#include "DebugRender.h"
#include "FoxTracerEngine.h"
#include "DebugSystem.h"
#include "Light.h"
#include <mutex>

Layer::Layer(const std::string& name) : mName(name) 
{ 
	mCamera = Camera::Create(); 
	mLightingSystem.Initialize();
}

void Layer::Shutdown()
{
	for (auto& r : mRenderers)
		r.second->GetRenderables().AlivePtrs_.clear();
	mLightingSystem.Shutdown();
}

void Layer::Render()
{
	mCamera->Update();
	for (auto& r : mRenderers)
		r.second->Render();
	RenderDebugObjects();
}		

Renderer& Layer::GetRenderer(const std::string name)
{
	auto itr = mRenderers.find(name);
	if (itr == mRenderers.end())
		PRINT_ERROR << "Renderer not found" << std::endl;
	return *itr->second;
}

LightingSystem& Layer::GetLightingSystem()
{
	return mLightingSystem;
}

const std::string& Layer::GetName()
{
	return mName;
}

void Layer::SetCamera(SHD_PTR<Camera> cam)
{
	mCamera = cam;
}

SHD_PTR<Camera> Layer::GetCamera()
{
	return mCamera;
}

void Layer::ShowGUI()
{
	ImGui::Text("Layer: %s", mName.c_str());
	ImGui::Text("Camera: ");
	mCamera->ShowGUI();

	static bool lighting_sys = false;
	std::string lightsys = "Lighting system##" + std::to_string((int)this);
	if (ImGui::Button(lightsys.c_str()))
		lighting_sys = true;

	if (lighting_sys)
		mLightingSystem.ShowGUIWindow(lighting_sys);
}

void Layer::RenderDebugObjects()
{
	for (auto& p : mDebugRenders)
		p->Render();
	mDebugRenders.clear();
}

void Layer::RenderDebugPoint(const Vec3& pos, const Vec4& color, float size)
{
	mDebugRenders.emplace_back(std::make_shared<DebugPoint>(*this, pos, color, size));
}

void Layer::RenderDebugLine(const Vec3& start, const Vec3& end, const Vec4& color, const float& width)
{
	mDebugRenders.emplace_back(std::make_shared<DebugLine>(*this, color, start, end, width));
}

void Layer::RenderDebugScreenLine(const Vec2& start, const Vec2& end, const Vec4& color, const float& width)
{
	mDebugRenders.emplace_back(std::make_shared<DebugScreenLine>(*this, color, start, end, width));
}

void Layer::RenderDebugWireCube(const Transform& tr, const Vec4& color, const float& width)
{
	mDebugRenders.emplace_back(std::make_shared<DebugWireCube>(*this, tr, color, width));
}

void Layer::RenderDebugScreenQuad(Texture& texture)
{
	mDebugRenders.emplace_back(std::make_shared<DebugScreenQuad>(*this, Vec4{0, 0, 0, 0}, texture));
}

void Layer::RenderDebugScreenTRQuad(Texture& texture, const Transform& tr)
{
	mDebugRenders.emplace_back(std::make_shared<DebugScreenTRQuad>(*this, tr, Vec4{ 0, 0, 0, 0 }, texture));
}

void Layer::FillRTData(RT_Layer& layer)
{
	for (auto& r : mRenderers)
	{
		layer.mRenderers.emplace_back(RT_Renderer());
		r.second->FillRTData(layer.mRenderers.back());
	}

	for (auto& l : mLightingSystem.GetLights())
	{
		for (auto& p : l.second)
		{
			layer.mLights.emplace_back(RT_Light());
			p.lock()->FillRTData(layer.mLights.back());
		}
	}
}