#include <iostream>
#include "FoxTracerEngine.h"
#include "Renderer.h"
#include "Model.h"
#include "Light.h"

#include "ImGUIHeaders.h"
#include "Intersection.h"
#include "Property.h"

#include "SDLHeaders.h"
#include "FTESystems.h"

#include "KDTree.h"
#include "PointKDTree.h"

#include "AnimatorCmp.h"
#include "FileUtilities.h"
#include "IKAnimatorCmp.h"

#include "ClothAnimatorCmp.h"

#undef main

WK_PTR<Camera> camera;
const std::string scene = "assets/levels/animation.txt";

void SetContraints();

void LevelAhriInit()
{
	auto desk_res = FoxTracerEngine::Display_.GetDesktopResolution();
	FoxTracerEngine::Display_.SetWindowSize({ desk_res.x * (2.f / 3.f), desk_res.y * (2.f / 3.f) });

	FoxTracerEngine::GetSystem<AssetSystem>().LoadAsset("assets/textures/MR.png");

	FoxTracerEngine::GetSystem<AssetSystem>().LoadAsset("assets/models/Sphere.obj");

	FoxTracerEngine::GetSystem<AssetSystem>().LoadAsset("assets/shaders/BasicShader.frag,assets/shaders/BasicShader.vert", "BasicShader");
	FoxTracerEngine::GetSystem<AssetSystem>().LoadAsset("assets/shaders/CameraLightShader.frag,assets/shaders/CameraLightShader.vert", "CameraLightShader");
	FoxTracerEngine::GetSystem<AssetSystem>().LoadAsset("assets/shaders/TextureShader.frag,assets/shaders/TextureShader.vert", "TexShader");
	FoxTracerEngine::GetSystem<AssetSystem>().LoadAsset("assets/shaders/PhongLightShader.frag,assets/shaders/PhongLightShader.vert", "PhongLightShader");

	FoxTracerEngine::GetSystem<GraphicSystem>().CreateLayer("World");
	FoxTracerEngine::GetSystem<GraphicSystem>().CreateLayer("HUD");

	auto cam = ArcballCamera::Create();
	cam->GetTransform().mPosition = { 0.f, 8.f, 36.f};

	camera = cam;
	FoxTracerEngine::GetSystem<GraphicSystem>().GetLayer("World").SetCamera(cam);
	cam->SetTarget({ 0.f, 0.f, 0.f });
	cam->SetFocalDistance(40.f);

	FoxTracerEngine::GetSystem<GraphicSystem>().GetLayer("World").CreateRenderer<BasicRenderer>("BasicRenderer", "BasicShader");
	FoxTracerEngine::GetSystem<GraphicSystem>().GetLayer("World").CreateRenderer<CameraLightRenderer>("CameraLightRenderer", "CameraLightShader");
	FoxTracerEngine::GetSystem<GraphicSystem>().GetLayer("World").CreateRenderer<AnimationRenderer>("AnimationRenderer", "BasicShader");
	FoxTracerEngine::GetSystem<GraphicSystem>().GetLayer("World").CreateRenderer<ClothMeshRenderer>("ClothMeshRenderer", "BasicShader");
	FoxTracerEngine::GetSystem<GraphicSystem>().GetLayer("World").CreateRenderer<ClothTextureRenderer>("ClothTextureRenderer", "TexShader");
	FoxTracerEngine::GetSystem<GraphicSystem>().GetLayer("World").CreateRenderer<PhongLightRenderer>("PhongLightRenderer", "PhongLightShader");
	FoxTracerEngine::GetSystem<GraphicSystem>().GetLayer("World").CreateRenderer<ReflectivePhongLightRenderer>("ReflectivePhongLightRenderer", "PhongLightShader");
	FoxTracerEngine::GetSystem<GraphicSystem>().GetLayer("World").CreateRenderer<RefractivePhongLightRenderer>("RefractivePhongLightRenderer", "PhongLightShader");

	FoxTracerEngine::GetSystem<SceneSystem>().LoadScene(scene);
	FoxTracerEngine::GetSystem<EditorSystem>().EnableEditor(false);

	auto& en = FoxTracerEngine::GetSystem<EntitySystem>().GetEntity("Cloth");
	en.GetComponent<ClothAnimatorCmp>()->Initialize();
}

void KeyboardInput()
{
	// Reload scene
	if (FoxTracerEngine::GetSystem<InputSystem>().KeyTriggered(SDL_SCANCODE_R))
	{
		FoxTracerEngine::ShutdownAllSystems();
		FoxTracerEngine::GetSystem<SceneSystem>().LoadScene(scene);
	}
	// Save scene
	if (FoxTracerEngine::GetSystem<InputSystem>().KeyPressed(SDL_SCANCODE_LCTRL)
		&& FoxTracerEngine::GetSystem<InputSystem>().KeyTriggered(SDL_SCANCODE_S))
	{
		FoxTracerEngine::GetSystem<SceneSystem>().SaveScene(scene);
	}
	// Full Screen
	if (FoxTracerEngine::GetSystem<InputSystem>().KeyTriggered(SDL_SCANCODE_F))
	{
		static bool dev = false;
		if (!dev)
		{
			FoxTracerEngine::Display_.SetDeveloperFullScreen();
			dev = true;
		}
		else
		{
			FoxTracerEngine::Display_.SetDeveloperWindowed();
			dev = false;
		}
	}
	// Toggle editor overlay
	if (FoxTracerEngine::GetSystem<InputSystem>().KeyPressed(SDL_SCANCODE_LCTRL)
		&& FoxTracerEngine::GetSystem<InputSystem>().KeyTriggered(SDL_SCANCODE_0))
		FoxTracerEngine::GetSystem<EditorSystem>().EnableEditor(!FoxTracerEngine::GetSystem<EditorSystem>().IsEnabled());
}

void CheckClothCut()
{
	static Vec3 points[2];
	static bool tracing = false;

	if (FoxTracerEngine::GetSystem<InputSystem>().MouseTriggered(MOUSE_MIDDLE))
	{
		tracing = true;

		Vec2 mousepos = Vec2(FoxTracerEngine::GetSystem<InputSystem>().GetMousePosition()) / Vec2(FoxTracerEngine::Display_.GetWindowSize());
		auto projplane = camera.lock()->GetProjectionPlane();
		auto& orig = projplane[0];
		auto right = projplane[1] - projplane[0];
		auto down = projplane[2] - projplane[0];
		auto through = orig + (right * mousepos.x) + (down * mousepos.y);
		auto dir = glm::normalize(through - camera.lock()->GetTransform().mPosition);
		auto pos = camera.lock()->GetTransform().mPosition;

		auto dist = glm::length(pos);
		points[0] = pos + (2 * dist * dir);
	}

	if (tracing)
	{
		Vec2 mousepos = Vec2(FoxTracerEngine::GetSystem<InputSystem>().GetMousePosition()) / Vec2(FoxTracerEngine::Display_.GetWindowSize());
		auto projplane = camera.lock()->GetProjectionPlane();
		auto& orig = projplane[0];
		auto right = projplane[1] - projplane[0];
		auto down = projplane[2] - projplane[0];
		auto through = orig + (right * mousepos.x) + (down * mousepos.y);
		auto dir = glm::normalize(through - camera.lock()->GetTransform().mPosition);
		auto pos = camera.lock()->GetTransform().mPosition;
		auto dist = glm::length(pos);

		FoxTracerEngine::GetSystem<GraphicSystem>().GetLayer("World").RenderDebugLine(points[0], pos + (2 * dist * dir), { 1, 0, 0, 1 });

		if (FoxTracerEngine::GetSystem<InputSystem>().MouseReleased(MOUSE_MIDDLE))
		{
			tracing = false;
			points[1] = pos + (2 * dist * dir);

			FoxTracerEngine::GetSystem<EntitySystem>().GetEntity("Cloth").GetComponent<ClothAnimatorCmp>()->CutConstraintsThrough(pos, points[0], points[1]);
		}
	}
}

static bool rel[4] = { true, true, true, true };

void RenderBars()
{
	ClothAnimatorCmp& cmp = *FoxTracerEngine::GetSystem<EntitySystem>().GetEntity("Cloth").GetComponent<ClothAnimatorCmp>();

	Entity* bars[4];
	bars[0] = &FoxTracerEngine::GetSystem<EntitySystem>().GetEntity("Bar0");
	bars[1] = &FoxTracerEngine::GetSystem<EntitySystem>().GetEntity("Bar1");
	bars[2] = &FoxTracerEngine::GetSystem<EntitySystem>().GetEntity("Bar2");
	bars[3] = &FoxTracerEngine::GetSystem<EntitySystem>().GetEntity("Bar3");

	ImGui::Checkbox("Bar0", &rel[0]);
	ImGui::SameLine();
	ImGui::Checkbox("Bar2", &rel[2]);
	ImGui::Checkbox("Bar1", &rel[1]);
	ImGui::SameLine();
	ImGui::Checkbox("Bar3", &rel[3]);

	cmp.ReleaseBars(rel[0], rel[1], rel[2], rel[3]);

	float hs = cmp.mLength.x / 4.f;
	float off = (-cmp.mLength.x / 2.f) + hs / 2.f;
	for (int i = 0; i < 4; ++i)
	{
		bars[i]->GetTransform().mPosition = { off + (i * hs), cmp.GetTransform().mPosition.y, 0 };
		bars[i]->GetTransform().mScale = { hs, 0.2f, 0.2f };
		bars[i]->GetComponent<Renderable>()->SetVisible(rel[i]);
	}
}

void ClothSimulationDemo()
{
	CheckClothCut();

	auto& en = FoxTracerEngine::GetSystem<EntitySystem>().GetEntity("Cloth");
	
	static bool open = true;
	ImGui::SetNextWindowPos({ 0, 0 }, ImGuiSetCond_Once);
	ImGui::Begin("Cloth simulation", &open, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_ShowBorders);

	ImGui::Text("FPS %i", (int)FoxTracerEngine::GetSystem<FrameRateController>().GetFrameRate());
	ImGui::Separator();

	ClothAnimatorCmp& cmp = *en.GetComponent<ClothAnimatorCmp>();

	static IVec2 PointRes = { 35, 35 };
	static Vec2 Length = { 15, 15 };

	ImGui::DragInt2("Mass point resolution", &PointRes.x);
	ImGui::DragFloat2("Cloth size", &Length.x);
	cmp.Resize(Length, PointRes);
	
	ImGui::Spacing();
	ImGui::Separator();
	ImGui::Spacing();

	ImGui::SliderInt("Relaxation iterations", (int*)&cmp.mRestrictionIterations, 0, 25);
	
	ImGui::DragFloat("Drag", &cmp.mDrag, 0.01f);
	ImGui::SliderFloat("Restitution", &cmp.mRestitution, 0.f, 1.f);

	ImGui::Spacing();
	ImGui::Separator();
	ImGui::Spacing();

	static int render_mode = 0;
	ImGui::RadioButton("Shaded", &render_mode, 0);
	ImGui::SameLine();
	ImGui::RadioButton("Links display", &render_mode, 1);

	if (render_mode == 0)
		en.GetComponent<Renderable>()->SetRenderer("ClothTextureRenderer");
	else
		en.GetComponent<Renderable>()->SetRenderer("ClothMeshRenderer");

	ImGui::Spacing();
	ImGui::Separator();
	ImGui::Spacing();

	RenderBars();

	static float wf = 0.5f;	
	ImGui::DragFloat("Wind force", &wf, 0.5f);

	static bool wind = true;
	ImGui::SameLine();
	ImGui::Checkbox("Wind", &wind);

	if (wind)
		cmp.ApplyWindForce({ 0, 0, 1 }, wf);

	ImGui::DragFloat("Gravity force", &cmp.mGravityStrength, 0.5f);

	ImGui::Spacing();
	ImGui::Separator();
	ImGui::Spacing();

	ImGui::DragFloat3("Sphere pos", &cmp.mSpherePosition.x, 0.1f);
	auto& sphtr = FoxTracerEngine::GetSystem<EntitySystem>().GetEntity("Sphere").GetTransform();
	sphtr.mPosition = cmp.mSpherePosition;
	sphtr.mScale = Vec3{ cmp.mSphereRadius, cmp.mSphereRadius, cmp.mSphereRadius }*2.f;

	ImGui::DragFloat3("Cube limits", &cmp.mBoxLimits.x, 0.1f);

	Transform tr;
	tr.mScale = cmp.mBoxLimits * 2.f;
	FoxTracerEngine::GetSystem<GraphicSystem>().GetLayer("World").RenderDebugWireCube(tr);

	ImGui::Spacing();
	ImGui::Separator();
	ImGui::Spacing();

	static bool pause = false;
	ImGui::Checkbox("Pause simulation", &pause);
	if (!pause)
		cmp.Update();

	ImGui::Spacing();
	ImGui::Separator();
	ImGui::Spacing();

	if (ImGui::Button("Reset cloth"))
	{
		for (int i = 0; i < 4; ++i)
			rel[i] = true;
		cmp.Reset();
	}
	ImGui::SameLine();
	if (ImGui::Button("Reset values"))
	{
		cmp.Resize({ 15, 15 }, { 35, 35 });
		cmp.mDrag = 0.001f;
		cmp.mRestitution = 1.f;
		cmp.mBoxLimits = { 15, 15, 15 };
		wind = true;
		wf = 0.5f;
		cmp.mGravityStrength = 1.f;
		cmp.mRestrictionIterations = 10;
		pause = false;
		cmp.mSpherePosition = { 0, 0,  5.f };
	}

	ImGui::End();
}

void LevelAhriRun()
{
	KeyboardInput();
	ClothSimulationDemo();
}

void LevelAhriShutdown() {}

int main()
{
	FoxTracerEngine::Initialize();
	FoxTracerEngine::AddLevel("Ahri", LevelAhriInit, LevelAhriRun, LevelAhriShutdown);
	FoxTracerEngine::SetLevel("Ahri");
	FoxTracerEngine::Run();

	return 0;
}