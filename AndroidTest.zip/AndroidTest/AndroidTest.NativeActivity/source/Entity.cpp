#include "Entity.h"
#include "FoxTracerEngine.h"
#include "Component.h"
#include "RTTI_imp.h"

#include "FTESystems.h"

SERIALIZABLE_IMPLEMENTATION(Entity)

REGISTER_PROPERTIES(Entity)
{
	PROPERTY(Entity, std::string, mName);
	PROPERTY(Entity, std::string, mSpace);
	PROPERTY(Entity, Transform, mTransform);
}

Entity::Entity(const std::string& name) : mName(name) {}

void Entity::Destroy()
{
	RemoveAllComponents();
	FoxTracerEngine::GetSystem<EntitySystem>().GetEntitySpace(mSpace).mEntities.RemovePtr(shared_from_this());
}

void Entity::SetName(const std::string& name)
{
	mName = name;
}

const std::string& Entity::GetName()
{
	return mName;
}

void Entity::SetSpace(const std::string& space)
{
	FoxTracerEngine::GetSystem<EntitySystem>().GetEntitySpace(mSpace).mEntities.RemovePtr(shared_from_this());
	mSpace = space;
	FoxTracerEngine::GetSystem<EntitySystem>().GetEntitySpace(mSpace).mEntities.AddPtr(shared_from_this());
}

const std::string& Entity::GetSpace() { return mSpace; }

void Entity::AddComponent(SHD_PTR<Component> comp)
{
	auto rtti = comp->GetRTTI().mTypehash;
	if (mComponentMap.find(rtti) != mComponentMap.end())
	{
		PRINT_WARNING << "Trying to add a duplicated component" << std::endl;
		return;
	}
	comp->mpOwner = shared_from_this();
	mComponentMap[rtti] = comp;
}

SHD_PTR<Base> Entity::GetComponent(const size_t type)
{
	auto itr = mComponentMap.find(type);
	if (itr != mComponentMap.end())
		return itr->second;
	return nullptr;
}

void Entity::RemoveAllComponents()
{
	for (auto& p : mComponentMap)
		p.second->RemoveFromSystem();
	mComponentMap.clear();
}

SHD_PTR<Entity> Entity::Create(const std::string& name, const std::string& space)
{
	SHD_PTR<Entity>sp = std::make_shared<Entity>(name);
	FoxTracerEngine::GetSystem<EntitySystem>().GetEntitySpace(space).mEntities.AddPtr(sp);
	return sp;
}

SHD_PTR<Base> Entity::CreateB()
{
	return Create();
}

Transform& Entity::GetTransform()
{
	return mTransform;
}

void Entity::Load(SerDataPack& data)
{
	mSpace = "";
	SetSpace(data.GetData("mSpace").GetData<std::string>());
}
