#pragma once

#include "fbxsdk_api/fbxsdk.h"
#include <string>

::FbxManager* GetFBXSDK();
::FbxScene* LoadFBXScene(const std::string& filename);