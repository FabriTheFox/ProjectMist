#include "SceneSystem.h"
#include "RTTI_imp.h"
#include "DebugSystem.h"

RTTI_IMPLEMENTATION(SceneSystem);

PropertyList& SceneSystem::GetProperties()
{
	static PropertyList prop;
	return prop;
}

void SceneSystem::Initialize()
{
	for (auto& fn : FoxTracerEngine::GetRegisterPropertyFunctions())
		if (fn)
			fn();
}

void SceneSystem::LoadScene(const std::string& name)
{
	mDeserializer.LoadLevel(name);
	PRINT_LINE << "Scene '" << name << "' loaded.";
}

void SceneSystem::SaveScene(const std::string& name)
{
	mSerializer.SaveScene(name);
	PRINT_LINE << "Scene '" << name << "' saved.";
}

void SceneSystem::LoadSystemConfigs()
{
	auto t = Utilities::GetFileWritingTime("config.cfg");
	if (t != mCFGLastWritingTime)
	{
		mCFGLastWritingTime = t;
		mDeserializer.LoadConfigFile();
	}
}

void SceneSystem::SaveSystemConfigs()
{
	bool save = false;
	for (auto& sys : FoxTracerEngine::Systems_)
	{
		if (sys.second->GetConfiguration().HasChanged())
		{
			save = true;
			break;
		}
	}

	if (save)
		mSerializer.SaveConfigFile();
}