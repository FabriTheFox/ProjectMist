#include "DebugRender.h"
#include "FoxTracerEngine.h"
#include "OpenGLHeaders.h"
#include "RenderCommand.h"
#include <glm/gtc/type_ptr.hpp>

#include "FTESystems.h"

DebugRender::DebugRender(Layer& layer, const Vec4& color) : mLayer(layer), mColor(color), mCamera(*mLayer.GetCamera()) {}

DebugScreenLine::DebugScreenLine(Layer& layer, const Vec4& color, const Vec2& start, const Vec2& end, const float& width) :
	DebugRender(layer, color),
	mStart(start),
	mEnd(end),
	mWidth(width)
{}

void DebugScreenLine::Render()
{
	static WK_PTR<Shader> p_shader = FoxTracerEngine::GetSystem<AssetSystem>().GetAsset<Shader>("LinesShader");
	static WK_PTR<Model> p_model = FoxTracerEngine::GetSystem<AssetSystem>().GetAsset<Model>("Line");

	RenderCommand render(p_shader, p_model);
	render.EnableDepthTest(false);
	render.EnableDepthWriting(false);
	render.ApplyConfig();

	render.SetUniformMat4("mv_mtx", Mat4());
	render.SetUniformVec3("start", Vec3(mStart, 1.f));
	render.SetUniformVec3("end", Vec3(mEnd, 1.f));
	render.SetUniformVec4("color", mColor);

	gl::LineWidth(mWidth);
	gl::Enable(gl::LINE_SMOOTH);

	render.Render(gl::LINES);
}

DebugLine::DebugLine(Layer& layer, const Vec4& color, const Vec3& start, const Vec3& end, const float& width) :
	DebugRender(layer, color),
	mStart(start),
	mEnd(end),
	mWidth(width)
{}

void DebugLine::Render()
{
	static WK_PTR<Shader> p_shader = FoxTracerEngine::GetSystem<AssetSystem>().GetAsset<Shader>("LinesShader");
	static WK_PTR<Model> p_model = FoxTracerEngine::GetSystem<AssetSystem>().GetAsset<Model>("Line");

	RenderCommand render(p_shader, p_model);
	render.EnableDepthTest(false);
	render.EnableDepthWriting(false);
	render.ApplyConfig();

	render.SetUniformMat4("mv_mtx", mCamera.GetViewportMatrix());
	render.SetUniformVec3("start", mStart);
	render.SetUniformVec3("end", mEnd);
	render.SetUniformVec4("color", mColor);

	gl::LineWidth(mWidth);
	gl::Enable(gl::LINE_SMOOTH);

	render.Render(gl::LINES);
}

DebugScreenQuad::DebugScreenQuad(Layer& layer, const Vec4& color, Texture& tex) :
	DebugRender(layer, color),
	mTexture(tex)
{}

void DebugScreenQuad::Render()
{
	static WK_PTR<Shader> p_shader = FoxTracerEngine::GetSystem<AssetSystem>().GetAsset<Shader>("TexShader");
	static WK_PTR<Model> p_model = FoxTracerEngine::GetSystem<AssetSystem>().GetAsset<Model>("Quad");
	static Mat4 mv = Transform({ 0, 0, 0 }, { 2, 2, 1 }, { 0, 0, 0 }).GetModelMatrix();

	RenderCommand render(p_shader, p_model);
	render.EnableDepthTest(false);
	render.EnableDepthWriting(false);
	render.ApplyConfig();

	render.SetUniformMat4("MV", mv);

	mTexture.Bind(0);
	
	render.Render();
}

DebugScreenTRQuad::DebugScreenTRQuad(Layer& layer, const Transform& tr, const Vec4& color, Texture& tex) :
	DebugRender(layer, color),
	mTexture(tex),
	mTransform(tr)
{}

void DebugScreenTRQuad::Render()
{
	static WK_PTR<Shader> p_shader = FoxTracerEngine::GetSystem<AssetSystem>().GetAsset<Shader>("TexShader");
	static WK_PTR<Model> p_model = FoxTracerEngine::GetSystem<AssetSystem>().GetAsset<Model>("Quad");
	Mat4 mv = mTransform.GetModelMatrix();

	RenderCommand render(p_shader, p_model);
	render.EnableDepthTest(false);
	render.EnableDepthWriting(false);
	render.ApplyConfig();

	render.SetUniformMat4("MV", mv);

	mTexture.Bind(0);

	render.Render();
}

DebugWireCube::DebugWireCube(Layer& layer, const Transform& tr, const Vec4& color, const float& width) :
	DebugRender(layer, color),
	mTransform(tr),
	mWidth(width){}

void DebugWireCube::Render()
{
	static WK_PTR<Shader> p_shader = FoxTracerEngine::GetSystem<AssetSystem>().GetAsset<Shader>("BasicShader");
	static WK_PTR<Model> p_model = FoxTracerEngine::GetSystem<AssetSystem>().GetAsset<Model>("WireCube");

	RenderCommand render(p_shader, p_model);
	render.EnableDepthTest(true);
	render.EnableDepthWriting(true);
	render.ApplyConfig();

	auto mod = mTransform.GetModelMatrix();
	auto mv = mCamera.GetViewportMatrix() * mod;

	render.SetUniformMat4("MV", mv);
	render.SetUniformMat4("ViewSpace", mCamera.GetCameraMatrix() * mod);
	render.SetUniformVec4("modulation_color", mColor);

	gl::LineWidth(mWidth);
	gl::Enable(gl::LINE_SMOOTH);

	render.Render(gl::LINES);
}

DebugPoint::DebugPoint(Layer& layer, const Vec3& pos, const Vec4& color, const float& size) :
	DebugRender(layer, color),
	mPos(pos),
	mSize(size) {}

void DebugPoint::Render()
{
	static WK_PTR<Shader> p_shader = FoxTracerEngine::GetSystem<AssetSystem>().GetAsset<Shader>("PointShader");
	static WK_PTR<Model> p_model = FoxTracerEngine::GetSystem<AssetSystem>().GetAsset<Model>("Point");

	RenderCommand render(p_shader, p_model);
	render.EnableDepthTest(true);
	render.EnableDepthWriting(false);
	render.ApplyConfig();

	auto mv = mCamera.GetViewportMatrix();

	gl::Enable(gl::PROGRAM_POINT_SIZE);

	render.SetUniformMat4("mv_mtx", mv);
	render.SetUniformVec4("color", mColor);
	render.SetUniformVec3("pos", mPos);
	render.SetUniformfloat("pointsize", mSize);

	render.Render(gl::POINTS);
}