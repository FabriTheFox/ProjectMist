#include "Utilities.h"
#include "SDL\SDL_video.h"		
#include "SDL\SDL_timer.h"
#include <math.h>
#include <string>
#include <ctime>

#include <sys\stat.h>

namespace Utilities
{
	int Random(int min, int max)
	{
		if (min == max)
			return min;
		return std::rand() % ((max - min) + 1) + min;
	}

	float Random(float min, float max)
	{
		if (min == max)
			return min;
		float random = ((float)rand()) / (float)RAND_MAX;
		float range = max - min;
		return (random*range) + min;
	}

	float LERP(float a, float b, float f)
	{
		return a + f * (b - a);
	}

	Vec3 LERP(const Vec3& a, const Vec3& b, float f)
	{
		Vec3 res;
		res.r = LERP(a.r, b.r, f);
		res.g = LERP(a.g, b.g, f);
		res.b = LERP(a.b, b.b, f);
		return res;
	}

	Vec4 LERP(const Vec4& a, const Vec4& b, float f)
	{
		Vec4 res;
		res.r = LERP(a.r, b.r, f);
		res.g = LERP(a.g, b.g, f);
		res.b = LERP(a.b, b.b, f);
		res.a = LERP(a.a, b.a, f);
		return res;
	}

	FTE_Quat::FTEQuat LERP(const FTE_Quat::FTEQuat& a, const FTE_Quat::FTEQuat& b, float f)
	{
		return FTE_Quat::Slerp(a, b, f);
	}

	float Clamp(const float& val, const float& min, const float& max)
	{
		if (val < min)
			return min;
		if (val > max)
			return max;
		return val;
	}

	IVec2 WorldToScreenCoords(const Vec3& pos, const Mat4& trans, const IVec2& resolution)
	{
		auto tex_pos = trans * Vec4(pos, 1.f);

		tex_pos = { (tex_pos.x / (2 * tex_pos.w)) + 0.5, (tex_pos.y / (2 * tex_pos.w)) + 0.5, 0, 0 };
		tex_pos.x = tex_pos.x * resolution.x;
		tex_pos.y = resolution.y - (tex_pos.y * resolution.y);

		//if (tex_pos.z > 1 || tex_pos.z < 0)
		//	return { -1, -1 };

		return{ tex_pos.x, tex_pos.y };
	}

	std::string GetDate()
	{
		std::string date;
		date.resize(26);

		std::time_t result = std::time(nullptr);
		tm mtm;
		localtime_s(&mtm, &result);
		asctime_s((char*)date.data(), date.size(), &mtm);
		return date.substr(0, date.size() - 2);
	}

	void RemoveCharFromString(std::string& s, const char& c)
	{
		std::string clean;
		for (unsigned i = 0; i < s.size(); ++i)
		{
			if (s[i] != c)
				clean += s[i];
		}
		s = clean;
	}

	std::string GetFileExtension(const std::string& str)
	{
		auto pos = str.find_last_of('.');
		if (pos == std::string::npos)
			return "";
		return str.substr(pos + 1, std::string::npos);
	}

	std::string GetFileName(const std::string& str)
	{
		auto comma = str.find_last_of('.');
		auto slash = str.find_last_of('/');
		if (slash == std::string::npos)
			slash = 0;
		else
			++slash;
		return str.substr(slash, comma - slash);
	}

	time_t GetFileWritingTime(const std::string& file)
	{
		struct stat st;
		stat(file.c_str(), &st);
		return st.st_mtime;
	}

	std::string AppendID(const std::string& n, const int& id)
	{
		return n + "##" + std::to_string(id);
	}

	std::vector<std::string> GetIndividualPaths(const std::string& path)
	{
		std::string str = path;
		std::vector<std::string> v;
		size_t pos = str.find_first_of(',');
		while (pos != std::string::npos)
		{ 
			auto p = str.substr(0, pos);
			str = str.substr(pos + 1);
			v.push_back(p);
			pos = str.find_first_of(',');
		}
		v.push_back(str);
		return v;
	}

	void Timer::Start()
	{
		mStartTime = SDL_GetTicks();
	}

	void Timer::Update()
	{
		auto time = SDL_GetTicks();
		mTime += time - mStartTime;
		mStartTime = time;
	}

	void Timer::Reset()
	{
		mStartTime = 0;
		mTime = 0;
	}

	unsigned Timer::GetMilliseconds()
	{
		return mTime;
	}

	float Timer::GetSeconds()
	{
		return GetMilliseconds() / 1000.f;
	}

	float Timer::GetMinutes()
	{
		return GetSeconds() / 60.f;
	}

	float Timer::GetHours()
	{
		return GetMinutes() / 60.f;
	}

	float Timer::GetDays()
	{
		return GetHours() / 24.f;
	}

	std::string Timer::GetTime_DaysHoursMinutesSecondsMillisecs(bool d, bool h, bool m, bool s, bool ms)
	{
		std::string str;

		float days = GetDays();
		float frac, integ;

		frac = std::modf(days, &integ);
		if (d)
		{
			str += std::to_string((unsigned)integ);
			str += " D. ";
		}
		
		frac = std::modf(frac * 24, &integ);
		if (h)
		{
			str += std::to_string((unsigned)integ);
			str += " H. ";
		}

		frac = std::modf(frac * 60, &integ);
		if (m)
		{
			str += std::to_string((unsigned)integ);
			str += " M. ";
		}
		
		frac = std::modf(frac * 60, &integ);
		if (s)
		{
			str += std::to_string((unsigned)integ);
			str += " S. ";
		}
		
		frac = std::modf(frac * 1000, &integ);
		if (ms)
		{
			if (integ < 100)
				str += std::to_string((unsigned)0);
			if (integ < 10)
				str += std::to_string((unsigned)0);
			str += std::to_string((unsigned)integ);
			str += " MS. ";
		}

		return str;
	}
}