#include "EntitySystem.h"
#include "ImGUIHeaders.h"
#include "EditorSystem.h"
#include "RTTI_imp.h"

#include "DebugSystem.h"

RTTI_IMPLEMENTATION(EntitySystem);

void EntitySystem::Initialize()
{
	mDefaultEntitySpace.SetName("Default");
}

void EntitySystem::Update(){}

void EntitySystem::Shutdown()
{
	mDefaultEntitySpace.mChildren.AlivePtrs_.clear();
	mDefaultEntitySpace.mEntities.AlivePtrs_.clear();
}

std::vector<SHD_PTR<Entity>> EntitySystem::GetAllEntities()
{
	std::vector<SHD_PTR<Entity>> v;
	mDefaultEntitySpace.GetAllEntities(v);
	return v;
}

Entity& EntitySystem::GetEntity(const std::string& name, const std::string& space)
{
	auto& s = GetEntitySpace(space);
	return s.GetEntity(name);
}

EntitySpace& EntitySystem::GetEntitySpace(const std::string& name)
{
	std::string cat = name;
	cat += "/";
	EntitySpace* parent = &mDefaultEntitySpace;

	while (!cat.empty())
	{
		auto next = cat.find_first_of('/');
		std::string curr_cath = cat.substr(0, next);
		parent = &parent->GetChildSpace(curr_cath);
		cat = cat.substr(next + 1, std::string::npos);
	}
	return *parent;
}

EntitySpace& EntitySystem::GetDefaultSpace()
{
	return mDefaultEntitySpace;
}

void EntitySystem::ShowDebug() {}
