#pragma once

#include "System.h"
#include "Property.h"
#include "Deserializer.h"
#include "Serializer.h"

class SceneSystem : public System
{
	RTTI_DECLARATION(SceneSystem)
	friend class FoxTracerEngine;

public:
	void Initialize() override;
	void LoadScene(const std::string& name);
	void SaveScene(const std::string& name);
	void LoadSystemConfigs();
	void SaveSystemConfigs();

	template <typename T, typename S>
	static IProperty& RegisterProperty(const std::string& name, S T::* pdata)
	{
		auto parent_name = typeid(T).name();

		auto& parent = GetProperties()[parent_name];
		auto& prop = parent[name];
		prop = std::make_shared<Property<T, S>>(pdata);

		prop->mName = name;
		prop->mClassName = typeid(S).name();
		prop->mClassType = typeid(S).hash_code();

		return *prop;
	}

	static PropertyList& GetProperties();

	void ShowComponentGUI(const RTTI& rtti, void* inst)
	{
		auto& props = GetProperties();
		auto& parent = props[rtti.mTypename];

		if (ImGui::TreeNode(rtti.mTypename.c_str()))
		{
			for (auto& pr : parent)
			{
				if (ImGui::TreeNode(pr.first.c_str()))
				{
					pr.second->ShowGUI(props, inst);
					ImGui::TreePop();
				}
			}

			ImGui::TreePop();
		}
		
	}

private:
	Deserializer mDeserializer;
	Serializer mSerializer;

	time_t mCFGLastWritingTime{0};
};