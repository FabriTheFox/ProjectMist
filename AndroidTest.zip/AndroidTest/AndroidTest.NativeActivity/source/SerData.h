#pragma once

#include <unordered_map>
#include <string>

class SerData
{
public:
	SerData(const SerData& rhs) = delete;
	SerData& operator= (const SerData& rhs) = delete;
	SerData() = default;
	~SerData() { if (mAllocated) delete mData; }

	template <typename T>
	void SetData(const T& data)
	{
		if (mAllocated)
			delete mData;
		mData = new T;
		mAllocated = true;
		*((T*)mData) = data;
	}

	template <typename T>
	const T& GetData()
	{
		return *((T*)mData);
	}

	void* mData = nullptr;
	bool mAllocated{ false };
};

class SerDataPack
{
public:
	SerDataPack(const SerDataPack& rhs) = delete;
	SerDataPack& operator= (const SerDataPack& rhs) = delete;
	SerDataPack() = default;

	SerData& GetData(const std::string& name){ return mData[name]; }
private:
	std::unordered_map<std::string, SerData> mData;
};