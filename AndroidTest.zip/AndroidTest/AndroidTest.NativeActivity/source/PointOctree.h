#pragma once

#include "RTTI.h"
#include "Intersection.h"
#include "SpacePartition.h"

template <typename T>
class PointOctree
{
	NON_COPYABLE(PointOctree<T>)
public:
	struct OCTData
	{
		Vec3 mPosition;
		T mData;
	};

	struct Stats
	{
		unsigned mLevel{0};
		unsigned mTotalElements{ 0 };
		unsigned mNodes{ 0 };
		float AvgElementsPerNode{ 0 };
	};

	PointOctree() = default;
	void Initialize(AABB bb, unsigned maxlevel);
	void InsertElement(const OCTData& data);
	//unsigned RenderTree(unsigned level, bool drawparent, bool drawtriangles);
	void DeleteTree();
	void GetNearbyElements(const Vec3& pos, float radius, std::vector<T>& near);
	Stats GetStats() { return mStats; };

private:
	struct OctreeNode
	{
		AABB mBoundingVolume;
		unsigned mLevel{ 0 };

		OctreeNode* mOctants[8];
		std::vector<unsigned> mDataIndices;

		unsigned mElementCount{ 0 };
	};

	struct NodeToRender
	{
		NodeToRender(const AABB& aabb, const unsigned& level) : mBoundingVolume(aabb), mLevel(level) {}
		AABB mBoundingVolume;
		unsigned mLevel;
	};

	//unsigned RenderNode(unsigned level, OctreeNode* node, bool drawparent, bool drawtriangles);
	void DeleteNode(OctreeNode* current, OctreeNode* parent);
	void GetNearbyElementsNode(const Vec3& pos, float radius, std::vector<T>& near, OctreeNode* node);
	void InsertElementNode(unsigned index, const OCTData& data, OctreeNode* node);
	void CreateChildOctants(OctreeNode* node);

	std::vector<OCTData> mData;
	std::vector<NodeToRender> mNodesToRender;

	OctreeNode* mRoot{ nullptr };
	unsigned mMaxLevel;

	Stats mStats;
};

template <typename T>
void PointOctree<T>::Initialize(AABB bb, unsigned maxlevel)
{
	DeleteTree();
	mMaxLevel = maxlevel;

	mRoot = new OctreeNode;
	mRoot->mBoundingVolume = bb;
	mRoot->mBoundingVolume.MakeItCube();
	memset(mRoot->mOctants, 0, sizeof(void*) * 8);
}

template <typename T>
void PointOctree<T>::GetNearbyElements(const Vec3& pos, float radius, std::vector<T>& near)
{
	GetNearbyElementsNode(pos, radius, near, mRoot);
}

template <typename T>
void PointOctree<T>::GetNearbyElementsNode(const Vec3& pos, float radius, std::vector<T>& near, OctreeNode* node)
{
	if (!node)
		return;

	AABB bb;
	bb.mCenter = pos;
	bb.mExtent = Vec3(radius);

	if (!node->mBoundingVolume.IsCollidingWithAABB(bb))
		return;

	float sqrad = radius * radius;
	for (auto& d : node->mDataIndices)
	{
		auto disvec = mData[d].mPosition - pos;
		if (glm::dot(disvec, disvec) <= sqrad)
			near.push_back(mData[d].mData);
	}

	for (unsigned i = 0; i < 8; ++i)
		GetNearbyElementsNode(pos, radius, near, node->mOctants[i]);
}

template <typename T>
void PointOctree<T>::InsertElement(const OCTData& data)
{
	mData.push_back(data);
	InsertElementNode((int)mData.size() - 1, data, mRoot);
}

template <typename T>
void PointOctree<T>::InsertElementNode(unsigned index, const OCTData& data, OctreeNode* node)
{
	int octant_index = -1;

	if (node->mLevel < mMaxLevel)
	{
		if (!node->mOctants[0])
			CreateChildOctants(node);

		for (unsigned i = 0; i < 8; ++i)
		{
			if (node->mOctants[i]->mBoundingVolume.IsPointInside(data.mPosition))
			{
				octant_index = i;
				break;
			}
		}
	}

	if (octant_index < 0)
	{
		node->mDataIndices.push_back(index);
		++mStats.mNodes;
		if (node->mLevel > mStats.mLevel)
			mStats.mLevel = node->mLevel;
		++mStats.mTotalElements;
		mStats.AvgElementsPerNode = mStats.mTotalElements / (float)mStats.mNodes;
		return;
	}

	InsertElementNode(index, data, node->mOctants[octant_index]);
}

template <typename T>
void PointOctree<T>::DeleteTree()
{
	DeleteNode(mRoot, nullptr);
	mRoot = nullptr;
}

template <typename T>
void PointOctree<T>::DeleteNode(OctreeNode* current, OctreeNode* parent)
{
	if (parent)
		delete parent;

	if (!current)
		return;

	for (unsigned i = 0; i < 7; ++i)
		DeleteNode(current->mOctants[i], nullptr);
	DeleteNode(current->mOctants[7], current);
}

template <typename T>
void PointOctree<T>::CreateChildOctants(OctreeNode* node)
{
	for (unsigned i = 0; i < 8; ++i)
		node->mOctants[i] = new OctreeNode;

	AABB& thiscube = node->mBoundingVolume;
	Vec3 halfextent = thiscube.mExtent / 2.f;

	unsigned index = 0;
	for (int x = -1; x < 2; x += 2)
	{
		for (int y = -1; y < 2; y += 2)
		{
			for (int z = -1; z < 2; z += 2, ++index)
			{
				AABB& octantcube = node->mOctants[index]->mBoundingVolume;
				octantcube.mCenter.x = thiscube.mCenter.x + (halfextent.x * x);
				octantcube.mCenter.y = thiscube.mCenter.y + (halfextent.y * y);
				octantcube.mCenter.z = thiscube.mCenter.z + (halfextent.z * z);
				octantcube.mExtent = halfextent;
				node->mOctants[index]->mLevel = node->mLevel + 1;
				memset(node->mOctants[index]->mOctants, 0, sizeof(void*) * 8);
			}
		}
	}
}