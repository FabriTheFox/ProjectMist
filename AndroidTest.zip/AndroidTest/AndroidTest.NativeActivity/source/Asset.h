#pragma once

#include "RTTI.h"
#include <string>

#define ASSET_DECLARATION(thistype)							\
	friend class AssetSystem;								\
	public:													\
	SHD_PTR<thistype> GetPtr() {return shared_from_this();}	\
	private:												\
	RTTI_DECLARATION(thistype)								\
	NON_COPYABLE(thistype)									\
	CREATE_DECLARATION(thistype)				

class Asset : public Base
{
	friend class AssetSystem;
public:
	const std::string& GetName() { return mName; };
	void ReloadAsset();

private:
	void InternalLoad();

protected:

	std::string mName;
	std::string mPath;

	time_t mLastReadingTime{0};
};