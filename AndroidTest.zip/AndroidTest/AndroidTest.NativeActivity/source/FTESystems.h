#pragma once

#include "DisplayModule.h"
#include "DebugSystem.h"
#include "EntitySystem.h"
#include "GraphicSystem.h"
#include "AssetSystem.h"
#include "RayTracerSystem.h"
#include "FrameRateController.h"
#include "InputSystem.h"
#include "SceneSystem.h"
#include "EditorSystem.h"

#include "FoxTracerEngine.h"

//namespace FTESys
//{
//	DebugSystem& FTEDebugSystem() { static auto& s = FoxTracerEngine::GetSystem<DebugSystem>(); return s; }
//}