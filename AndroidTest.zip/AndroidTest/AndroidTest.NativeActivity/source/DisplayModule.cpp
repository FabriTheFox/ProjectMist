#include "ImGUIHeaders.h"
#include "OpenGLHeaders.h"
#include "GraphicsDebug.h"

#include "DisplayModule.h"
#include "Utilities.h"
#include "SDLHeaders.h"
#include "DebugSystem.h"

#include "FTE_Config.h"

DisplayModule::DisplayModule() {}

DisplayModule::~DisplayModule()
{
	Terminate();
}

void DisplayModule::Initialize(const IVec2& opengl_version)
{
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, opengl_version.x);
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, opengl_version.y);
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
	SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);
	SDL_GL_SetAttribute(SDL_GL_STENCIL_SIZE, 1);

	if (SDL_Init(SDL_INIT_VIDEO) < 0)
		PRINT_ERROR << "SDL could not initialize! SDL_Error: " << SDL_GetError() << std::endl;

	SDL_GL_SetAttribute(SDL_GL_STENCIL_SIZE, 1);
	SDL_GL_SetAttribute(SDL_GL_MULTISAMPLEBUFFERS, 1);
	SDL_GL_SetAttribute(SDL_GL_MULTISAMPLESAMPLES, 4);

#if FTE_ENABLE_GL_DEBUG
		SDL_GL_SetAttribute(SDL_GL_CONTEXT_FLAGS, SDL_GL_CONTEXT_DEBUG_FLAG);
#endif

	mpWindow = SDL_CreateWindow("Fox Tracer Engine - Fabrizio Tonietti", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, mWindowSize.x, mWindowSize.y,
		SDL_WINDOW_OPENGL | SDL_WINDOW_SHOWN | SDL_WINDOW_ALLOW_HIGHDPI);

	if (!mpWindow)
		PRINT_ERROR << "Window could not be created! SDL_Error: " << SDL_GetError() << std::endl;

	mpGL_context = SDL_GL_CreateContext((SDL_Window*)mpWindow);


	if (mpGL_context == nullptr)
		PRINT_ERROR << "OpenGL context could not be created! SDL Error: " << SDL_GetError() << std::endl;

	gl::sys::LoadFunctions();
	InitializeImGUI();

#if FTE_ENABLE_GL_DEBUG
	gl::Enable(gl::DEBUG_OUTPUT);
	gl::Enable(gl::DEBUG_OUTPUT_SYNCHRONOUS);
	gl::DebugMessageCallback((GLDEBUGPROC)GFX::glDebugOutput, nullptr);
	gl::DebugMessageControl(gl::DONT_CARE, gl::DONT_CARE, gl::DONT_CARE, 0, nullptr, gl::TRUE_);
#endif

	// Initialize members
	CheckDesktopResolution();
	GetWindowPos();
	CenterWindow();
	SetWindowMode(WINDOWED);

}

void DisplayModule::Terminate()
{
	SDL_GL_DeleteContext(mpGL_context);
	SDL_DestroyWindow((SDL_Window*)mpWindow);
	mpWindow = nullptr;
	SDL_Quit();
}

void DisplayModule::SwapWindow()
{
	SDL_GL_SwapWindow((SDL_Window*)mpWindow);
}

void DisplayModule::SetWindowSize(const IVec2 & size)
{
	SDL_SetWindowSize((SDL_Window*)mpWindow, size.x, size.y);
	mWindowSize = size;
	CenterWindow();
}

const glm::ivec2 & DisplayModule::GetWindowSize()
{
	int w;
	int h;
	SDL_GetWindowSize((SDL_Window*)mpWindow, &w, &h);
	if (mWindowSize.x != w || mWindowSize.y != h)
	{
		PRINT_WARNING << "Window has been externally resized" << std::endl;
		mWindowSize = IVec2{ w, h };
	}
	return mWindowSize;
}

void DisplayModule::SetWindowPos(const IVec2& pos)
{
	SDL_SetWindowPosition((SDL_Window*)mpWindow, pos.x, pos.y);
}

const IVec2& DisplayModule::GetWindowPos()
{
	SDL_GetWindowPosition((SDL_Window*)mpWindow, &mWindosPos.x, &mWindosPos.y);
	return mWindosPos;
}

void DisplayModule::CenterWindow()
{
	SetWindowPos({ (mDesktopResolution.x - mWindowSize.x) / 2, (mDesktopResolution.y - mWindowSize.y) / 2 });
}

const DisplayModule::WINDOW_MODE& DisplayModule::GetWindowMode() const
{
	return mWindowMode;
}

void DisplayModule::SetWindowMode(WINDOW_MODE mode)
{
	unsigned int flags = 0;;
	switch (mode)
	{
	case DisplayModule::FULLSCREEN:
		flags |= SDL_WINDOW_FULLSCREEN;
		break;
	case DisplayModule::WINDOWED:
		flags |= 0;
		break;
	case DisplayModule::FULL_WINDOWED:
		flags |= SDL_WINDOW_FULLSCREEN_DESKTOP;
		break;
	default:
		break;
	}

	SDL_SetWindowFullscreen((SDL_Window*)mpWindow, flags);
	mWindowMode = mode;
}

bool DisplayModule::GetWindowBordered()
{
	return mBordered;
}

void DisplayModule::SetWindowBordered(bool bordered)
{
	SDL_SetWindowBordered((SDL_Window*)mpWindow, (SDL_bool)bordered);
}

float DisplayModule::GetWindowAspectRatio()
{
	auto size = GetWindowSize();
	return (float)size.x / (float)size.y;
}

IVec2 DisplayModule::GetDesktopResolution()
{
	return mDesktopResolution;
}

IVec2 DisplayModule::CheckDesktopResolution()
{
	RECT desktop_size;
	GetWindowRect(GetDesktopWindow(), &desktop_size);
	mDesktopResolution.x = desktop_size.right;
	mDesktopResolution.y = desktop_size.bottom;
	return mDesktopResolution;
}

void DisplayModule::SetDeveloperFullScreen()
{
	SetWindowMode(WINDOWED);
	SetWindowBordered(false);
	SDL_SetWindowSize((SDL_Window*)mpWindow, mDesktopResolution.x + 1, mDesktopResolution.y);
	mWindowSize = { mDesktopResolution.x + 1, mDesktopResolution.y};
	SetWindowPos({ 0, 0 });
}

void DisplayModule::SetDeveloperWindowed()
{
	SetWindowMode(DisplayModule::WINDOWED);
	SetWindowSize({ mDesktopResolution.x * (2.f / 3.f), mDesktopResolution.y * (2.f / 3.f) });
	SetWindowBordered(true);
}

void* DisplayModule::GetWindow()
{
	return mpWindow;
}

void DisplayModule::InitializeImGUI()
{
	InitializeGL3W();
	ImGui_ImplSdlGL3_Init((SDL_Window*)mpWindow);

	ImGuiIO& io = ImGui::GetIO();
	//io.Fonts->AddFontDefault();
	//io.Fonts->AddFontFromFileTTF("include/imgui/extra_fonts/Righteous-Regular.ttf", 30.0f);
	io.Fonts->AddFontFromFileTTF("include/imgui/extra_fonts/Cousine-Regular.ttf", 15.0f);
	//io.Fonts->AddFontFromFileTTF("include/imgui/extra_fonts/DroidSans.ttf", 30.0f);
	//io.Fonts->AddFontFromFileTTF("include/imgui/extra_fonts/ProggyClean.ttf", 30.0f);
	//io.Fonts->AddFontFromFileTTF("include/imgui/extra_fonts/ProggyTiny.ttf", 30.0f);
	//io.Fonts->AddFontFromFileTTF("c:\\Windows\\Fonts\\ArialUni.ttf", 18.0f, NULL, io.Fonts->GetGlyphRangesJapanese());
}

