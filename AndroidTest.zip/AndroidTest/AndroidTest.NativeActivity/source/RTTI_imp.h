#pragma once

#include "FoxTracerEngine.h"
#include "SceneSystem.h"

#define RTTI_IMPLEMENTATION(thistype)																	\
	RTTI& thistype::RTTI_ = FoxTracerEngine::RegisterRTTI<thistype>(nullptr);							\
	void thistype::RegisterProperties(){}

#define SERIALIZABLE_IMPLEMENTATION(thistype)															\
	RTTI& thistype::RTTI_ = FoxTracerEngine::RegisterRTTI<thistype>(&thistype::CreateB);				\
	
#define COMPONENT_SERIALIZABLE_IMPLEMENTATION(thistype)													\
	SERIALIZABLE_IMPLEMENTATION(thistype)	

#define COMPONENT_IMPLEMENTATION(thistype)																\
	RTTI_IMPLEMENTATION(thistype)

#define ASSET_IMPLEMENTATION(thistype)																	\
	RTTI_IMPLEMENTATION(thistype)

#define REGISTER_PROPERTIES(thistype)																	\
	void thistype::RegisterProperties()

#define PROPERTY(parenttype, type, name)																\
	SceneSystem::RegisterProperty<parenttype, type>(#name, &parenttype::name)