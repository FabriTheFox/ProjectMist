#pragma once

#include "DataTypes.h"

class Transform
{
public:
	Transform() = default;
	Transform(const Vec3& p, const Vec3& s, const Vec3& r);

	Mat4 GetModelMatrix();
	Mat4 GetInvMatrix();
	Mat4 GetRotationMatrix();

	Vec3 TransformPosition(const Mat4& mat) const;

	Vec3 VectorToLocal(const Vec3& vec);
	Vec3 VectorToParent(const Vec3& vec);

	Vec3 PositionToLocal(const Vec3& pos);
	Vec3 PositionToParent(const Vec3& pos);

	void OrientTo(const Vec3& target, const Vec3& axis, const Vec3& up);
	void RotateAround(const Vec3& axis, float deg);

private:
	Vec3 GetEulerAnglesFromMatrix(const Mat4& mat);

public:
	Vec3 mPosition{0, 0, 0};
	Vec3 mScale{1, 1, 1};
	Vec3 mRotation{0, 0, 0};
};