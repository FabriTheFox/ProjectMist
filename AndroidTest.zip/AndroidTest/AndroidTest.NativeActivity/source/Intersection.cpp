#include "Intersection.h"
#include "Transform.h"
#include <glm\gtx\intersect.hpp>

namespace FTEIntersection
{
	bool Triangle::IsPointInside(const Vec3& p)
	{
		Vec3 v0 = mVertices[1] - mVertices[0], v1 = mVertices[2] - mVertices[0], v2 = p - mVertices[0];
		float d00 = glm::dot(v0, v0);
		float d01 = glm::dot(v0, v1);
		float d11 = glm::dot(v1, v1);
		float d20 = glm::dot(v2, v0);
		float d21 = glm::dot(v2, v1);
		float denom = d00 * d11 - d01 * d01;
		float v = (d11 * d20 - d01 * d21) / denom;
		float w = (d00 * d21 - d01 * d20) / denom;
		if (v < 0 || w < 0 || 1.0f - v - w < 0)
			return false;
		return true;
	}

	void Triangle::ComputeNormal()
	{
		mN = glm::normalize(glm::cross(mVertices[1] - mVertices[0], mVertices[2] - mVertices[0]));
	}

	bool Triangle::TraceRay_Test(const Vec3& lineorig, const Vec3& linedir)
	{
		Vec3 bar;
		if (glm::dot(mN, -linedir) > 0)
			return glm::intersectRayTriangle(lineorig, linedir, mVertices[0], mVertices[1], mVertices[2], bar);
		return glm::intersectRayTriangle(lineorig, linedir, mVertices[2], mVertices[1], mVertices[0], bar);
	}

	IntersectionResult Triangle::TraceRay(const Vec3& lineorig, const Vec3& linedir)
	{
		IntersectionResult res;

		if (glm::dot(mN, -linedir) < 0)
			res.mIsBackFace = true;

		Vec3 bar;
		if (!res.mIsBackFace)
		{
			if (!glm::intersectRayTriangle(lineorig, linedir, mVertices[0], mVertices[1], mVertices[2], bar))
				return IntersectionResult();
		}
			
		else
		{
			if (!glm::intersectRayTriangle(lineorig, linedir, mVertices[2], mVertices[1], mVertices[0], bar))
				return IntersectionResult();
		}

		res.mIntersectionPoint = lineorig + (bar.z * linedir);
		res.mDis = bar.z;
		bar.z = 1 - bar.x - bar.y;
		res.mNormal = (mNormals[0] * bar.z) + (mNormals[1] * bar.x) + (mNormals[2] * bar.y);
		if (res.mIsBackFace)
			res.mNormal = -res.mNormal;

		return res;
	}

	float Triangle::GetMinValOnAxis(unsigned axis) const
	{
		return std::fmin(std::fmin(mVertices[0][axis], mVertices[1][axis]), mVertices[2][axis]);
	}

	float Triangle::GetMaxValOnAxis(unsigned axis) const
	{
		return std::fmax(std::fmax(mVertices[0][axis], mVertices[1][axis]), mVertices[2][axis]);
	}

	IntersectionResult Ray_UnitarySphereOrigin(const Vec3& lineorig, const Vec3& linedir)
	{
		float a = glm::dot(linedir, (lineorig));
		auto discr = (a * a) - (glm::dot(lineorig, lineorig)) + (0.25f);
		if (discr < 0)
			return IntersectionResult();
		float sqr = glm::sqrt(discr);
		float dis = -a - sqr;;
		bool inside = false;
		float n = 1.f;
		if (dis < 0)
		{
			n = -1.f;
			inside = true;
			dis = -a + sqr;
		}
		if (dis < 0)
			return IntersectionResult();
		Vec3 point = lineorig + (dis * linedir);
		return IntersectionResult(point, dis, point * n, inside);
	}

	IntersectionResult Ray_Sphere(const Vec3& sphcenter, float radius, const Vec3& lineorig, const Vec3& linedir)
	{
		auto v = lineorig - sphcenter;
		float a = glm::dot(linedir, v);
		float leng = glm::dot(v, v);
		auto discr = (a * a) - (leng) + (radius * radius);
		if (discr < 0)
			return IntersectionResult();
		float sqr = glm::sqrt(discr);
		float dis = -a - sqr;
		bool inside = false;
		float n = 1.f;
		if (dis < 0)
		{
			n = -1.f;
			inside = true;
			dis = -a + sqr;
		}
		if (dis < 0)
			return IntersectionResult();
		Vec3 point = lineorig + (dis * linedir);
		return IntersectionResult(point, dis, (point - sphcenter) * n, inside);
	}

	IntersectionResult Ray_Ellipsoid(const Mat4& worldtomodel, const Vec3& lineorig, const Vec3& linedir)
	{
		Vec3 s = Vec3(worldtomodel * Vec4(lineorig, 1));
		Vec3 e = Vec3(worldtomodel * Vec4(lineorig + linedir, 1));
		float l = glm::length(e - s);
		Vec3 d = (e - s) / l;

		auto res = Ray_UnitarySphereOrigin(s, d);
		res.mDis = res.mDis / l;
		res.mIntersectionPoint = lineorig + (linedir * res.mDis);
		res.mOriginPoint = lineorig;
		res.mNormal = glm::normalize(Vec3(glm::transpose(worldtomodel) * Vec4(res.mNormal, 0.f)));

		return res;
	}

	IntersectionResult Ray_InfinitePlane(const Vec3& planepoint, const Vec3& normal, const Vec3& lineorig, const Vec3& linedir)
	{
		float a = glm::dot(linedir, normal);
		if (a == 0)
			return IntersectionResult();
		float dis = (glm::dot((planepoint - lineorig), normal)) / a;
		if (dis <= 0)
			return IntersectionResult();
		return IntersectionResult(lineorig + (dis * linedir), dis);
	}

	IntersectionResult Ray_OBB(const Mat4& worldtomodel, const Vec3& lineorig, const Vec3& linedir)
	{
		Vec3 s = Vec3(worldtomodel * Vec4(lineorig, 1));
		Vec3 e = Vec3(worldtomodel * Vec4(lineorig + linedir, 1));
		float l = glm::length(e - s);
		Vec3 d = (e - s) / l;

		auto res = Ray_AACubeOrigin(s, d);
		res.mDis = res.mDis / l;
		res.mIntersectionPoint = lineorig + (linedir * res.mDis);
		res.mOriginPoint = lineorig;
		res.mNormal = glm::normalize(Vec3(glm::transpose(worldtomodel) * Vec4(res.mNormal, 0.f)));

		return res;
	}

	bool Ray_AABB_Test(const Vec3& center, const Vec3& scale, const Vec3& lineorig, const Vec3& linedir)
	{
		float x1 = (center.x - scale.x - lineorig.x) / linedir.x;
		float x2 = (center.x + scale.x - lineorig.x) / linedir.x;

		float min = -FLT_MAX;
		float max = FLT_MAX;

		if (x1 < x2) {
			min = x1;
			max = x2;}
		else {
			min = x2;
			max = x1;}

		float y1 = (center.y - scale.y - lineorig.y) / linedir.y;
		float y2 = (center.y + scale.y - lineorig.y) / linedir.y;

		float ymin = y1;
		float ymax = y2;
		if (ymin > ymax)
			std::swap(ymin, ymax);
		if (ymin > min)
			min = ymin;
		if (ymax < max)
			max = ymax;

		float z1 = (center.z - scale.z - lineorig.z) / linedir.z;
		float z2 = (center.z + scale.z - lineorig.z) / linedir.z;
		float zmin = z1;
		float zmax = z2;

		if (zmin > zmax) 
			std::swap(zmin, zmax);
		if (zmin > min)
			min = zmin;
		if (zmax < max)
			max = zmax;

		if (min < 0 && max < 0)
			return false;
		return min < max;
	}

	IntersectionResult Ray_AABB(const Vec3& center, const Vec3& scale, const Vec3& lineorig, const Vec3& linedir)
	{
		float x1 = (center.x -scale.x - lineorig.x) / linedir.x;
		float x2 = (center.x + scale.x - lineorig.x) / linedir.x;

		float min = -FLT_MAX;
		float max = FLT_MAX;
		Vec3 n;
		Vec3 maxn;
		if (x1 < x2) {
			n.x = -1;
			maxn.x = -1;
			min = x1;
			max = x2;
		}
		else {
			n.x = 1;
			maxn.x = 1;
			min = x2;
			max = x1;
		}

		float y1 = (center.y -scale.y - lineorig.y) / linedir.y;
		float y2 = (center.y + scale.y - lineorig.y) / linedir.y;

		float ymin = y1;
		float ymax = y2;
		float yn = -1;
		if (ymin > ymax) {
			std::swap(ymin, ymax);
			yn = 1;
		}

		if (ymin > min) {
			n = { 0, yn, 0 };
			min = ymin;
		}
		if (ymax < max)
		{
			max = ymax;
			maxn = { 0, yn, 0 };
		}

		float z1 = (center.z -scale.z - lineorig.z) / linedir.z;
		float z2 = (center.z + scale.z - lineorig.z) / linedir.z;
		float zmin = z1;
		float zmax = z2;
		float zn = -1;

		if (zmin > zmax) {
			std::swap(zmin, zmax);
			zn = 1;
		}
		if (zmin > min) 
		{
			n = { 0, 0, zn };
			min = zmin;
		}
		if (zmax < max)
		{
			max = zmax;
			maxn = { 0, 0, zn };
		}

		if (min < 0 && max < 0)
			return IntersectionResult();
		if (max > min)
		{
			bool inside = false;
			if (min < 0)
			{
				n = maxn;
				min = max;
				inside = true;
			}
			return IntersectionResult(lineorig + (linedir * min), min, n, inside);
		}
		return IntersectionResult();
	}

	/*IntersectionResult Ray_AABB(const Vec3& center, const Vec3& scale, const Vec3& lineorig, const Vec3& linedir)
	{
		float min = -FLT_MAX;
		float max = FLT_MAX;

		float x1 = (center.x - scale.x - lineorig.x) / linedir.x;
		float x2 = (center.x + scale.x - lineorig.x) / linedir.x;
		float xmin = std::fmin(x1, x2);
		float xmax = std::fmax(x1, x2);
		
		min = std::fmax(min, xmin);
		max = std::fmin(max, xmax);

		float y1 = (center.y - scale.y - lineorig.y) / linedir.y;
		float y2 = (center.y + scale.y - lineorig.y) / linedir.y;
		float ymin = std::fmin(y1, y2);
		float ymax = std::fmax(y1, y2);

		min = std::fmax(min, ymin);
		max = std::fmin(max, ymax);

		float z1 = (center.z - scale.z - lineorig.z) / linedir.z;
		float z2 = (center.z + scale.z - lineorig.z) / linedir.z;
		float zmin = std::fmin(z1, z2);
		float zmax = std::fmax(z1, z2);

		min = std::fmax(min, zmin);
		max = std::fmin(max, zmax);

		if (min < 0 && max < 0)
			return IntersectionResult();
		if (max > min)
		{
			if (min < 0)
				min = max;

			Vec3 normal;
			if (min == x1)
				normal = { -1, 0, 0 };
			else if (min == x2)
				normal = { 1, 0, 0 };
			else if (min == y1)
				normal = { 0, -1, 0 };
			else if (min == y2)
				normal = { 0, 1, 0 };
			else if (min == z1)
				normal = { 0, 0, -1 };
			else if (min == z2)
				normal = { 0, 0, 1 };

			return IntersectionResult(true, lineorig + (linedir * min), min, normal);
		}
		return IntersectionResult();
	}*/

	IntersectionResult Ray_AACubeOrigin(const Vec3& lineorig, const Vec3& linedir)
	{
		float x1 =  (-0.5f - lineorig.x) / linedir.x;
		float x2 =  (0.5f - lineorig.x) / linedir.x;

		float min = -FLT_MAX;
		float max = FLT_MAX;
		Vec3 n;
		if (x1 < x2) {
			n.x = -1;
			min = x1;
			max = x2;
		}
		else {
			n.x = 1;
			min = x2;
			max = x1;
		}

		float y1 = (-0.5f - lineorig.y) / linedir.y;
		float y2 = (0.5f - lineorig.y) / linedir.y;

		float ymin = y1;
		float ymax = y2;
		float yn = -1;
		if (ymin > ymax) {
			std::swap(ymin, ymax);
			yn = 1;
		}
		if (ymin > min) {
			n = { 0, yn, 0 };
			min = ymin;
		}
		if (ymax < max)
			max = ymax;

		float z1 = (- 0.5f - lineorig.z) / linedir.z;
		float z2 = (+ 0.5f - lineorig.z) / linedir.z;
		float zmin = z1;
		float zmax = z2;
		float zn = -1;

		if (zmin > zmax) {
			std::swap(zmin, zmax);
			zn = 1;
		}
		if (zmin > min)
		{
			n = { 0, 0, zn };
			min = zmin;
		}
		if (zmax < max)
			max = zmax;

		if (min < 0 && max < 0)
			return IntersectionResult();
		if (max > min)
		{
			bool inside = false;
			if (min < 0)
			{
				n *= -1;
				min = max;
				inside = true;
			}
			return IntersectionResult(lineorig + (linedir * min), min, n, inside);
		}
		return IntersectionResult();
	}

	Vec3 Refract(const Vec3& i, const Vec3& n, float eta)
	{
		const float dot = glm::dot(i, n);
		float k = 1 - (eta * eta) * (1 - (dot * dot));
		if (k < 0)
			return glm::reflect(i, n);
		return glm::refract(i, n, eta);
	}
}