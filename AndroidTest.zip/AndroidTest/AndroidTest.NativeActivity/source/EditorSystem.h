#pragma once

#include "System.h"
#include "Editor.h"

#include <map>

class EditorSystem : public System
{
	RTTI_DECLARATION(EditorSystem)

private:
	struct GUIWindow
	{
		void ShowActive();
		void RenderWindowHorizontal();
		void RenderWindowVertical();
		void AddToActiveList();
		void RemoveFromActiveList();

		virtual void CallFunction() { if (mFunct) mFunct(); }

		std::string mName;
		std::string mPath;
		unsigned mEditorSide;
		bool mActive{ false };

		typedef void(*GUIWindowFun)();
		std::map<std::string, GUIWindow*> mChildren;
		GUIWindowFun mFunct{ nullptr };

		static std::vector<std::vector<GUIWindow*>>* mpActiveWindowList;
		static std::vector<std::vector<GUIWindow*>>* mpDeleteWindowList;
	} mGUIWindows;

	template <typename T>
	struct TGUIWindow : public GUIWindow
	{
		void CallFunction() override
		{
			if (mObject && mFunct)
				(mObject->*(mFunct))();
		}

		typedef void(T::*TGUIWindowFun)();
		TGUIWindowFun mFunct{ nullptr };
		T* mObject{ nullptr };
	};

public:
	void Initialize() override;
	void Update() override;
	void ShowDebug() override;
	void Shutdown() override;

	void EnableEditor(bool enable);
	bool IsEnabled();

	void SetGameViewPort();

	void AddGUIWindow(void(*fp)(), const std::string& name, const std::string& cathegory, unsigned editorside);

	template <typename T>
	void AddGUIWindow(void(T::*fp)(), T* object, const std::string& name, const std::string& cathegory, unsigned editorside)
	{
		GUIWindow* parent = &mGUIWindows;
		std::string cath = cathegory;

		while (cath != "")
		{
			auto next = cath.find_first_of('/');
			std::string curr_cath = cath.substr(0, next);
			cath = cath.substr(next + 1, std::string::npos);

			parent = parent->mChildren[curr_cath];

			if (!parent)
				parent = new TGUIWindow<T>;

			parent->mName = curr_cath;
		}

		auto& child = parent->mChildren[name];
		child = new TGUIWindow<T>;

		child->mName = name;
		((TGUIWindow<T>*)(child))->mFunct = fp;
		((TGUIWindow<T>*)(child))->mObject = object;

		child->mPath = cathegory + "/" + name;
		child->mEditorSide = editorside;
	}

private:
	void RenderMainMenuBar();
	void RenderEditorWindows();

	void RenderSideWindows(unsigned side);
	void RemoveInactiveWindows();

	// Size and positions of the game window and the editor windows
	struct WindowLayoutProperties
	{
		void UpdateWindowLayoutProperties();
		IVec2 GetGameWindowSize();

		Vec2 mGameWindowRelativeSize{ 0.75f, 0.75f };

		IVec2 mWindowResolution;
		unsigned mMenuBarSize;		// y size in pixels
		IVec2 mGameWindowSize;

		IVec2 mGameWindowTL;
		IVec2 mGameWindowTR;
		IVec2 mGameWindowBL;
		IVec2 mGameWindowBR;

		bool mHasChanged{ true };
	} mWindowProperties;	

	std::vector<std::vector<GUIWindow*>> mActiveWindowList;
	std::vector<std::vector<GUIWindow*>> mDeleteWindowList;

	Editor mEditor;
	bool mEditorEnabled{ true };
};