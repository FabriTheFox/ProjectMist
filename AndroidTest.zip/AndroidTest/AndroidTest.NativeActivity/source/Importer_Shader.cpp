#include "Importer_Shader.h"
#include "AssetSystem.h"

void Importer_Shader::Import(const std::string& name, const std::string& path)
{
	auto& sys = FoxTracerEngine::GetSystem<AssetSystem>();
	auto& asset = sys.RegisterAsset<Shader>(name);	

	asset.mPath = path;
	asset.mName = name;

	auto paths = Utilities::GetIndividualPaths(path);
	asset.CreateProgram(paths[1], paths[0], "");
}