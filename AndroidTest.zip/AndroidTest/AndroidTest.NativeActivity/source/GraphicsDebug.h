#pragma once

#include "OpenGLHeaders.h"
#include <iostream>

namespace GFX {

	void APIENTRY glDebugOutput(GLenum source, GLenum type, GLuint id, GLenum severity,
		GLsizei length, const GLchar *message, void *userParam);

	bool PrintOpenGLError(GLenum error, const char * function);

#define CHECK_GL_ERROR()										\
	if (GLenum error = gl::GetError())							\
		if (PrintOpenGLError(error, __FUNCTION__))				\
			DebugBreak()
}