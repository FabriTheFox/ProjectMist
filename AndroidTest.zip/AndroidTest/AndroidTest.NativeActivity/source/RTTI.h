#pragma once
#include "SerData.h"
#include "DataTypes.h"

class Base;
typedef std::shared_ptr<Base>(*create_func)();

struct RTTI
{
	RTTI(const std::string& name = "", size_t type = 0, create_func fn = nullptr) : mTypename(name), mTypehash(type), mCreateFun(fn) {}
	std::string mTypename;
	size_t mTypehash{ 0 };
	create_func mCreateFun;
};

class Base
{
public:
	virtual RTTI& GetRTTI() const = 0;
	virtual void Load(SerDataPack& data) { (void)(data); }
private:
};

// In the .h
#define NON_COPYABLE(thistype)																	\
	public:																						\
	thistype(const thistype&) = delete;															\
	thistype& operator= (const thistype&) = delete;												\
	//thistype() = default; private:

// In the .h
// Requires to be derived from Base
#define RTTI_DECLARATION(thistype)																\
	public:																						\
	virtual RTTI& GetRTTI() const override {return RTTI_;}										\
	static RTTI& RTTI_;																			\
	static void RegisterProperties();															\
	private:																					\
	friend class Component;																		\
	friend class Entity;																		\
	friend class Editor;																			

#define CREATE_AS_BASE_DECLARATION(thistype)													\
	public:																						\
	template<typename... Args> static SHD_PTR<Base> CreateB(Args&&... args)						\
	{ return std::make_shared<thistype>(args...); }												\
	private:

// In the .h
#define CREATE_DECLARATION(thistype)															\
	public:																						\
	template<typename... Args> static SHD_PTR<thistype> Create(Args&&... args)					\
	{ return std::make_shared<thistype>(args...); }												\
	private:																					\

#define COMPONENT_CREATE_AS_BASE_DECLARATION(thistype)											\
	public:																						\
	template<typename... Args> static SHD_PTR<Base> CreateB(Args&&... args)						\
	{ auto pt = std::make_shared<thistype>(args...); pt->AddToSystem(); return pt; }			\
	private:

// In the .h
#define COMPONENT_CREATE_DECLARATION(thistype)													\
	public:																						\
	template<typename... Args> static SHD_PTR<thistype> Create(Args&&... args)					\
	{ auto pt = std::make_shared<thistype>(args...); pt->AddToSystem(); return pt; }			\
	private:																					\

// In the .h
// Requires to be derived from Base
#define COMPONENT_DECLARATION(thistype)															\
	RTTI_DECLARATION(thistype)																	\
	COMPONENT_CREATE_DECLARATION(thistype)														\
	NON_COPYABLE(thistype)	

#define COMPONENT_SERIALIZABLE_DECLARATION(thistype)											\
	COMPONENT_DECLARATION(thistype)																\
	COMPONENT_CREATE_AS_BASE_DECLARATION(thistype)

#define SERIALIZABLE_DECLARATION(thistype)														\
	RTTI_DECLARATION(thistype)																	\
	CREATE_AS_BASE_DECLARATION(thistype)


																	

