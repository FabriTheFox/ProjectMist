#pragma once

#include <vector>
#include "DataTypes.h"

namespace Utilities
{
	template<typename T>
	void DeleteMatches(std::vector<T>& Alive, std::vector<T>& Dead)
	{
		for (T& deadobj : Dead)
		{
			*std::find(Alive.begin(), Alive.end(), deadobj) = Alive.back();
			Alive.pop_back();
		}
	}

	int Random(int min, int max);
	float Random(float min, float max);
	float LERP(float a, float b, float f);
	Vec3 LERP(const Vec3& a, const Vec3& b, float f);
	Vec4 LERP(const Vec4& a, const Vec4& b, float f);
	FTE_Quat::FTEQuat LERP(const FTE_Quat::FTEQuat& a, const FTE_Quat::FTEQuat& b, float f);

	float Clamp(const float& val, const float& min, const float& max);
	IVec2 WorldToScreenCoords(const Vec3& pos, const Mat4& trans, const IVec2& resolution);

	std::string GetDate();
	void RemoveCharFromString(std::string& s, const char& c);
	std::string GetFileExtension(const std::string& str);
	std::string GetFileName(const std::string& str);
	time_t GetFileWritingTime(const std::string& file);
	std::string AppendID(const std::string& n, const int& id);
	std::vector<std::string> GetIndividualPaths(const std::string& path);

	struct Timer
	{
		void Start();
		void Update();
		void Reset();

		unsigned GetMilliseconds();
		float GetSeconds();
		float GetMinutes();
		float GetHours();
		float GetDays();

		std::string GetTime_DaysHoursMinutesSecondsMillisecs(bool d = true, bool h = true, bool m = true, bool s = true, bool ms = true);

		unsigned mTime{0};
	private:
		unsigned mStartTime{0};
	};
}



