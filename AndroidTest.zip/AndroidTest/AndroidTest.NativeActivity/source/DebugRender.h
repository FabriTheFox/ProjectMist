#pragma once

#include "Model.h"
#include <string>
#include "Layer.h"

class Layer;
class Camera;

class DebugRender
{
public:
	DebugRender(Layer& layer, const Vec4& color);
	void operator= (const DebugRender&) = delete;

	virtual void Render() = 0;
protected:
	Layer& mLayer;
	Camera& mCamera;
	Vec4 mColor;
};

class DebugLine : public DebugRender
{
public:
	DebugLine(Layer& layer, const Vec4& color, const Vec3& start, const Vec3& end, const float& width);
	void Render() override;
private:
	Vec3 mStart;
	Vec3 mEnd;
	float mWidth;
};

class DebugScreenLine : public DebugRender
{
public:
	DebugScreenLine(Layer& layer, const Vec4& color, const Vec2& start, const Vec2& end, const float& width);
	void Render() override;
private:
	Vec2 mStart;
	Vec2 mEnd;
	float mWidth;
};

class DebugScreenQuad : public DebugRender
{
public:
	DebugScreenQuad(Layer& layer, const Vec4& color, Texture& tex);
	void Render() override;
private:
	Texture& mTexture;
};

class DebugScreenTRQuad : public DebugRender
{
public:
	DebugScreenTRQuad(Layer& layer, const Transform& tr, const Vec4& color, Texture& tex);
	void Render() override;
private:
	Texture& mTexture;
	Transform mTransform;
};

class DebugWireCube : public DebugRender
{
public:
	DebugWireCube(Layer& layer, const Transform& tr, const Vec4& color, const float& width);
	void Render() override;
private:
	Transform mTransform;
	float mWidth;
};

class DebugPoint : public DebugRender
{
public:
	DebugPoint(Layer& layer, const Vec3& pos, const Vec4& color, const float& size);
	void Render() override;
private:
	Vec3 mPos;
	float mSize;
};