#pragma once

#include "Importer.h"

class Importer_Texture : public Importer
{
public:
	IMPORTER_DECLARATION(Importer_Texture)
	void Import(const std::string& name, const std::string& path) override;
private:
};