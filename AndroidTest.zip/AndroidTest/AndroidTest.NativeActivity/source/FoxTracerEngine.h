#pragma once

#include <string>
#include <unordered_map>
#include <map>

#include "System.h"
#include "DisplayModule.h"
#include "RTTI.h"

#include "FTE_Config.h"

typedef void(*GlobalFP)();

class FoxTracerEngine
{
	friend class SceneSystem;
	friend class Serializer;
	friend class EditorSystem;

public:
	static DisplayModule Display_;

	template <typename T>
	static T& GetSystem()
	{
		return *SHD_CAST(T)(Systems_.at(T::RTTI_.mTypehash));
	}

	static void ShutdownAllSystems();

	static void Initialize();
	static void Terminate();
	static void Run();

	static void AddLevel(const std::string& name, GlobalFP init = nullptr, GlobalFP run = nullptr, GlobalFP terminate = nullptr);
	static void SetLevel(const std::string& name);

	template <typename T>
	static RTTI& RegisterRTTI(create_func createfn)
	{
		auto hash = typeid(T).hash_code();
		auto str = typeid(T).name();
		GetRTTIs()[str] = { str, hash, createfn };
		GetRegisterPropertyFunctions().push_back(&T::RegisterProperties);
		return GetRTTIs()[str];
	}

	static std::unordered_map<std::string, RTTI>& GetRTTIs();

private:
	static void UpdateAllSystems();
	static void UpdateDebugOfAllSystems();
	static void UpdateCurrentLevel();
	static void Clean();

	template <typename T>
	static void RegisterSystemOrdered()
	{
		auto ptr = std::make_shared<T>();
		Systems_[T::RTTI_.mTypehash] = ptr;
		SystemVec_.push_back(ptr);
	}

	static std::vector<GlobalFP>& GetRegisterPropertyFunctions();
	static std::map<size_t, SHD_PTR<System>> Systems_;
	static std::vector<SHD_PTR<System>> SystemVec_;
};