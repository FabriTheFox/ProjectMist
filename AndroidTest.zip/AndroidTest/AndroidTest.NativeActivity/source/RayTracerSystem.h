#pragma once

#include "DataTypes.h"
#include <vector>
#include "Texture.h"
#include "System.h"
#include "RenderJob.h"

class Layer;
class Camera;
class RenderJob;

class RayTracerSystem : public System
{
	RTTI_DECLARATION(RayTracerSystem)

public:
	void Initialize() override;
	void Update() override;
	void ShowDebug() override;

	bool IsRendering();
	bool HasRenderJobs();

	void PauseRender(bool pause);
	void CancelRender();

private:
	void RenderLayer(const std::string& layer);
	void RenderImage();
	void CleanRenderJobs();

	void UpdateRenderJobs();
	RenderJob& GetCurrentRenderJob();

	void ShowGUIWindow(bool& open);
	void ShowPhotonMappingProgress();
	void ShowIrradianceCachingProgress();
	void ShowRenderProgress();

	std::vector<SHD_PTR<RenderJob>> mRenderJobs;
	unsigned mCurrentRenderJob{ 0 };

	bool mShowRender{false};
	bool mIsRendering{false};
	bool mIsPaused{ false };

	//Texture mTexture;
};