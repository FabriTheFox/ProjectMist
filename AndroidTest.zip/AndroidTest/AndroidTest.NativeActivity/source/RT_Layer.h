#pragma once

#include "RT_Renderer.h"
#include "RT_Light.h"
#include "RT_PhotonMap.h"
#include "RT_IrradianceCache.h"
#include "Camera.h"
#include <vector>
#include <thread>

class Layer;

class RT_Layer
{
	NON_COPYABLE(RT_Layer)

public:
	enum GI_method
	{
		NONE,
		MONTE_CARLO,
		PHOTON_MAP
	};

	RT_Layer() = default;

	void Initialize(Layer& layer);

	FTEIntersection::IntersectionResult TraceRay(const Vec3& start, const Vec3& dir, RT_Renderer::RenderData& data);
	FTEIntersection::IntersectionResult TraceShadowRay(const Vec3& start, const Vec3& dir, RT_Renderer::RenderData& data);

	Vec4 ComputeColor(const Vec3& start, const Vec3& dir, const Vec4 background, RT_Renderer::RenderData& data);
	Vec4 ComputeGI(const Vec3& start, const Vec3& dir, RT_Renderer::RenderData& data);
	Vec3 ComputeGIAt(FTEIntersection::IntersectionResult& at);

	Vec4 ComputeColorAt(FTEIntersection::IntersectionResult&, RT_Renderer::RenderData& data);
	Vec4 ComputeColorAndDis(const Vec3& start, const Vec3& dir, const Vec4 background, float& dis, RT_Renderer::RenderData& data);

	void EmitPhoton(RT_PhotonMap& map, RT_PhotonMap::PhotonData& photon, const Vec3& start, const Vec3& dir, RT_Renderer::RenderData& data);

	std::vector<RT_Renderer> mRenderers;
	std::vector<RT_Light> mLights;

	Camera* mpCamera;

	RT_PhotonMap mPhotonMap;
	RT_IrradianceCache mIrradianceCache;

	GI_method mGIMethod;
	bool mIrradianceCacheEnabled;
	unsigned mMontecarloSamples;
	bool mScatterGather;
	unsigned mGatherSamples;
};