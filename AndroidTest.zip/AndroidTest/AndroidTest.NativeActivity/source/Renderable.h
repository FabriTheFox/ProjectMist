#pragma once

#include "Component.h"
#include "Model.h"
#include "Intersection.h"
#include "RT_Renderable.h"
#include <string>

class Renderable : 
	public Component,
	public std::enable_shared_from_this<Renderable>
{
	COMPONENT_SERIALIZABLE_DECLARATION(Renderable)

public:
	Renderable(const std::string& layer = "World", const std::string& renderer = "BasicRenderer") : mLayer(layer), mRenderer(renderer){}
	void AddToSystem() override;
	void RemoveFromSystem() override;

	const std::string& GetLayer();
	const std::string& GetRenderer();

	void SetModel(const std::string& name);
	Model& GetModel();

	bool CastsShadow();
	void SetCastShadow(bool cast);

	bool IsVisible();
	void SetVisible(bool visible);

	void SetRenderer(const std::string& name);

	const Vec4& GetModulationColor();
	void SetModulationColor(const Vec4& color);

	void Load(SerDataPack& data) override;

	// Ray tracing ==============================
	void FillRTData(RT_Renderable& renderable);
	std::vector<FTEIntersection::Triangle>& UpdateTransformedVertices();

private:
	Vec4 mModulationColor{1, 1, 1, 1};
	std::string mLayer;
	std::string mRenderer;

	std::string mModel;
	WK_PTR<Model> mpModel;

	// flags
	bool mCastsShadow{true};
	bool mVisible{ true };

	// Ray tracing ==============================
	std::vector<FTEIntersection::Triangle> mTransformedVertices;
};