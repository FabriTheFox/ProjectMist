/*
* Copyright (C) 2010 The Android Open Source Project
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*      http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*
*/

#define LOGI(...) ((void)__android_log_print(ANDROID_LOG_INFO, "AndroidProject1.NativeActivity", __VA_ARGS__))
#define LOGW(...) ((void)__android_log_print(ANDROID_LOG_WARN, "AndroidProject1.NativeActivity", __VA_ARGS__))

#include "source/Shader.h"
#include "source/Model.h"
#include "source/Transform.h"

#include "source/NkGLES.h"

/**
* Our saved state data.
*/
struct saved_state {
	float angle;
	int32_t x;
	int32_t y;
};

/**
* Shared state for our app.
*/
struct engine {
	struct android_app* app;

	ASensorManager* sensorManager;
	const ASensor* accelerometerSensor;
	ASensorEventQueue* sensorEventQueue;

	int animating;
	EGLDisplay display;
	EGLSurface surface;
	EGLContext context;
	int32_t width;
	int32_t height;
	struct saved_state state;

    NkGLES *nk;
};

GLuint Camtexture;

std::string frag =
"#version 320 es"
"\n #extension GL_OES_EGL_image_external_essl3 : require"
"\n in highp vec2 fr_Texcoord;"
"\n in highp vec3 fr_Position;"
"\n in highp vec3 fr_Normal;"
"\n "
"\n layout(location = 0) out highp vec4 albedo;"
"\n "
"\n uniform highp vec4 modulation_color;"
"\n layout(binding = 0) uniform samplerExternalOES sampler;"
"\n "
"\n void main()"
"\n {"
"\n     albedo = texture(sampler, fr_Texcoord);"
"\n     //albedo = vec4(fr_Texcoord, 0, 1);"
"\n     //albedo = vec4(modulation_color.xyz, 1);"
"\n }";

std::string vert =
"#version 320 es"
"\n in highp vec3 vt_Position;"
"\n in highp vec2 vt_Texcoord;"
"\n in highp vec3 vt_Normal;"
"\n "
"\n out highp vec2 fr_Texcoord;"
"\n out highp vec3 fr_Position;"
"\n out highp vec3 fr_Normal;"
"\n "
"\n uniform highp mat4 MV;"
"\n uniform highp mat4 ViewSpace;"
"\n "
"\n void main()"
"\n {"
"\n     fr_Position = vec3(ViewSpace * vec4(vt_Position, 1.0));"
"\n     fr_Normal = normalize(mat3(transpose(inverse(ViewSpace))) * vt_Normal);"
"\n     fr_Texcoord = vt_Texcoord;"
"\n     gl_Position = MV * vec4(vt_Position, 1.0);"
"\n }";

Shader sh;
Mesh quad;
Mesh circle;

void CreateQuad()
{
    std::vector<Vertex> vertices;
    std::vector<unsigned> indices;
    vertices.push_back({ { +0.5f, +0.5f, 0 },{ 1, 1 },{ 0, 0, 1 } });
    vertices.push_back({ { -0.5f, +0.5f, 0 },{ 0, 1 },{ 0, 0, 1 } });
    vertices.push_back({ { -0.5f, -0.5f, 0 },{ 0, 0 },{ 0, 0, 1 } });
    vertices.push_back({ { +0.5f, -0.5f, 0 },{ 1, 0 },{ 0, 0, 1 } });

    indices.push_back(0);
    indices.push_back(1);
    indices.push_back(2);

    indices.push_back(0);
    indices.push_back(2);
    indices.push_back(3);

    quad.UploadToGpu(vertices, indices);
}

void CreateCircle()
{
    std::vector<Vertex> vertices;
    std::vector<unsigned> indices;

    vertices.push_back({ { 0, 0, 0 },{ 1, 1 },{ 0, 0, 1 } });
    vertices.push_back({ { 1, 0, 0 },{ 1, 1 },{ 0, 0, 1 } });

    unsigned step = 360.f / 35.f;
    unsigned index = 0;
    for (float a = step; a < 360.f; a += step, ++index)
    {
        float x = glm::cos(glm::radians(a));
        float y = glm::sin(glm::radians(a));
        vertices.push_back({ { x, y, 0 },{ 0, 1 },{ 0, 0, 1 } });

        indices.push_back(0);
        indices.push_back(index + 1);
        indices.push_back(index + 2);
    }

    indices.push_back(0);
    indices.push_back(index + 1);
    indices.push_back(1);

    circle.UploadToGpu(vertices, indices);
}

struct Ball
{
    Vec2 position;
    float radius;
    Vec2 direction;
    float speed;
    bool dead = false;
};

std::vector<Ball> balls;

float aspectratio = 16.f / 9.f;
float left = -0.5f;
float right = 0.5f;
float bottom = -0.5 * aspectratio;
float top = 0.5 * aspectratio;

#include "camera/native-lib.h"

/**
* Initialize an EGL context for the current display.
*/
static int engine_init_display(struct engine* engine) {
	// initialize OpenGL ES and EGL

	/*
	* Here specify the attributes of the desired configuration.
	* Below, we select an EGLConfig with at least 8 bits per color
	* component compatible with on-screen windows
	*/
	const EGLint attribs[] = {
		EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
		EGL_BLUE_SIZE, 8,
		EGL_GREEN_SIZE, 8,
		EGL_RED_SIZE, 8,
		EGL_NONE
	};
	EGLint w, h, format;
	EGLint numConfigs;
	EGLConfig config;
	EGLSurface surface;
	EGLContext context;

	EGLDisplay display = eglGetDisplay(EGL_DEFAULT_DISPLAY);

	eglInitialize(display, 0, 0);

	/* Here, the application chooses the configuration it desires. In this
	* sample, we have a very simplified selection process, where we pick
	* the first EGLConfig that matches our criteria */
	eglChooseConfig(display, attribs, &config, 1, &numConfigs);

	/* EGL_NATIVE_VISUAL_ID is an attribute of the EGLConfig that is
	* guaranteed to be accepted by ANativeWindow_setBuffersGeometry().
	* As soon as we picked a EGLConfig, we can safely reconfigure the
	* ANativeWindow buffers to match, using EGL_NATIVE_VISUAL_ID. */
	eglGetConfigAttrib(display, config, EGL_NATIVE_VISUAL_ID, &format);

	ANativeWindow_setBuffersGeometry(engine->app->window, 0, 0, format);

	surface = eglCreateWindowSurface(display, config, engine->app->window, NULL);

    EGLint contextAttribs[] =
    { 
        EGL_CONTEXT_CLIENT_VERSION, 3, // Specifies OpenGL ES 3.2.
        EGL_NONE
    };

	context = eglCreateContext(display, config, NULL, contextAttribs);

	if (eglMakeCurrent(display, surface, surface, context) == EGL_FALSE) {
		LOGW("Unable to eglMakeCurrent");
		return -1;
	}

	eglQuerySurface(display, surface, EGL_WIDTH, &w);
	eglQuerySurface(display, surface, EGL_HEIGHT, &h);

	engine->display = display;
	engine->context = context;
	engine->surface = surface;
	engine->width = w;
	engine->height = h;
	engine->state.angle = 0;
    
    //AAssetManager* aa;
    //AAsset* asset = AAssetManager_open(aa, "test.jpg", 1);

    

	// Initialize GL state.
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_FASTEST);
	glEnable(GL_CULL_FACE);
	//glShadeModel(GL_SMOOTH);
	glDisable(GL_DEPTH_TEST);

    sh.CreateProgram(vert, frag);
    CreateQuad();
    CreateCircle();

    balls.push_back({});
    auto& b = balls.back();

    b.direction = { 0.5f, 0.5f };
    b.radius = 0.1f;
    b.speed = 0.1f;

    engine->nk = new NkGLES(engine->display, engine->surface, MAX_VERTEX_MEMORY, MAX_ELEMENT_MEMORY);

    Asur

    glGenTextures(1, &Camtexture);
    glBindTexture(GL_TEXTURE_EXTERNAL_OES, Camtexture);

    initCam();
    initSurface(Camtexture, engine->app->window);

	return 0;
}

void UpdatePosition(Ball& ball, float dt)
{
    ball.position += ball.direction * ball.speed * dt;
}

void ResolveCollisions(Ball& ball)
{
    Vec2& pos = ball.position;
    float& radius = ball.radius;

    if (glm::abs(pos.x - left) <= radius)
        ball.direction = glm::reflect(ball.direction, { 1, 0 });
    if (glm::abs(pos.x - right) <= radius)
        ball.direction = glm::reflect(ball.direction, { -1, 0 });
    if (glm::abs(pos.y - bottom) <= radius)
        ball.direction = glm::reflect(ball.direction, { 0, 1 });
    if (glm::abs(pos.y - top) <= radius)
        ball.direction = glm::reflect(ball.direction, { 0, -1 });

    for (auto& other : balls)
    {
        if (other.position == ball.position)
            continue;

        if (glm::distance(ball.position, other.position) <= ball.radius + other.radius)
        {
            //float m1 = ball.radius * ball.radius;
            //float m2 = other.radius * other.radius;

            if (ball.radius < other.radius)
            {
                other.radius += glm::sqrt(ball.radius);
                ball.dead = true;
            }
            else
            {
                ball.radius += glm::sqrt(other.radius);
                other.dead = true;
            }

            //Vec2 n = glm::normalize(other.position - ball.position);
            //
            //float a1 = glm::dot(ball.direction, n);
            //float a2 = glm::dot(other.direction, n);
            //
            //float p = (2.0 * (a1 - a2)) / (m1 + m2);
            //
            //Vec2 v1 = ball.direction - p * m2 * n;
            //Vec2 v2 = other.direction + p * m1 * n;
            //
            //ball.direction = glm::normalize(v1);
            //ball.speed = glm::length(v1);
        }
    }
}

Transform tr;
float speed = 0.1f;

bool buttondown = false;

#include <iostream>

void RotatingQuad()
{
    if (buttondown)
    {
        speed += 0.05f;
        if (speed > 15)
            speed = 15;
    }
    else
    {
        speed -= 0.2f;
        if (speed < 0)
            speed = 0.f;
    }

    tr.mRotation.z += speed;
    tr.mScale = Vec3{ speed / 15.f };
}

void CreateNewBall(struct engine* engine)
{
    static bool donwbefore = false;
    static Vec2 initialpos;
    static unsigned framecount = 0;

    float xx = (float(engine->state.x) / float(engine->width)) - 0.5f;
    float yy = 0.5f - (float(engine->state.y) / float(engine->height));

    tr.mPosition.x = xx;
    tr.mPosition.y = yy * aspectratio;

    if (buttondown)
    {
        ++framecount;

        if (!donwbefore)
        {
            framecount = 0;
            initialpos = { xx, yy };

            balls.push_back({});
            auto& b = balls.back();

            b.direction = { 0.5f, 0.5f };
            b.radius = 0.05f;
            b.direction = { 0, 0};
        }
        
        if (framecount >= 30)
        {
            initialpos = { xx, yy };
        }

        auto& b = balls.back();
        b.radius += 0.001f;

        if (b.radius >= 0.2f)
            b.radius = 0.3f;

        b.position = { xx, yy};
    }

    if (!buttondown)
    {
        if (donwbefore)
        {
            auto& b = balls.back();
            Vec2 dir = Vec2{ xx, yy } - initialpos;

            b.speed = glm::length(dir);
            b.direction = glm::normalize(dir);
        }
    }

    donwbefore = buttondown;
}

/**
* Just the current frame in the display.
*/
static void engine_draw_frame(struct engine* engine) {
	if (engine->display == NULL) {
		// No display.
		return;
	}
    glClearColor(1.f, 1.f, 1.f, 1.f);
    glClear(GL_COLOR_BUFFER_BIT);
    
    for (unsigned i = 0; i < balls.size(); ++i)
    {
        auto& b = balls[i];

        ResolveCollisions(b);
        UpdatePosition(b, 0.016f);

        if (b.dead)
        {
            b = balls.back();
            balls.pop_back();
        }
    }

    CreateNewBall(engine);

    glDisable(GL_DEPTH_TEST);
    glDepthMask(0);

    Mat4 proj = glm::ortho(left, right, bottom, top);
    sh.Bind();

    for (auto& b : balls)
    {
        Transform camera;
        camera.mScale = {1.f, 1.f, 1};

        Transform trs;
        trs.mPosition = Vec3{ b.position, 0.f };
        trs.mScale = {b.radius, b.radius, 1.f};

        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_EXTERNAL_OES, Camtexture);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

        glUniform1i(0, 0);

        sh.SetUniformMat4("MV", proj * camera.GetModelMatrix() * trs.GetModelMatrix());
        sh.SetUniformVec4("modulation_color", { 1, 0, 0, 1 });
        quad.Draw(GL_TRIANGLES);
    }

    /* GUI */
#if 0
    nk_context *ctx = &engine->nk->ctx;
    if (nk_begin(ctx, "Demo", nk_rect(50, 200, 500, 500),
        NK_WINDOW_BORDER | NK_WINDOW_MOVABLE | NK_WINDOW_SCALABLE |
        NK_WINDOW_CLOSABLE | NK_WINDOW_MINIMIZABLE | NK_WINDOW_TITLE))
    {
        struct nk_rect b = ctx->begin->bounds;
        struct nk_vec2 p = ctx->input.mouse.pos;

        /*nk_menubar_begin(ctx);
        nk_layout_row_begin(ctx, NK_STATIC, 25, 2);
        nk_layout_row_push(ctx, 45);
        if (nk_menu_begin_label(ctx, "FILE", NK_TEXT_LEFT, nk_vec2(120, 200))) {
            nk_layout_row_dynamic(ctx, 30, 1);
            nk_menu_item_label(ctx, "OPEN", NK_TEXT_LEFT);
            nk_menu_item_label(ctx, "CLOSE", NK_TEXT_LEFT);
            nk_menu_end(ctx);
        }
        nk_layout_row_push(ctx, 45);
        if (nk_menu_begin_label(ctx, "EDIT", NK_TEXT_LEFT, nk_vec2(120, 200))) {
            nk_layout_row_dynamic(ctx, 30, 1);
            nk_menu_item_label(ctx, "COPY", NK_TEXT_LEFT);
            nk_menu_item_label(ctx, "CUT", NK_TEXT_LEFT);
            nk_menu_item_label(ctx, "PASTE", NK_TEXT_LEFT);
            nk_menu_end(ctx);
        }
        nk_layout_row_end(ctx);
        nk_menubar_end(ctx);*/
        
        enum { EASY, HARD };
        static int op = EASY;
        static int property = 20;
        nk_layout_row_static(ctx, 30, 80, 1);
            
        char buf[128];
        nk_button_label(ctx, nk_itoa(buf, engine->state.x));
        nk_button_label(ctx, nk_itoa(buf, engine->state.y));
        nk_button_label(ctx, nk_itoa(buf, b.x));
        nk_button_label(ctx, nk_itoa(buf, b.y));
        nk_button_label(ctx, nk_itoa(buf, p.x));
        nk_button_label(ctx, nk_itoa(buf, p.y));
        /*nk_layout_row_dynamic(ctx, 40, 2);
        if (nk_option_label(ctx, "easy", op == EASY)) op = EASY;
        if (nk_option_label(ctx, "hard", op == HARD)) op = HARD;
        nk_layout_row_dynamic(ctx, 25, 1);
        nk_property_int(ctx, "Compression:", 0, &property, 100, 10, 1);*/
    }
    nk_end(ctx);

    engine->nk->Render(NK_ANTI_ALIASING_ON);
#endif

	eglSwapBuffers(engine->display, engine->surface);
}

/**
* Tear down the EGL context currently associated with the display.
*/
static void engine_term_display(struct engine* engine) {
	if (engine->display != EGL_NO_DISPLAY) {
		eglMakeCurrent(engine->display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
		if (engine->context != EGL_NO_CONTEXT) {
			eglDestroyContext(engine->display, engine->context);
		}
		if (engine->surface != EGL_NO_SURFACE) {
			eglDestroySurface(engine->display, engine->surface);
		}
		eglTerminate(engine->display);
	}
	engine->animating = 0;
	engine->display = EGL_NO_DISPLAY;
	engine->context = EGL_NO_CONTEXT;
	engine->surface = EGL_NO_SURFACE;

    delete engine->nk;
}

/**
* Process the next input event.
*/
static int32_t engine_handle_input(struct android_app* app, AInputEvent* e) {
	//struct engine* engine = (struct engine*)app->userData;
	//if (AInputEvent_getType(event) == AINPUT_EVENT_TYPE_MOTION) {
	//	engine->state.x = AMotionEvent_getX(event, 0);
	//	engine->state.y = AMotionEvent_getY(event, 0);
	//	return 1;
	//}
	//return 0;

    engine* eng = (engine*)app->userData;
    switch (AInputEvent_getType(e)) {
    case AINPUT_EVENT_TYPE_MOTION: { // Touch event
        eng->state.x = AMotionEvent_getX(e, 0);
        eng->state.y = AMotionEvent_getY(e, 0);
        float x = AMotionEvent_getX(e, 0);
        float y = AMotionEvent_getY(e, 0);

        nk_context *ctx = &eng->nk->ctx;
        nk_input_begin(ctx);
        switch (AMotionEvent_getAction(e) & AMOTION_EVENT_ACTION_MASK) {
        case AMOTION_EVENT_ACTION_DOWN: // WM_LBUTTONDOWN
            ctx->input.mouse.pos = nk_vec2(x, y);
            buttondown = true;
            nk_input_button(ctx, NK_BUTTON_LEFT, x, y, true);
            break;
        case AMOTION_EVENT_ACTION_UP: // WM_LBUTTONUP
            ctx->input.mouse.pos = nk_vec2(0, 0);
            buttondown = false;
            nk_input_button(ctx, NK_BUTTON_LEFT, x, y, false);
            break;
        case AMOTION_EVENT_ACTION_MOVE: // WM_MOUSEMOVE
            nk_input_motion(ctx, x, y);
            break;
        }
        nk_input_end(ctx);
    } return 1;
    case AINPUT_EVENT_TYPE_KEY:
        break;
    }
    return 0;
}

/**
* Process the next main command.
*/
static void engine_handle_cmd(struct android_app* app, int32_t cmd) {
	struct engine* engine = (struct engine*)app->userData;
	switch (cmd) {
	case APP_CMD_SAVE_STATE:
		// The system has asked us to save our current state.  Do so.
		engine->app->savedState = malloc(sizeof(struct saved_state));
		*((struct saved_state*)engine->app->savedState) = engine->state;
		engine->app->savedStateSize = sizeof(struct saved_state);
		break;
	case APP_CMD_INIT_WINDOW:
		// The window is being shown, get it ready.
		if (engine->app->window != NULL) {
			engine_init_display(engine);
			engine_draw_frame(engine);
		}
		break;
	case APP_CMD_TERM_WINDOW:
		// The window is being hidden or closed, clean it up.
		engine_term_display(engine);
		break;
	case APP_CMD_GAINED_FOCUS:
		// When our app gains focus, we start monitoring the accelerometer.
		if (engine->accelerometerSensor != NULL) {
			ASensorEventQueue_enableSensor(engine->sensorEventQueue,
				engine->accelerometerSensor);
			// We'd like to get 60 events per second (in us).
			ASensorEventQueue_setEventRate(engine->sensorEventQueue,
				engine->accelerometerSensor, (1000L / 60) * 1000);
		}
		break;
	case APP_CMD_LOST_FOCUS:
		// When our app loses focus, we stop monitoring the accelerometer.
		// This is to avoid consuming battery while not being used.
		if (engine->accelerometerSensor != NULL) {
			ASensorEventQueue_disableSensor(engine->sensorEventQueue,
				engine->accelerometerSensor);
		}
		// Also stop animating.
		engine->animating = 0;
		engine_draw_frame(engine);
		break;
	}
}

/**
* This is the main entry point of a native application that is using
* android_native_app_glue.  It runs in its own thread, with its own
* event loop for receiving input events and doing other things.
*/
void android_main(struct android_app* state) {
	struct engine engine;

	memset(&engine, 0, sizeof(engine));
	state->userData = &engine;
	state->onAppCmd = engine_handle_cmd;
	state->onInputEvent = engine_handle_input;
	engine.app = state;

	// Prepare to monitor accelerometer
	engine.sensorManager = ASensorManager_getInstance();
	engine.accelerometerSensor = ASensorManager_getDefaultSensor(engine.sensorManager,
		ASENSOR_TYPE_ACCELEROMETER);
	engine.sensorEventQueue = ASensorManager_createEventQueue(engine.sensorManager,
		state->looper, LOOPER_ID_USER, NULL, NULL);

	if (state->savedState != NULL) {
		// We are starting with a previous saved state; restore from it.
		engine.state = *(struct saved_state*)state->savedState;
	}

	engine.animating = 1;

	// loop waiting for stuff to do.

	while (1) {
		// Read all pending events.
		int ident;
		int events;
		struct android_poll_source* source;

		// If not animating, we will block forever waiting for events.
		// If animating, we loop until all events are read, then continue
		// to draw the next frame of animation.
		while ((ident = ALooper_pollAll(engine.animating ? 0 : -1, NULL, &events,
			(void**)&source)) >= 0) {

			// Process this event.
			if (source != NULL) {
				source->process(state, source);
			}

			// If a sensor has data, process it now.
			if (ident == LOOPER_ID_USER) {
				if (engine.accelerometerSensor != NULL) {
					ASensorEvent event;
					while (ASensorEventQueue_getEvents(engine.sensorEventQueue,
						&event, 1) > 0) {
						LOGI("accelerometer: x=%f y=%f z=%f",
							event.acceleration.x, event.acceleration.y,
							event.acceleration.z);
					}
				}
			}

			// Check if we are exiting.
			if (state->destroyRequested != 0) {
				engine_term_display(&engine);
				return;
			}
		}

		if (engine.animating) {
			// Done with events; draw next animation frame.
			engine.state.angle += .01f;
			if (engine.state.angle > 1) {
				engine.state.angle = 0;
			}

			// Drawing is throttled to the screen update rate, so there
			// is no need to do timing here.
			engine_draw_frame(&engine);
		}
	}
}
