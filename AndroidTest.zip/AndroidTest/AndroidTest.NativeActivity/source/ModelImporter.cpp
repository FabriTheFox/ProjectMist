#include <iostream>
#include "DebugSystem.h"
#include "Model.h"

#include "FBX_SDK.h"

#define USE_FBX_IMPORTER

#ifdef  USE_FBX_IMPORTER

// ==========================================================================================================================

void DisplayAnimation(FbxAnimStack* pAnimStack, FbxNode* pNode, bool isSwitcher = false);
void DisplayAnimation(FbxAnimLayer* pAnimLayer, FbxNode* pNode, bool isSwitcher = false);
void DisplayChannels(FbxNode* pNode, FbxAnimLayer* pAnimLayer, void(*DisplayCurve) (FbxAnimCurve* pCurve), void(*DisplayListCurve) (FbxAnimCurve* pCurve, FbxProperty* pProperty), bool isSwitcher);
void DisplayCurveKeys(FbxAnimCurve* pCurve);
void DisplayListCurveKeys(FbxAnimCurve* pCurve, FbxProperty* pProperty);

void DisplayAnimation(FbxScene* pScene)
{
	int i;
	for (i = 0; i < pScene->GetSrcObjectCount<FbxAnimStack>(); i++)
	{
		FbxAnimStack* lAnimStack = pScene->GetSrcObject<FbxAnimStack>(i);

		std::string lOutputString = "Animation Stack Name: ";
		lOutputString += lAnimStack->GetName();
		lOutputString += "\n\n";
		std::cout << lOutputString << std::endl;

		DisplayAnimation(lAnimStack, pScene->GetRootNode(), true);
		DisplayAnimation(lAnimStack, pScene->GetRootNode());
	}
}

void DisplayAnimation(FbxAnimStack* pAnimStack, FbxNode* pNode, bool isSwitcher)
{
	int l;
	int nbAnimLayers = pAnimStack->GetMemberCount<FbxAnimLayer>();

	std::string lOutputString;
	lOutputString = "Animation stack contains ";
	lOutputString += std::to_string(nbAnimLayers);
	lOutputString += " Animation Layer(s)\n";

	std::cout << lOutputString << std::endl;

	for (l = 0; l < nbAnimLayers; l++)
	{
		FbxAnimLayer* lAnimLayer = pAnimStack->GetMember<FbxAnimLayer>(l);

		lOutputString = "AnimLayer ";
		lOutputString += std::to_string(l);
		lOutputString += "\n";
		std::cout << lOutputString << std::endl;

		DisplayAnimation(lAnimLayer, pNode, isSwitcher);
	}
}

void DisplayAnimation(FbxAnimLayer* pAnimLayer, FbxNode* pNode, bool isSwitcher)
{
	int lModelCount;
	std::string lOutputString;

	lOutputString = "     Node Name: ";
	lOutputString += pNode->GetName();
	lOutputString += "\n\n";
	std::cout << lOutputString << std::endl;

	DisplayChannels(pNode, pAnimLayer, DisplayCurveKeys, DisplayListCurveKeys, isSwitcher);

	for (lModelCount = 0; lModelCount < pNode->GetChildCount(); lModelCount++)
	{
		DisplayAnimation(pAnimLayer, pNode->GetChild(lModelCount), isSwitcher);
	}
}

void DisplayChannels(FbxNode* pNode, FbxAnimLayer* pAnimLayer, void(*DisplayCurve) (FbxAnimCurve* pCurve), void(*DisplayListCurve) (FbxAnimCurve* pCurve, FbxProperty* pProperty), bool isSwitcher)
{
	FbxAnimCurve* lAnimCurve = NULL;

	// Display general curves.
	if (!isSwitcher)
	{

		lAnimCurve = pNode->LclTranslation.GetCurve(pAnimLayer, FBXSDK_CURVENODE_COMPONENT_X);
		if (lAnimCurve)
		{
			FBXSDK_printf("        TX\n");
			DisplayCurve(lAnimCurve);
		}
		lAnimCurve = pNode->LclTranslation.GetCurve(pAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y);
		if (lAnimCurve)
		{
			FBXSDK_printf("        TY\n");
			DisplayCurve(lAnimCurve);
		}
		lAnimCurve = pNode->LclTranslation.GetCurve(pAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z);
		if (lAnimCurve)
		{
			FBXSDK_printf("        TZ\n");
			DisplayCurve(lAnimCurve);
		}

		lAnimCurve = pNode->LclRotation.GetCurve(pAnimLayer, FBXSDK_CURVENODE_COMPONENT_X);
		if (lAnimCurve)
		{
			FBXSDK_printf("        RX\n");
			DisplayCurve(lAnimCurve);
		}
		lAnimCurve = pNode->LclRotation.GetCurve(pAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y);
		if (lAnimCurve)
		{
			FBXSDK_printf("        RY\n");
			DisplayCurve(lAnimCurve);
		}
		lAnimCurve = pNode->LclRotation.GetCurve(pAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z);
		if (lAnimCurve)
		{
			FBXSDK_printf("        RZ\n");
			DisplayCurve(lAnimCurve);
		}

		lAnimCurve = pNode->LclScaling.GetCurve(pAnimLayer, FBXSDK_CURVENODE_COMPONENT_X);
		if (lAnimCurve)
		{
			FBXSDK_printf("        SX\n");
			DisplayCurve(lAnimCurve);
		}
		lAnimCurve = pNode->LclScaling.GetCurve(pAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y);
		if (lAnimCurve)
		{
			FBXSDK_printf("        SY\n");
			DisplayCurve(lAnimCurve);
		}
		lAnimCurve = pNode->LclScaling.GetCurve(pAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z);
		if (lAnimCurve)
		{
			FBXSDK_printf("        SZ\n");
			DisplayCurve(lAnimCurve);
		}
	}

	// Display curves specific to a light or marker.
	FbxNodeAttribute* lNodeAttribute = pNode->GetNodeAttribute();

	if (lNodeAttribute)
	{
		lAnimCurve = lNodeAttribute->Color.GetCurve(pAnimLayer, FBXSDK_CURVENODE_COLOR_RED);
		if (lAnimCurve)
		{
			FBXSDK_printf("        Red\n");
			DisplayCurve(lAnimCurve);
		}
		lAnimCurve = lNodeAttribute->Color.GetCurve(pAnimLayer, FBXSDK_CURVENODE_COLOR_GREEN);
		if (lAnimCurve)
		{
			FBXSDK_printf("        Green\n");
			DisplayCurve(lAnimCurve);
		}
		lAnimCurve = lNodeAttribute->Color.GetCurve(pAnimLayer, FBXSDK_CURVENODE_COLOR_BLUE);
		if (lAnimCurve)
		{
			FBXSDK_printf("        Blue\n");
			DisplayCurve(lAnimCurve);
		}

		// Display curves specific to a light.
		FbxLight* light = pNode->GetLight();
		if (light)
		{
			lAnimCurve = light->Intensity.GetCurve(pAnimLayer);
			if (lAnimCurve)
			{
				FBXSDK_printf("        Intensity\n");
				DisplayCurve(lAnimCurve);
			}

			lAnimCurve = light->OuterAngle.GetCurve(pAnimLayer);
			if (lAnimCurve)
			{
				FBXSDK_printf("        Outer Angle\n");
				DisplayCurve(lAnimCurve);
			}

			lAnimCurve = light->Fog.GetCurve(pAnimLayer);
			if (lAnimCurve)
			{
				FBXSDK_printf("        Fog\n");
				DisplayCurve(lAnimCurve);
			}
		}

		// Display curves specific to a camera.
		FbxCamera* camera = pNode->GetCamera();
		if (camera)
		{
			lAnimCurve = camera->FieldOfView.GetCurve(pAnimLayer);
			if (lAnimCurve)
			{
				FBXSDK_printf("        Field of View\n");
				DisplayCurve(lAnimCurve);
			}

			lAnimCurve = camera->FieldOfViewX.GetCurve(pAnimLayer);
			if (lAnimCurve)
			{
				FBXSDK_printf("        Field of View X\n");
				DisplayCurve(lAnimCurve);
			}

			lAnimCurve = camera->FieldOfViewY.GetCurve(pAnimLayer);
			if (lAnimCurve)
			{
				FBXSDK_printf("        Field of View Y\n");
				DisplayCurve(lAnimCurve);
			}

			lAnimCurve = camera->OpticalCenterX.GetCurve(pAnimLayer);
			if (lAnimCurve)
			{
				FBXSDK_printf("        Optical Center X\n");
				DisplayCurve(lAnimCurve);
			}

			lAnimCurve = camera->OpticalCenterY.GetCurve(pAnimLayer);
			if (lAnimCurve)
			{
				FBXSDK_printf("        Optical Center Y\n");
				DisplayCurve(lAnimCurve);
			}

			lAnimCurve = camera->Roll.GetCurve(pAnimLayer);
			if (lAnimCurve)
			{
				FBXSDK_printf("        Roll\n");
				DisplayCurve(lAnimCurve);
			}
		}

		// Display curves specific to a geometry.
		if (lNodeAttribute->GetAttributeType() == FbxNodeAttribute::eMesh ||
			lNodeAttribute->GetAttributeType() == FbxNodeAttribute::eNurbs ||
			lNodeAttribute->GetAttributeType() == FbxNodeAttribute::ePatch)
		{
			FbxGeometry* lGeometry = (FbxGeometry*)lNodeAttribute;

			int lBlendShapeDeformerCount = lGeometry->GetDeformerCount(FbxDeformer::eBlendShape);
			for (int lBlendShapeIndex = 0; lBlendShapeIndex<lBlendShapeDeformerCount; ++lBlendShapeIndex)
			{
				FbxBlendShape* lBlendShape = (FbxBlendShape*)lGeometry->GetDeformer(lBlendShapeIndex, FbxDeformer::eBlendShape);

				int lBlendShapeChannelCount = lBlendShape->GetBlendShapeChannelCount();
				for (int lChannelIndex = 0; lChannelIndex<lBlendShapeChannelCount; ++lChannelIndex)
				{
					FbxBlendShapeChannel* lChannel = lBlendShape->GetBlendShapeChannel(lChannelIndex);
					const char* lChannelName = lChannel->GetName();

					lAnimCurve = lGeometry->GetShapeChannel(lBlendShapeIndex, lChannelIndex, pAnimLayer, true);
					if (lAnimCurve)
					{
						FBXSDK_printf("        Shape %s\n", lChannelName);
						DisplayCurve(lAnimCurve);
					}
				}
			}
		}
	}

	// Display curves specific to properties
	FbxProperty lProperty = pNode->GetFirstProperty();
	while (lProperty.IsValid())
	{
		if (lProperty.GetFlag(FbxPropertyFlags::eUserDefined))
		{
			FbxString lFbxFCurveNodeName = lProperty.GetName();
			FbxAnimCurveNode* lCurveNode = lProperty.GetCurveNode(pAnimLayer);

			if (!lCurveNode) {
				lProperty = pNode->GetNextProperty(lProperty);
				continue;
			}

			FbxDataType lDataType = lProperty.GetPropertyDataType();
			if (lDataType.GetType() == eFbxBool || lDataType.GetType() == eFbxDouble || lDataType.GetType() == eFbxFloat || lDataType.GetType() == eFbxInt)
			{
				FbxString lMessage;

				lMessage = "        Property ";
				lMessage += lProperty.GetName();
				if (lProperty.GetLabel().GetLen() > 0)
				{
					lMessage += " (Label: ";
					lMessage += lProperty.GetLabel();
					lMessage += ")";
				};

				std::cout << lMessage.Buffer() << std::endl;

				for (int c = 0; c < lCurveNode->GetCurveCount(0U); c++)
				{
					lAnimCurve = lCurveNode->GetCurve(0U, c);
					if (lAnimCurve)
						DisplayCurve(lAnimCurve);
				}
			}
			else if (lDataType.GetType() == eFbxDouble3 || lDataType.GetType() == eFbxDouble4 || lDataType.Is(FbxColor3DT) || lDataType.Is(FbxColor4DT))
			{
				char* lComponentName1 = (lDataType.Is(FbxColor3DT) || lDataType.Is(FbxColor4DT)) ? (char*)FBXSDK_CURVENODE_COLOR_RED : (char*)"X";
				char* lComponentName2 = (lDataType.Is(FbxColor3DT) || lDataType.Is(FbxColor4DT)) ? (char*)FBXSDK_CURVENODE_COLOR_GREEN : (char*)"Y";
				char* lComponentName3 = (lDataType.Is(FbxColor3DT) || lDataType.Is(FbxColor4DT)) ? (char*)FBXSDK_CURVENODE_COLOR_BLUE : (char*)"Z";
				FbxString      lMessage;

				lMessage = "        Property ";
				lMessage += lProperty.GetName();
				if (lProperty.GetLabel().GetLen() > 0)
				{
					lMessage += " (Label: ";
					lMessage += lProperty.GetLabel();
					lMessage += ")";
				}

				std::cout << lMessage.Buffer() << std::endl;

				for (int c = 0; c < lCurveNode->GetCurveCount(0U); c++)
				{
					lAnimCurve = lCurveNode->GetCurve(0U, c);
					if (lAnimCurve)
					{
						std::cout << "        Component " << lComponentName1 << std::endl;
						DisplayCurve(lAnimCurve);
					}
				}

				for (int c = 0; c < lCurveNode->GetCurveCount(1U); c++)
				{
					lAnimCurve = lCurveNode->GetCurve(1U, c);
					if (lAnimCurve)
					{
						std::cout << "        Component " << lComponentName2 << std::endl;
						DisplayCurve(lAnimCurve);
					}
				}

				for (int c = 0; c < lCurveNode->GetCurveCount(2U); c++)
				{
					lAnimCurve = lCurveNode->GetCurve(2U, c);
					if (lAnimCurve)
					{
						std::cout << "        Component " << lComponentName3 << std::endl;
						DisplayCurve(lAnimCurve);
					}
				}
			}
			else if (lDataType.GetType() == eFbxEnum)
			{
				FbxString lMessage;

				lMessage = "        Property ";
				lMessage += lProperty.GetName();
				if (lProperty.GetLabel().GetLen() > 0)
				{
					lMessage += " (Label: ";
					lMessage += lProperty.GetLabel();
					lMessage += ")";
				};

				std::cout << lMessage.Buffer() << std::endl;

				for (int c = 0; c < lCurveNode->GetCurveCount(0U); c++)
				{
					lAnimCurve = lCurveNode->GetCurve(0U, c);
					if (lAnimCurve)
						DisplayListCurve(lAnimCurve, &lProperty);
				}
			}
		}

		lProperty = pNode->GetNextProperty(lProperty);
	} // while

}

static int InterpolationFlagToIndex(int flags)
{
	if ((flags & FbxAnimCurveDef::eInterpolationConstant) == FbxAnimCurveDef::eInterpolationConstant) return 1;
	if ((flags & FbxAnimCurveDef::eInterpolationLinear) == FbxAnimCurveDef::eInterpolationLinear) return 2;
	if ((flags & FbxAnimCurveDef::eInterpolationCubic) == FbxAnimCurveDef::eInterpolationCubic) return 3;
	return 0;
}

static int ConstantmodeFlagToIndex(int flags)
{
	if ((flags & FbxAnimCurveDef::eConstantStandard) == FbxAnimCurveDef::eConstantStandard) return 1;
	if ((flags & FbxAnimCurveDef::eConstantNext) == FbxAnimCurveDef::eConstantNext) return 2;
	return 0;
}

static int TangentmodeFlagToIndex(int flags)
{
	if ((flags & FbxAnimCurveDef::eTangentAuto) == FbxAnimCurveDef::eTangentAuto) return 1;
	if ((flags & FbxAnimCurveDef::eTangentAutoBreak) == FbxAnimCurveDef::eTangentAutoBreak) return 2;
	if ((flags & FbxAnimCurveDef::eTangentTCB) == FbxAnimCurveDef::eTangentTCB) return 3;
	if ((flags & FbxAnimCurveDef::eTangentUser) == FbxAnimCurveDef::eTangentUser) return 4;
	if ((flags & FbxAnimCurveDef::eTangentGenericBreak) == FbxAnimCurveDef::eTangentGenericBreak) return 5;
	if ((flags & FbxAnimCurveDef::eTangentBreak) == FbxAnimCurveDef::eTangentBreak) return 6;
	return 0;
}

static int TangentweightFlagToIndex(int flags)
{
	if ((flags & FbxAnimCurveDef::eWeightedNone) == FbxAnimCurveDef::eWeightedNone) return 1;
	if ((flags & FbxAnimCurveDef::eWeightedRight) == FbxAnimCurveDef::eWeightedRight) return 2;
	if ((flags & FbxAnimCurveDef::eWeightedNextLeft) == FbxAnimCurveDef::eWeightedNextLeft) return 3;
	return 0;
}

static int TangentVelocityFlagToIndex(int flags)
{
	if ((flags & FbxAnimCurveDef::eVelocityNone) == FbxAnimCurveDef::eVelocityNone) return 1;
	if ((flags & FbxAnimCurveDef::eVelocityRight) == FbxAnimCurveDef::eVelocityRight) return 2;
	if ((flags & FbxAnimCurveDef::eVelocityNextLeft) == FbxAnimCurveDef::eVelocityNextLeft) return 3;
	return 0;
}

void DisplayCurveKeys(FbxAnimCurve* pCurve)
{
	static const char* interpolation[] = { "?", "constant", "linear", "cubic" };
	static const char* constantMode[] = { "?", "Standard", "Next" };
	static const char* cubicMode[] = { "?", "Auto", "Auto break", "Tcb", "User", "Break", "User break" };
	static const char* tangentWVMode[] = { "?", "None", "Right", "Next left" };

	FbxTime   lKeyTime;
	float   lKeyValue;
	char    lTimeString[256];
	FbxString lOutputString;
	int     lCount;

	int lKeyCount = pCurve->KeyGetCount();

	for (lCount = 0; lCount < lKeyCount; lCount++)
	{
		lKeyValue = static_cast<float>(pCurve->KeyGetValue(lCount));
		lKeyTime = pCurve->KeyGetTime(lCount);

		lOutputString = "            Key Time: ";
		lOutputString += lKeyTime.GetTimeString(lTimeString, FbxUShort(256));
		lOutputString += ".... Key Value: ";
		lOutputString += lKeyValue;
		lOutputString += " [ ";
		lOutputString += interpolation[InterpolationFlagToIndex(pCurve->KeyGetInterpolation(lCount))];
		if ((pCurve->KeyGetInterpolation(lCount)&FbxAnimCurveDef::eInterpolationConstant) == FbxAnimCurveDef::eInterpolationConstant)
		{
			lOutputString += " | ";
			lOutputString += constantMode[ConstantmodeFlagToIndex(pCurve->KeyGetConstantMode(lCount))];
		}
		else if ((pCurve->KeyGetInterpolation(lCount)&FbxAnimCurveDef::eInterpolationCubic) == FbxAnimCurveDef::eInterpolationCubic)
		{
			lOutputString += " | ";
			lOutputString += cubicMode[TangentmodeFlagToIndex(pCurve->KeyGetTangentMode(lCount))];
			lOutputString += " | ";
			lOutputString += tangentWVMode[TangentweightFlagToIndex(pCurve->KeyGet(lCount).GetTangentWeightMode())];
			lOutputString += " | ";
			lOutputString += tangentWVMode[TangentVelocityFlagToIndex(pCurve->KeyGet(lCount).GetTangentVelocityMode())];
		}
		lOutputString += " ]";
		lOutputString += "\n";
		FBXSDK_printf(lOutputString);
	}
}

void DisplayListCurveKeys(FbxAnimCurve* pCurve, FbxProperty* pProperty)
{
	FbxTime   lKeyTime;
	int     lKeyValue;
	char    lTimeString[256];
	FbxString lListValue;
	FbxString lOutputString;
	int     lCount;

	int lKeyCount = pCurve->KeyGetCount();

	for (lCount = 0; lCount < lKeyCount; lCount++)
	{
		lKeyValue = static_cast<int>(pCurve->KeyGetValue(lCount));
		lKeyTime = pCurve->KeyGetTime(lCount);

		lOutputString = "            Key Time: ";
		lOutputString += lKeyTime.GetTimeString(lTimeString, FbxUShort(256));
		lOutputString += ".... Key Value: ";
		lOutputString += lKeyValue;
		lOutputString += " (";
		lOutputString += pProperty->GetEnumValue(lKeyValue);
		lOutputString += ")";

		lOutputString += "\n";
		FBXSDK_printf(lOutputString);
	}
}

void DisplayMetaDataConnections(FbxObject* pObject)
{
	int nbMetaData = pObject->GetSrcObjectCount<FbxObjectMetaData>();
	if (nbMetaData > 0)
		std::cout << "    MetaData connections " << std::endl;

	for (int i = 0; i < nbMetaData; i++)
	{
		FbxObjectMetaData* metaData = pObject->GetSrcObject<FbxObjectMetaData>(i);
		std::cout << "        Name: " << (char*)metaData->GetName() << std::endl;
	}
}

void DisplaySkeleton(FbxNode* pNode)
{
	FbxSkeleton* lSkeleton = (FbxSkeleton*)pNode->GetNodeAttribute();

	if (!lSkeleton || lSkeleton->GetSkeletonType() > 3 || lSkeleton->GetSkeletonType() < 0)
		return;

	std::cout << "Skeleton Name: " << (char *)pNode->GetName() << std::endl;
	DisplayMetaDataConnections(lSkeleton);

	const char* lSkeletonTypes[] = { "Root", "Limb", "Limb Node", "Effector" };

	std::cout << "    Type: " << lSkeletonTypes[lSkeleton->GetSkeletonType()] << std::endl;

	if (lSkeleton->GetSkeletonType() == FbxSkeleton::eLimb)
	{
		std::cout << "    Limb Length: " << lSkeleton->LimbLength.Get() << std::endl;;
	}
	else if (lSkeleton->GetSkeletonType() == FbxSkeleton::eLimbNode)
	{
		std::cout << "    Limb Node Size: " << lSkeleton->Size.Get() << std::endl;
	}
	else if (lSkeleton->GetSkeletonType() == FbxSkeleton::eRoot)
	{
		std::cout << "    Limb Root Size: " << lSkeleton->Size.Get() << std::endl;
	}

	std::cout << "    Color: " << lSkeleton->GetLimbNodeColor().mRed << std::endl;
}

/*void LoadMaterials(FbxGeometry* pGeometry, Mesh::resource mesh)
{
int lMaterialCount = 0;
FbxNode* lNode = nullptr;
if (pGeometry)
{
lNode = pGeometry->GetNode();
if (lNode)
lMaterialCount = lNode->GetMaterialCount();
}

//ASSERT_THAT

if (lMaterialCount > 1)
lMaterialCount = lMaterialCount;

if (lMaterialCount > 0)
{
FbxPropertyT<FbxDouble3> lKFbxDouble3;
FbxPropertyT<FbxDouble> lKFbxDouble1;
FbxColor theColor;

for (int lCount = 0; lCount < lMaterialCount; lCount++)
{
::FbxSurfaceMaterial *lMaterial = lNode->GetMaterial(lCount);

if (lMaterial->GetClassId().Is(FbxSurfacePhong::ClassId))
{
// We found a Phong material.  Display its properties.
Material::ptr pnewmat = Material::Create();

FbxProperty lProperty = ((FbxSurfacePhong *)lMaterial)->FindProperty(::FbxSurfaceMaterial::sDiffuse);
int lTextureCount = lProperty.GetSrcObjectCount<FbxLayeredTexture>();
UNUSED_PARAM(lTextureCount);

// Display the Ambient Color
lKFbxDouble3 = ((FbxSurfacePhong *)lMaterial)->Ambient;
theColor.Set(lKFbxDouble3.Get()[0], lKFbxDouble3.Get()[1], lKFbxDouble3.Get()[2]);

// Diffuse Color
lKFbxDouble3 = ((FbxSurfacePhong *)lMaterial)->Diffuse;
theColor.Set(lKFbxDouble3.Get()[0], lKFbxDouble3.Get()[1], lKFbxDouble3.Get()[2]);
auto& diff = pnewmat->getDiffuseColor();
diff.x = (float)theColor.mRed;
diff.y = (float)theColor.mGreen;
diff.z = (float)theColor.mBlue;

// Display the Specular Color (unique to Phong materials)
lKFbxDouble3 = ((FbxSurfacePhong *)lMaterial)->Specular;
theColor.Set(lKFbxDouble3.Get()[0], lKFbxDouble3.Get()[1], lKFbxDouble3.Get()[2]);
auto& spec = pnewmat->getSpecularColor();
spec.x = (float)theColor.mRed;
spec.y = (float)theColor.mGreen;
spec.z = (float)theColor.mBlue;

// Display the Emissive Color
lKFbxDouble3 = ((FbxSurfacePhong *)lMaterial)->Emissive;
theColor.Set(lKFbxDouble3.Get()[0], lKFbxDouble3.Get()[1], lKFbxDouble3.Get()[2]);

//Opacity is Transparency factor now
lKFbxDouble1 = ((FbxSurfacePhong *)lMaterial)->TransparencyFactor;

// Display the Shininess
lKFbxDouble1 = ((FbxSurfacePhong *)lMaterial)->Shininess;
pnewmat->getGlossiness() = (float)lKFbxDouble1;

// Display the Reflectivity
lKFbxDouble1 = ((FbxSurfacePhong *)lMaterial)->ReflectionFactor;

auto add_textures = [](const FbxProperty & fbx_property, const Material::ptr & pnewmat)
{
if (fbx_property.IsValid())
{
int lTextureCount = fbx_property.GetSrcObjectCount<FbxTexture>();

lTextureCount = fbx_property.GetSrcObjectCount();

for (int j = 0; j < lTextureCount; ++j)
{
FbxTexture* lTexture = fbx_property.GetSrcObject<FbxTexture>(j);
if (lTexture)
{
otl::string n = FbxCast<FbxFileTexture>(lTexture)->GetFileName();
n = n.substr(n.find_last_of('\\') + 1, n.size() - n.find_first_of('\0'));
pnewmat->getTextureArray().emplace_back(n, false);
}
}
}
};

add_textures(lMaterial->FindProperty(::FbxSurfaceMaterial::sDiffuse), pnewmat);
add_textures(lMaterial->FindProperty(::FbxSurfaceMaterial::sSpecular), pnewmat);
add_textures(lMaterial->FindProperty(::FbxSurfaceMaterial::sAmbient), pnewmat);
add_textures(lMaterial->FindProperty(::FbxSurfaceMaterial::sEmissive), pnewmat);
add_textures(lMaterial->FindProperty(::FbxSurfaceMaterial::sBump), pnewmat);
add_textures(lMaterial->FindProperty(::FbxSurfaceMaterial::sTransparencyFactor), pnewmat);
add_textures(lMaterial->FindProperty(::FbxSurfaceMaterial::sTransparentColor), pnewmat);

static int because_artist_name_everything_correctly = 0;
std::string unique_name = std::to_string(because_artist_name_everything_correctly++) + lMaterial->GetName();
auto matres = ResourceManager::getInstance().Add<Material>(unique_name.c_str(), pnewmat);
mesh.get()->AddMaterial(matres);
}
}
}
}*/

/*void ComputeTangentsAndBinormals(Vertex& v0, Vertex& v1, Vertex& v2)
{
const Vec3 V0 = v1.mPosition - v0.mPosition;
const Vec3 V1 = v2.mPosition - v0.mPosition;
const Vec2 tp0 = v1.mTexCoord - v0.mTexCoord;
const Vec2 tp1 = v2.mTexCoord - v0.mTexCoord;

// PRAISE THE DENOMITANOR
const float denomitanor = tp0.x * tp1.y - tp0.y * tp1.x;

if (denomitanor == 0)
{
//PRINT_WARNING << "Tangents/Bitangents not computed correctly (denominator = 0)";

v0.mTangent = glm::normalize(Vec3{ -v0.mNormal.y, v0.mNormal.x, v0.mNormal.z });
v1.mTangent = glm::normalize(Vec3{ -v1.mNormal.y, v1.mNormal.x, v1.mNormal.z });
v2.mTangent = glm::normalize(Vec3{ -v2.mNormal.y, v2.mNormal.x, v2.mNormal.z });

v0.mBinormal = glm::normalize(glm::cross(v0.mNormal, v0.mTangent));
v1.mBinormal = glm::normalize(glm::cross(v1.mNormal, v1.mTangent));
v2.mBinormal = glm::normalize(glm::cross(v2.mNormal, v2.mTangent));

return;
}

Vec3 tangent = glm::normalize((tp1.y * V0 - tp0.y * V1) / denomitanor);
Vec3 binormal = glm::normalize((tp0.x * V1 - tp1.x * V0) / denomitanor);

v0.mTangent = tangent;
v1.mTangent = tangent;
v2.mTangent = tangent;

v0.mBinormal = binormal;
v1.mBinormal = binormal;
v2.mBinormal = binormal;
}*/

#else

// ==========================================================================================================================

#include <assimp/Importer.hpp>
#include <assimp/scene.h>
#include <assimp/postprocess.h>
#include "DebugSystem.h"

void LoadModel(Model& model, const std::string& path);
void ProcessNode(Model& model, aiNode* node, const aiScene* scene);
Mesh ProcessMesh(Model& model, aiMesh* mesh, const aiScene* scene, aiNode* node);

void Model::Load(const std::string& path)
{
	LoadModel(*this, path);
}

void LoadModel(Model& model, const std::string& path)
{
	static Assimp::Importer import;
	const aiScene* scene = import.ReadFile(path, aiProcess_ImproveCacheLocality | aiProcess_Triangulate | aiProcess_FlipUVs | aiProcess_GenSmoothNormals);

	if (!scene || scene->mFlags == AI_SCENE_FLAGS_INCOMPLETE || !scene->mRootNode)
	{
		PRINT_ERROR << "Assimp: " << import.GetErrorString() << std::endl;
		return;
	}

	model.mPath = path.substr(0, path.find_last_of('/'));
	ProcessNode(model, scene->mRootNode, scene);
}

void ProcessNode(Model& model, aiNode* node, const aiScene* scene)
{
	for (unsigned i = 0; i < node->mNumMeshes; i++)
	{
		aiMesh* mesh = scene->mMeshes[node->mMeshes[i]];
		model.mMeshes.push_back(ProcessMesh(model, mesh, scene, node));
	}

	for (GLuint i = 0; i < node->mNumChildren; i++)
		ProcessNode(model, node->mChildren[i], scene);
}

Mesh ProcessMesh(Model& model, aiMesh* mesh, const aiScene* scene, aiNode* node)
{
	UNUSED_PARAM(scene);
	UNUSED_PARAM(model);

	Mesh newmesh;

	std::vector<Vertex> vertices;
	std::vector<unsigned> indices;

	auto& trans = node->mTransformation;
	aiVector3t<float> sca;
	aiVector3t<float> pos;
	aiQuaterniont<float>quat;

	auto parent = node->mParent;
	while (parent)
	{
		trans = parent->mTransformation * trans;
		parent = parent->mParent;
	}
	trans = trans.Transpose();

	Mat4 mat;
	for (unsigned i = 0; i < 4; ++i)
	{
		for (unsigned j = 0; j < 4; ++j)
		{
			mat[i][j] = trans[i][j];
		}
	}
	newmesh.mTransform = mat;

	for (unsigned i = 0; i < mesh->mNumVertices; i++)
	{
		Vertex vertex;
		Vec3 vector;

		aiVector3D& vec = mesh->mVertices[i];
		vertex.mPosition = Vec3{ mat * Vec4{ vec.x, vec.y, vec.z, 1.f } };

		vec = mesh->mNormals[i];
		vertex.mNormal = { vec.x, vec.y, vec.z };

		if (mesh->mTextureCoords[0])
			vertex.mTexCoord = { mesh->mTextureCoords[0][i].x, mesh->mTextureCoords[0][i].y };
		else
			vertex.mTexCoord = Vec2(0.0f, 0.0f);

		vertices.push_back(vertex);
	}

	for (unsigned i = 0; i < mesh->mNumFaces; i++)
	{
		aiFace face = mesh->mFaces[i];

		for (unsigned j = 0; j < face.mNumIndices; j++)
			indices.push_back(face.mIndices[j]);
	}

	newmesh.UploadToGpu(vertices, indices);

	return newmesh;
}

#endif