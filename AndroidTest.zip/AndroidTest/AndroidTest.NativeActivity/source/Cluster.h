#pragma once

#include "RenderJob.h"

class Cluster
{
	//NON_COPYABLE(Cluster)

public:
	enum ClusterState
	{
		WAITING,
		RUNNING,
		FINISHED
	};

	Cluster& operator= (Cluster& renjob) = delete;
	Cluster(RenderJob& renjob, const IVec2& start, const IVec2& size, unsigned samples, ClusterState state = WAITING);

	void Render();
	void RenderHighlight();
	void Interrupt();
	void Pause(bool pause);

	IVec2 mStart;
	IVec2 mSize;
	ClusterState mState;
	RenderJob& mRenderJob;
	unsigned mSamples;

private:
	volatile bool mInterrupt{ false };
	volatile bool mPaused{ false };

	bool mDOF_Enabled;
	unsigned mDOF_Samples;
	float mDOF_Aperture;
};