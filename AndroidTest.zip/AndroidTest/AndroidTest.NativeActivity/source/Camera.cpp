#include "Camera.h"
#include "ImGUIHeaders.h"
#include "FoxTracerEngine.h"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "SDLHeaders.h"
#include "Math.h"

#include "FTESystems.h"

void Camera::Update()
{
	UpdateMatrices();
}

Mat4 Camera::GetCameraMatrix()
{
	return mCameraMatrix;
}

Mat4& Camera::GetPerspectiveMatrix()
{
	return mPerspectiveMatrix;
}

Mat4& Camera::GetViewportMatrix()
{
	return mViewportMatrix;
}

void Camera::UpdateMatrices()
{
	ComputeCameraMatrix();
	ComputePerspectiveMatrix();
	ComputeViewportMatrix();
}

void Camera::ComputeCameraMatrix()
{
	mCameraMatrix = glm::lookAt(mTransform.mPosition, mTarget, mUp);
}

void Camera::ComputePerspectiveMatrix()
{
	mPerspectiveMatrix = glm::perspective(glm::radians(mFOV_V), mAspectRatio, mNearPlane, mFarPlane);
}

void Camera::ComputeViewportMatrix()
{
	mViewportMatrix = mPerspectiveMatrix * mCameraMatrix;
}

Vec3 Camera::ComputeRealUpVector()
{
	auto view = mTarget - mTransform.mPosition;
	auto right = glm::cross(view, mUp);
	return glm::normalize(glm::cross(right, view));
}

std::vector<Vec3> Camera::GetProjectionPlane()
{
	Vec3 center = GetTransform().mPosition + (GetViewVector() * GetFocalDistance());

	float h_height = tanf(glm::radians(GetVerticalFOV() / 2)) * GetFocalDistance();
	float h_width = h_height * GetAspectRatio();

	std::vector<Vec3> corners;
	auto up = (h_height * ComputeRealUpVector());
	auto right = (h_width * GetRightVector());

	corners.push_back(center - right + up);
	corners.push_back(center + right + up);
	corners.push_back(center - right - up);
	corners.push_back(center + right - up);
	return corners;
}

void Camera::ShowGUI()
{
	//auto& tr = mTransform;
	//ImGui::DragFloat3("Position", &tr.mPosition.x, 0.1f, -100, 100);

	std::string name = "Vertical FOV (deg)##";
	name += std::to_string((int)this);
	ImGui::DragFloat(name.c_str(), &mFOV_V, 0.1f, 0, 180);

	name = "Focal distance##";
	name += std::to_string((int)this);
	ImGui::DragFloat(name.c_str(), &mFocalDistance, 0.1f, 0, 50);
}

void Camera::SetAspectRatio(float aspectratio) { mAspectRatio = aspectratio; }
float Camera::GetAspectRatio() { return mAspectRatio; }
void Camera::SetNearPlane(float nearplane) { mNearPlane = nearplane; };
float Camera::GetNearPlane() { return mNearPlane; }
void Camera::SetFarPlane(float farplane) { mFarPlane = farplane; }
float Camera::GetFarPlane() { return mFarPlane; }
void Camera::SetVerticalFOV(float fov) { mFOV_V = fov; }
float Camera::GetVerticalFOV() { return mFOV_V; }
void Camera::SetFocalDistance(float foc) { mFocalDistance = foc; }
float Camera::GetFocalDistance() { return mFocalDistance; }
void Camera::SetTarget(const Vec3& tar) { mTarget = tar; }
const Vec3& Camera::GetTarget() { return mTarget; }
void Camera::SetUpVector(const Vec3& up) { mUp = up; }
const Vec3& Camera::GetUpVector() { return mUp; }
const Vec3 Camera::GetViewVector() { return glm::normalize(mTarget - mTransform.mPosition); }
const Vec3 Camera::GetRightVector() { return glm::normalize(glm::cross(GetViewVector(), mUp)); };


void ArcballCamera::Update()
{
	auto& input = FoxTracerEngine::GetSystem<InputSystem>();
	auto& mouse = input.GetMouseMotion();

	if (input.MousePressed(MOUSE_LEFT))
	{
		mAngle_X += mouse.x * mMoveSpeed;
		mAngle_Y += mouse.y * mMoveSpeed;
	}

	if (input.MousePressed(MOUSE_RIGHT))
		mTransform.mPosition += GetViewVector() * input.GetMouseMotion().y * -1.f;

	if (mAngle_Y >= 90)
		mAngle_Y = 89;
	if (mAngle_Y <= -90)
		mAngle_Y = -89;

	double radius = glm::length(mTarget - mTransform.mPosition);
	double cosin = glm::cos(glm::radians(mAngle_Y));
	double pos_x = glm::cos(glm::radians(mAngle_X)) * cosin * radius;
	double pos_z = glm::sin(glm::radians(mAngle_X)) * cosin * radius;
	double pos_y = glm::sin(glm::radians(mAngle_Y)) * radius;

	mTransform.mPosition += Vec3{ pos_x, pos_y, pos_z } + (mTarget - mTransform.mPosition);
	auto rightvec = GetRightVector();

	// Pan left
	//if (input.KeyPressed(SDL_SCANCODE_A)){
	//	mTransform.mPosition -= rightvec* mMoveSpeed * 0.5f;
	//	mTarget -= rightvec* mMoveSpeed * 0.5f; }
	//
	//// Pan right
	//if (input.KeyPressed(SDL_SCANCODE_D)){
	//	mTransform.mPosition += rightvec * mMoveSpeed * 0.5f;
	//	mTarget += rightvec* mMoveSpeed * 0.5f; }
	//
	//// Move forward
	//if (input.KeyPressed(SDL_SCANCODE_W))
	//	mTransform.mPosition += GetViewVector() * mMoveSpeed * 0.5f;
	//
	//// Move backward
	//if (input.KeyPressed(SDL_SCANCODE_S) && !FoxTracerEngine::GetSystem<InputSystem>().KeyPressed(SDL_SCANCODE_LCTRL))
	//	mTransform.mPosition -= GetViewVector() * mMoveSpeed * 0.5f;
	//
	//// Update target position
	//mTarget = mTransform.mPosition + (GetViewVector() * mRadius);

	UpdateMatrices();
}

void ArcballCamera::SetRadius(float radius)
{
	mRadius = radius;
}

const float& ArcballCamera::GetRadius()
{
	return mRadius;
}