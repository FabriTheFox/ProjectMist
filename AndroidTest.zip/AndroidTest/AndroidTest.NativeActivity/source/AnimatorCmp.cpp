#include "AnimatorCmp.h"
#include "RTTI_imp.h"
#include "AssetSystem.h"
#include "FoxTracerEngine.h"
#include "FrameRateController.h"

COMPONENT_SERIALIZABLE_IMPLEMENTATION(AnimatorCmp);

REGISTER_PROPERTIES(AnimatorCmp) 
{
	PROPERTY(AnimatorCmp, std::string, mAnimation);
}

void AnimatorCmp::Load(SerDataPack& data)
{
	mAnimation = data.GetData("mAnimation").GetData<std::string>();
	if (mAnimation.empty())
		return;
	FoxTracerEngine::GetSystem<AssetSystem>().GetAsset<Animation>(mAnimation)->GetAnimationInstance(mAnimationInstance);
}

void AnimatorCmp::Update()
{
	if (mAnimationInstance.GetAnimation().expired())
		return;

	if (mCompleted || mPaused)
	{
		mAnimationInstance.UpdateAnimation(GetTransform());
		return;
	}

	auto panim = mAnimationInstance.GetAnimation().lock();

	mCurrentTime += (FoxTracerEngine::GetSystem<FrameRateController>().GetFrameTime() * mSpeed);
	mCurrentFrame = ((mCurrentTime) / (float)panim->mDuration) * panim->mFrames;

	mAnimationInstance.UpdateAnimation(mCurrentFrame, GetTransform());

	if (mCurrentTime > panim->mDuration)
		mCompleted = true;

	if (mCompleted && mLoop)
		Reset();
}

void AnimatorCmp::Pause(bool pause) { mPaused = pause; }
void AnimatorCmp::Stop() { Reset(); Pause(true); }
void AnimatorCmp::Play() { Pause(false); }
void AnimatorCmp::Reset() { mCompleted = false, mCurrentTime = 0; mCurrentFrame = 0; }
void AnimatorCmp::SetSpeed(float speed) { mSpeed = speed; }
void AnimatorCmp::PlayAnimation(const std::string& name) { Reset();  FoxTracerEngine::GetSystem<AssetSystem>().GetAsset<Animation>(name); Play(); }
void AnimatorCmp::PlayAnimation(WK_PTR<Animation> anim) { Reset(); anim.lock()->GetAnimationInstance(mAnimationInstance); Play(); }
void AnimatorCmp::Loop(bool loop) { mLoop = loop; }
void AnimatorCmp::SetAnimationAt(float t) { mAnimationInstance.UpdateAnimation(t, GetTransform()); }

