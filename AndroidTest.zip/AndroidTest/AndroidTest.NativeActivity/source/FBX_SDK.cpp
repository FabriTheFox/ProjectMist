#include "FBX_SDK.h"
#include "DebugSystem.h"

::FbxManager* GetFBXSDK()
{
	::FbxManager* lSdkManager = ::FbxManager::Create();
	FbxIOSettings * ios = ::FbxIOSettings::Create(lSdkManager, IOSROOT);
	lSdkManager->SetIOSettings(ios);
	return lSdkManager;
}

::FbxScene* LoadFBXScene(const std::string& filename)
{
	static ::FbxManager* lSdkManager = GetFBXSDK();
	static ::FbxImporter* lImporter = ::FbxImporter::Create(lSdkManager, "the_importer");

	bool lImportStatus = lImporter->Initialize(filename.c_str(), -1, lSdkManager->GetIOSettings());

	if (!lImportStatus)
	{
		auto s = lImporter->GetStatus();
		auto err = s.GetErrorString();

		PRINT_ERROR << "Could not initialize the fbx importer for file \"" << filename << "\". " << err;
		return nullptr;
	}

	::FbxScene * lScene = ::FbxScene::Create(lSdkManager, filename.c_str());
	lImporter->Import(lScene);
	//lImporter->Destroy();

	return lScene;
}