#pragma once

class Event
{
public:

private:
};