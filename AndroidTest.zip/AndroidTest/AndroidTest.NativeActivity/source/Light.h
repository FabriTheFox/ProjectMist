#pragma once

#include "Component.h"
#include "DataTypes.h"
#include "Layer.h"
#include "RT_Light.h"

class Light :
	public Component,
	public std::enable_shared_from_this<Light>
{
	COMPONENT_DECLARATION(Light)
public:

	Light(const std::string& layer);
	void AddToSystem() override;
	void FillShaderData(std::vector<float>& vec);
	virtual void GetShaderData(std::vector<float>& vec) = 0;
	void ShowGUI();

	// RayTracing
	void FillRTData(RT_Light& light);

	struct Attenuation : public Base
	{
		SERIALIZABLE_DECLARATION(Attenuation)
	public:
		float mInnerRadius{ 0 };
		float mOuterRadius{ 25 };
	};

	Vec3 mDiffuse{ 1, 1, 1};
	Vec3 mSpecular{1, 1, 1};
	Vec3 mAmbient{0.1f, 0.1f, 0.1f};
	Attenuation mAttenuation;

protected:
	virtual void ShowDebugGUI() {}

	Layer& mLayer;
};


class OmniLight :
	public Light
{
	COMPONENT_SERIALIZABLE_DECLARATION(OmniLight)
public:

	OmniLight(const std::string& layer = "World");
	void GetShaderData(std::vector<float>& vec) override;

private:
};