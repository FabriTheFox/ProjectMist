#pragma once

#include "RTTI.h"
#include "DataTypes.h"
#include "Texture.h"
#include "Utilities.h"
#include <mutex>

class RenderJob;

class RT_PhotonMap
{
public:
	enum PhotonMapStatus
	{
		PM_WAITING,
		PM_TRACING_PHOTONS,
		PM_BUILDING_KDTREE,
		PM_FINISHED
	};

	struct PhotonData
	{
		Vec3 mColor{0, 0, 0};
		Vec3 mNormal{0, 0, 0};
	};

	RT_PhotonMap();
	~RT_PhotonMap();

	void Launch(RenderJob* renderjob);
	void AddPhoton(const Vec3& pos, const PhotonData& data);
	PhotonData GetValueAt(const Vec3& pos, const Vec3& normal);

	float GetRadius();
	float GetArea();

	unsigned GetLevels();
	unsigned GetPhotonNum();

	Utilities::Timer& GetTimer();

	PhotonMapStatus mStatus{PM_WAITING};

//private:
	void Initialize();
	void TracePhotons();
	void BuildKDTree();

	void* mPhotonMap;
	void* mPhotonVec;
	float mSQmaxDistance;
	float mMaxDistance;
	float mArea;

	RenderJob* mRenderJob;

	Utilities::Timer mTimer;

	static std::mutex mMutex;
};