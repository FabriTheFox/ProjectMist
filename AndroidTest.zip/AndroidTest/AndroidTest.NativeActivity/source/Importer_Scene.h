#pragma once

#include "Importer.h"

class Importer_Scene : public Importer
{
public:
	IMPORTER_DECLARATION(Importer_Scene)
	void Import(const std::string& name, const std::string& path) override;
private:
};