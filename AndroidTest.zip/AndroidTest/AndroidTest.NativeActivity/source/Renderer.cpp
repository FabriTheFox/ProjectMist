#include "Renderer.h"
#include "FoxTracerEngine.h"
#include "AssetSystem.h"
#include "OpenGLHeaders.h"
#include "Layer.h"
#include "Intersection.h"
#include "RenderCommand.h"
#include <glm/gtc/type_ptr.hpp>

#include "AnimatorCmp.h"
#include "IKAnimatorCmp.h"
#include "FTESystems.h"
#include "RTTI_imp.h"

#include "SDLHeaders.h"

RTTI_IMPLEMENTATION(Renderer)

Renderer::Renderer(const std::string& shader, const std::string& layer) : 
	mShader(*FoxTracerEngine::GetSystem<AssetSystem>().GetAsset<Shader>(shader)),
	mLayer(FoxTracerEngine::GetSystem<GraphicSystem>().GetLayer(layer)),
	mCamera(*mLayer.GetCamera())
{}

void Renderer::Render() {}
void Renderer::AddRenderer(SHD_PTR<Renderable> pren) { mRenderables.AddPtr(pren); }
void Renderer::RemoveRenderable(SHD_PTR<Renderable> pren) { mRenderables.RemovePtr(pren); }
SHDPtrVec<Renderable>& Renderer::GetRenderables() { return mRenderables; }
Shader& Renderer::GetShader() { return mShader; }
Camera& Renderer::GetLayerCamera() { return *mLayer.GetCamera(); }

void Renderer::FillRTData(RT_Renderer& renderer)
{
	auto type = GetRTTI().mTypehash;
	if (type == BasicRenderer::RTTI_.mTypehash)
		renderer.mRenderFN = &RT_Renderer::Render_Basic;
	else if (type == PhongLightRenderer::RTTI_.mTypehash)
		renderer.mRenderFN = &RT_Renderer::Render_Phong;
	else if (type == ReflectivePhongLightRenderer::RTTI_.mTypehash)
		renderer.mRenderFN = &RT_Renderer::Render_ReflectivePhong;
	else if (type == RefractivePhongLightRenderer::RTTI_.mTypehash)
		renderer.mRenderFN = &RT_Renderer::Render_RefractivePhong;

	for (auto& r : mRenderables.AlivePtrs_)
	{
		renderer.mRenderables.emplace_back(RT_Renderable());
		r->FillRTData(renderer.mRenderables.back());
	}
}

RTTI_IMPLEMENTATION(BasicRenderer)
BasicRenderer::BasicRenderer(const std::string& name, const std::string& layer) : Renderer(name, layer) {}
void BasicRenderer::Render()
{
	RenderCommand render(mShader.GetPtr());
	render.EnableDepthTest(true);
	render.EnableDepthWriting(true);
	render.EnableWireFrame(false);
	render.ApplyConfig();

	for (auto& ren : mRenderables.AlivePtrs_)
	{
		if (!ren->IsVisible())
			continue;

		auto mod = ren->GetTransform().GetModelMatrix();
		auto mv = mCamera.GetViewportMatrix() * mod;

		render.SetUniformMat4("MV", mv);
		render.SetUniformMat4("ViewSpace", mCamera.GetCameraMatrix() * mod);
		render.SetUniformVec4("modulation_color", ren->GetModulationColor());

		render.Render(gl::TRIANGLES, ren->GetModel().GetPtr());
	}
}

RTTI_IMPLEMENTATION(PhongLightRenderer)
PhongLightRenderer::PhongLightRenderer(const std::string& name, const std::string& layer) : Renderer(name, layer) {}
void PhongLightRenderer::Render()
{
	mLayer.GetLightingSystem().UploadLights(mShader);

	RenderCommand render(mShader.GetPtr());
	render.EnableDepthTest(true);
	render.EnableDepthWriting(true);
	render.ApplyConfig();

	for (auto& ren : mRenderables.AlivePtrs_)
	{
		if (!ren->IsVisible())
			continue;

		auto mod = ren->GetTransform().GetModelMatrix();
		auto mv = mCamera.GetViewportMatrix() * mod;

		render.SetUniformMat4("MV", mv);
		render.SetUniformMat4("ViewSpace", mCamera.GetCameraMatrix() * mod);
		render.SetUniformVec4("modulation_color", ren->GetModulationColor());

		render.Render(gl::TRIANGLES, ren->GetModel().GetPtr());
	}
}

RTTI_IMPLEMENTATION(ReflectivePhongLightRenderer)
ReflectivePhongLightRenderer::ReflectivePhongLightRenderer(const std::string& name, const std::string& layer) : PhongLightRenderer(name, layer) {}

RTTI_IMPLEMENTATION(RefractivePhongLightRenderer)
RefractivePhongLightRenderer::RefractivePhongLightRenderer(const std::string& name, const std::string& layer) : PhongLightRenderer(name, layer) {}

RTTI_IMPLEMENTATION(AnimationRenderer)
AnimationRenderer::AnimationRenderer(const std::string& name, const std::string& layer): Renderer(name, layer) {}

void AnimationRenderer::Render()
{
	RenderCommand render(mShader.GetPtr());
	render.EnableDepthTest(true);
	render.EnableDepthWriting(true);
	render.EnableWireFrame(true);
	render.ApplyConfig();

	for (auto& ren : mRenderables.AlivePtrs_)
	{
		if (!ren->IsVisible())
			continue;

		auto mod = ren->GetTransform().GetModelMatrix();
		auto mv = mCamera.GetViewportMatrix() * mod;

		// Get the animator component
		auto cmp = ren->GetOwner().GetComponent<AnimatorCmp>();

		// If ot has not animator or the animator has no animation, return
		if (!cmp)
			return;

		cmp->Pause(true);
		cmp->Update();

		RenderAnimationNode(cmp->mAnimationInstance.mRootNode, render, ren);

		//render.SetUniformMat4("MV", mv);
		//render.SetUniformMat4("ViewSpace", mCamera.GetCameraMatrix() * mod);
		//render.SetUniformVec4("modulation_color", ren->GetModulationColor());
		//render.Render(gl::TRIANGLES, ren->GetModel().GetPtr());
	}
}

// Updates the animation node and draws a sphere on the joint and a line joining his children and itself
void AnimationRenderer::RenderAnimationNode(AnimationInstanceNode& node, RenderCommand& rc, SHD_PTR<Renderable> ren)
{
	auto matrx = node.GetWorldTransform().GetMatrix();

	for (auto& m : ren->GetModel().mMeshes)
	{
		if (m.mName == node.mAnimationNode->mName)
		{
			rc.SetUniformMat4("MV", mCamera.GetViewportMatrix() * matrx);
			rc.SetUniformMat4("ViewSpace", mCamera.GetCameraMatrix() * matrx);
			rc.SetUniformVec4("modulation_color", ren->GetModulationColor());
			m.Draw(gl::TRIANGLES);
			break;
		}
	}

	FoxTracerEngine::GetSystem<GraphicSystem>().GetLayer("World").RenderDebugPoint(node.GetWorldPos(), { 1, 0, 0, 1 }, 8);

	for (auto& c : node.mChildren)
	{
		FoxTracerEngine::GetSystem<GraphicSystem>().GetLayer("World").RenderDebugLine(node.GetWorldPos(), c.GetWorldPos(), {1, 0.5f, 0, 1});
		RenderAnimationNode(c, rc, ren);
	}
}

RTTI_IMPLEMENTATION(CameraLightRenderer)
CameraLightRenderer::CameraLightRenderer(const std::string& name, const std::string& layer) : Renderer(name, layer) {}
void CameraLightRenderer::Render()
{
	RenderCommand render(mShader.GetPtr());
	render.EnableDepthTest(true);
	render.EnableDepthWriting(true);
	render.EnableWireFrame(true);
	render.ApplyConfig();

	for (auto& ren : mRenderables.AlivePtrs_)
	{
		if (!ren->IsVisible())
			continue;

		auto mod = ren->GetTransform().GetModelMatrix();
		auto mv = mCamera.GetViewportMatrix() * mod;

		render.SetUniformMat4("MV", mv);
		render.SetUniformMat4("ViewSpace", mCamera.GetCameraMatrix() * mod);
		render.SetUniformVec4("modulation_color", ren->GetModulationColor());

		render.Render(gl::TRIANGLES, ren->GetModel().GetPtr());
	}
}

#include "ClothAnimatorCmp.h"

RTTI_IMPLEMENTATION(ClothMeshRenderer)
ClothMeshRenderer::ClothMeshRenderer(const std::string& name, const std::string& layer) : Renderer(name, layer) {}

void ClothMeshRenderer::Render()
{
	RenderCommand render(mShader.GetPtr());
	//render.EnableDepthTest(true);
	//render.EnableDepthWriting(true);
	//render.EnableWireFrame(true);
	render.ApplyConfig();

	for (auto& ren : mRenderables.AlivePtrs_)
	{
		if (!ren->IsVisible())
			continue;

		ClothAnimatorCmp& cmp = *ren->GetOwner().GetComponent<ClothAnimatorCmp>();
		cmp.UpdateWireMeshes();

		auto mv = mCamera.GetViewportMatrix();
		render.SetUniformMat4("MV", mv);
		render.SetUniformMat4("ViewSpace", mCamera.GetCameraMatrix());

		render.SetUniformVec4("modulation_color", { 0.2f, 0.8f, 0.1f, 1.f });
		gl::LineWidth(1.f);
		gl::Disable(gl::LINE_SMOOTH);
		render.Render(gl::LINES, cmp.mConstraintMesh);

		render.SetUniformVec4("modulation_color", {1, 1, 1, 1});
		render.Render(gl::POINTS, cmp.mPointsMesh);
	}
}

RTTI_IMPLEMENTATION(ClothTextureRenderer)
ClothTextureRenderer::ClothTextureRenderer(const std::string& name, const std::string& layer) : Renderer(name, layer) {}

void ClothTextureRenderer::Render()
{
	RenderCommand render(mShader.GetPtr());
	render.EnableDepthTest(true);
	render.EnableDepthWriting(true);
	//render.EnableWireFrame(true);
	render.ApplyConfig();

	for (auto& ren : mRenderables.AlivePtrs_)
	{
		if (!ren->IsVisible())
			continue;

		ClothAnimatorCmp& cmp = *ren->GetOwner().GetComponent<ClothAnimatorCmp>();
		cmp.UpdateTriangleMesh();

		auto mv = mCamera.GetViewportMatrix();
		render.SetUniformMat4("MV", mv);
		render.SetUniformMat4("ViewSpace", mCamera.GetCameraMatrix());

		FoxTracerEngine::GetSystem<AssetSystem>().GetAsset<Texture>("MR")->Bind();
		render.SetUniformVec4("modulation_color", { 1, 1, 1, 1 });
		render.Render(gl::TRIANGLES, cmp.mTriangleMesh);
	}
}