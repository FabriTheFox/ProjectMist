#include "LightingSystem.h"
#include "Light.h"
#include "ImGUIHeaders.h"
#include "RTTI_imp.h"

RTTI_IMPLEMENTATION(LightingSystem)

const int LIGHT_TYPES = 1;
const int OMNI_LIGHT = 0;

void LightingSystem::Shutdown()
{
	mLights.clear();
}

void LightingSystem::Update()
{
	for (auto& pair : mLights)
	{
		for (unsigned i = 0; i < pair.second.size(); ++i)
		{
			if (pair.second[i].expired())
			{
				pair.second[i] = pair.second.back();
				pair.second.pop_back();
			}
		}
	}
}

void LightingSystem::UploadLights(Shader& shader)
{
	std::vector<int> light_types(LIGHT_TYPES);
	for (unsigned i = 0; i < light_types.size(); ++i)
		light_types[i] = 0;

	for (auto& pair : mLights)
	{
		auto type = pair.first;
		if (type == OmniLight::RTTI_.mTypehash)
			light_types[OMNI_LIGHT] = (int)pair.second.size();
	}

	mLightShaderData.clear();
	for (auto& pair : mLights)
	{
		mLightShaderData.push_back(14);		// HARDCODE
		for (auto& light : pair.second)
			light.lock()->FillShaderData(mLightShaderData);
	}

	shader.SetUniformIntVec("lighttypes_vec", light_types.data(), (unsigned)light_types.size());
	shader.SetUniformfloatVec("lightdata_vec", mLightShaderData.data(), (unsigned)mLightShaderData.size());
}

std::unordered_map<size_t, std::vector<WK_PTR<Light>>>& LightingSystem::GetLights()
{
	return mLights;
}

void LightingSystem::ShowGUIWindow(bool& open)
{
	ImGui::SetNextWindowPos(ImVec2(200, 200), ImGuiSetCond_Once);
	ImGui::Begin("Lighting System", &open, ImGuiWindowFlags_AlwaysAutoResize);

	for (auto& pair : mLights)
	{
		for (auto& l : pair.second)
		{
			ImGui::Text(l.lock()->GetOwner().GetName().c_str());
			l.lock()->ShowGUI();
			ImGui::Separator();
		}
	}

	ImGui::End();
}