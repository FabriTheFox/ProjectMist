#pragma once

#include "ImGUIHeaders.h"
#include "DataTypes.h"
#include <string>

namespace FTEDebug
{
	void EditColor4(Vec4& color, const std::string& name)
	{
		ImVec4 imcolor = { color.r, color.g, color.b, color.a };

		ImGui::ColorButton(imcolor);
		if (ImGui::BeginPopupContextItem((std::string("##") + std::to_string((int)(&color))).c_str()))
		{
			ImGui::Text("Edit color");
			ImGui::ColorEdit3((std::string("##") + std::to_string((int)(&color))).c_str(), (float*)&color);
			if (ImGui::Button("Close"))
				ImGui::CloseCurrentPopup();
			ImGui::EndPopup();
		}

		ImGui::SameLine();
		ImGui::Text(name.c_str());
	}

	void EditColor3(Vec3& color, const std::string& name)
	{
		ImVec4 imcolor = { color.r, color.g, color.b, 1 };

		ImGui::ColorButton(imcolor);
		if (ImGui::BeginPopupContextItem((std::string("##") + std::to_string((int)(&color))).c_str()))
		{
			ImGui::Text("Edit color");
			ImGui::ColorEdit3((std::string("##") + std::to_string((int)(&color))).c_str(), (float*)&color);
			if (ImGui::Button("Close"))
				ImGui::CloseCurrentPopup();
			ImGui::EndPopup();
		}

		ImGui::SameLine();
		ImGui::Text(name.c_str());
	}
}

