#include "KDTree.h"
#include "FoxTracerEngine.h"
#include "GraphicSystem.h"
#include <algorithm>

KDTree::~KDTree()
{
	DeleteTree();
}

FTEIntersection::IntersectionResult KDTree::TraceRay(const Vec3& start, const Vec3& dir)
{
	return TraceRayNode(start, dir, mRoot);
}

FTEIntersection::IntersectionResult KDTree::TraceRayNode(const Vec3& start, const Vec3& dir, KDNode* node)
{
	if (!node)
		return FTEIntersection::IntersectionResult();

	if (!node->mBoundingVolume.IsPointInside(start))
	{
		if (!FTEIntersection::Ray_AABB_Test(node->mBoundingVolume.mCenter, node->mBoundingVolume.mExtent, start, dir))
			return FTEIntersection::IntersectionResult();
	}

	FTEIntersection::IntersectionResult nearest = node->TraceRay(start, dir);

	KDNode* front = node->mChildRight;
	KDNode* back = node->mChildLeft;

	if (start[(int)node->mPlane.x] < node->mPlane.y)
		std::swap(front, back);

	auto res_front = TraceRayNode(start, dir, front);
	if (res_front.mDis < nearest.mDis)
		return res_front;

	auto res_back = TraceRayNode(start, dir, back);
	if (res_back.mDis < nearest.mDis)
		return res_back;

	return nearest;
}

FTEIntersection::IntersectionResult KDTree::KDNode::TraceRay(const Vec3& start, const Vec3& dir)
{
	FTEIntersection::IntersectionResult nearest;
	for (auto& tr : mTriangles)
	{
		auto res = tr.TraceRay(start, dir);
		if (res.mDis < nearest.mDis)
			nearest = res;
	}
	return nearest;
}

unsigned KDTree::BuildKDTree(std::vector<FTEIntersection::Triangle>& triangles, unsigned maxlevel)
{
	if (triangles.empty())
		return 0;

	DeleteTree();

	mMaxLevel = maxlevel;

	mRoot = new KDNode;
	mRoot->mBoundingVolume = AABB(triangles);
	mRoot->mLevel = 0;

	mTriangles = triangles;
	InternalBuild(mTriangles, mRoot);

	return mTreeLevel;
}

void KDTree::RenderTree(unsigned maxlevel, bool drawparents, const std::string& layer)
{
	auto& lay = FoxTracerEngine::GetSystem<GraphicSystem>().GetLayer(layer);

	for (auto& n : mNodesToRender)
	{
		if (n.mLevel > maxlevel || (!drawparents && n.mLevel < maxlevel))
			continue;

		Transform tr;
		tr.mPosition = n.mBoundingVolume.mCenter;
		tr.mScale = n.mBoundingVolume.mExtent * 2.f;
		Vec4 color = { 1 - ((n.mLevel + 1) * (1.f / (mTreeLevel + 1))), (n.mLevel + 1) * (1.f / (mTreeLevel + 1)), 0, 1 };
		lay.RenderDebugWireCube(tr, color, 3);
	}
}

void KDTree::DeleteTree()
{
	DeleteNode(mRoot);
	mRoot = nullptr;
	mTreeLevel = 0;
	mTriangles.clear();
	mCurrEventList.clear();
	mNodesToRender.clear();
}

void KDTree::InternalBuild(const std::vector<FTEIntersection::Triangle>& triangles, KDNode* node)
{
	if (node->mLevel >= mMaxLevel || triangles.empty())
	{
		node->mTriangles = triangles;
		return;
	}

	mNodesToRender.emplace_back(NodeToRender{ node->mBoundingVolume, node->mLevel });

	Vec2 splitplane = GetSplittingPlane(triangles, node);

	if (splitplane.x < 0)
	{
		node->mTriangles = triangles;
		return;
	}

	if (node->mLevel > mTreeLevel)
		mTreeLevel = node->mLevel;

	AABB& bb = node->mBoundingVolume;
	auto newvolumes = bb.SplitByAAPlane(splitplane);

	node->mPlane = splitplane;

	node->mChildLeft = new KDNode;
	node->mChildLeft->mBoundingVolume = newvolumes[0];
	node->mChildLeft->mLevel = node->mLevel + 1;

	node->mChildRight = new KDNode;
	node->mChildRight->mBoundingVolume = newvolumes[1];
	node->mChildRight->mLevel = node->mLevel + 1;

	if (node->mChildLeft->mBoundingVolume.mCenter[(int)splitplane.x] > node->mChildRight->mBoundingVolume.mCenter[(int)splitplane.x])
		std::swap(node->mChildLeft, node->mChildRight);

	std::vector<FTEIntersection::Triangle> lefttriangles;
	std::vector<FTEIntersection::Triangle> righttriangles;

	unsigned i = 0;
	for (; i < mCurrEventList.size(); ++i)
	{
		if (mCurrEventList[i].mEventType == KDEvent::ENDING)
			continue;

		if (mCurrEventList[i].mEventType == KDEvent::STARTING)
		{
			if ((mCurrEventList[i].mPosition < splitplane.y && mCurrEventList[i].mEndPosition >= splitplane.y) || 
				(mCurrEventList[i].mPosition >= splitplane.y && mCurrEventList[i].mEndPosition < splitplane.y))
			{
				lefttriangles.push_back(triangles[mCurrEventList[i].mTriangleIndex]);
				righttriangles.push_back(triangles[mCurrEventList[i].mTriangleIndex]);
				continue;
			}
		}

		if (mCurrEventList[i].mPosition < splitplane.y)
			lefttriangles.push_back(triangles[mCurrEventList[i].mTriangleIndex]);
		else
			righttriangles.push_back(triangles[mCurrEventList[i].mTriangleIndex]);
	}

	InternalBuild(lefttriangles, node->mChildLeft);
	InternalBuild(righttriangles, node->mChildRight);
}

Vec2 KDTree::GetSplittingPlane(const std::vector<FTEIntersection::Triangle>& triangles, KDNode* node)
{
	float total_area = node->mBoundingVolume.GetSurfaceArea();
	float base_cost = mIntersectionCost / total_area;
	float min_cost = FLT_MAX;

	Vec2 best_plane;
	std::vector<KDEvent> events[3];

	for (unsigned i = 0; i < 3; ++i)
	{
		GenerateEventList(triangles, i, events[i], node->mBoundingVolume);

		unsigned NL = 0;
		unsigned NR = (unsigned)triangles.size();
		unsigned N0 = 0;

		for (unsigned j = 0; j < events[i].size() - 1;)
		{
			float plane = events[i][j].mPosition;
			unsigned p[3] = { 0, 0, 0 };

			for (; j < events[i].size() - 1; ++j)
			{
				if (events[i][j].mPosition != plane)
					break;
				++p[events[i][j].mEventType];
			}

			unsigned& p_end = p[0];
			unsigned& p_cop = p[1];
			unsigned& p_start = p[2];

			N0 = p_cop;
			NR = NR - p_cop - p_end;

			auto splitted_abbs = node->mBoundingVolume.SplitByAAPlane({ i, plane });
			float cost = base_cost * (((splitted_abbs[0].GetSurfaceArea() * NL) + (splitted_abbs[1].GetSurfaceArea() * NR)));

			if (cost < min_cost)
			{
				min_cost = cost;
				best_plane = { i, plane };
			}
			NL = NL + p_cop + p_start;
		}
	}

	if (min_cost + mTraverseCost > triangles.size() * mIntersectionCost)
		best_plane.x = -1;
	else
		mCurrEventList = events[(unsigned)best_plane.x];

	return best_plane;
}

void KDTree::GenerateEventList(const std::vector<FTEIntersection::Triangle>& triangles, unsigned axis, std::vector<KDEvent>& evlist, const AABB& aabb)
{
	evlist.clear();

	float min = aabb.mCenter[axis] - aabb.mExtent[axis];
	float max = aabb.mCenter[axis] + aabb.mExtent[axis];

	for (unsigned i = 0; i < triangles.size(); ++i)
	{
		const auto& tr = triangles[i];

		if (tr.mVertices[0][axis] == tr.mVertices[1][axis] && tr.mVertices[1][axis] == tr.mVertices[2][axis])
		{
			KDEvent ev;
			ev.mEventType= KDEvent::COPLANAR;
			ev.mTriangleIndex = i;
			ev.mPosition = tr.mVertices[0][axis];
			evlist.push_back(ev);
		}
		else
		{
			KDEvent ev;
			ev.mEventType = KDEvent::ENDING;
			ev.mTriangleIndex = i;
			ev.mPosition = tr.GetMaxValOnAxis(axis);
			evlist.push_back(ev);
	
			ev.mEventType = KDEvent::STARTING;
			ev.mTriangleIndex = i;
			ev.mPosition = tr.GetMinValOnAxis(axis);
			ev.mEndPosition = evlist.back().mPosition;
			evlist.push_back(ev);
		}

		if (evlist.back().mPosition < min)
			evlist.back().mPosition = min;
		else if (evlist.back().mPosition > max)
			evlist.back().mPosition = max;
	}

	std::sort(evlist.begin(), evlist.end());
}

void KDTree::DeleteNode(KDNode* node)
{
	if (!node)
		return;

	KDNode* left = node->mChildLeft;
	KDNode* right = node->mChildRight;

	delete node;

	DeleteNode(left);
	DeleteNode(right);
}

float& KDTree::GetIntersectionCost() { return mIntersectionCost; }
float& KDTree::GetTraverseCost() { return mTraverseCost; }
unsigned KDTree::GetLevel() { return mTreeLevel; }

bool KDTree::KDEvent::operator< (const KDEvent& rhs) const
{
	if (rhs.mPosition == mPosition)
		return mEventType < rhs.mEventType;
	return mPosition < rhs.mPosition;
}