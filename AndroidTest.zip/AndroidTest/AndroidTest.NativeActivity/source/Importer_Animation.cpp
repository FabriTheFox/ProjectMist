#include "Importer_Animation.h"
#include "FBX_SDK.h"
#include "Animation.h"
#include "AssetSystem.h"

void LoadChannel(FbxAnimCurve* pCurve, AnimationCurve<float>& curv)
{
	if (!pCurve)
		return;

	curv.mCurve.reserve(pCurve->KeyGetCount());
	for (int i = 0; i < pCurve->KeyGetCount(); i++)
	{
		float lKeyValue = static_cast<float>(pCurve->KeyGetValue(i));
		auto lKeyTime = pCurve->KeyGetTime(i).GetFramedTime().GetTimeString();

		auto time = std::stoi(lKeyTime.Buffer());

		curv.mCurve.push_back({ (float)time, lKeyValue });
	}

	curv.mStartKey = curv.mCurve.front();
	curv.mEndKey = curv.mCurve.back();
}

void LoadChannel(FbxNode* pNode, FbxAnimLayer* pAnimLayer, AnimationCurve<FTE_Quat::FTEQuat>& curv)
{
	FbxAnimCurve* curves[3];

	curves[0] = pNode->LclRotation.GetCurve(pAnimLayer, FBXSDK_CURVENODE_COMPONENT_X);
	curves[1] = pNode->LclRotation.GetCurve(pAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y);
	curves[2] = pNode->LclRotation.GetCurve(pAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z);


	if (curves[0] || curves[1] || curves[2])
	{
		int count = curves[0]->KeyGetCount();
		if (curves[1]->KeyGetCount() != count || curves[2]->KeyGetCount() != count)
		{
			std::cout << "ERROR LOADING ANIMATION: CURVE NEEDS TO HAVE ALL ROTATION CHANNELS";
			return;
		}

		for (int i = 0; i < count; ++i)
		{
			Vec3 euler;
			auto lKeyTime = curves[0]->KeyGetTime(i).GetFramedTime().GetTimeString();
			auto time = std::stoi(lKeyTime.Buffer());

			euler[0] = static_cast<float>(curves[0]->KeyGetValue(i));
			euler[1] = static_cast<float>(curves[1]->KeyGetValue(i));
			euler[2] = static_cast<float>(curves[2]->KeyGetValue(i));

			curv.mCurve.push_back({(float)time,{ euler } });
		}
			

		curv.mStartKey = curv.mCurve.front();
		curv.mEndKey = curv.mCurve.back();
	}
}

void LoadAnimChannels(FbxNode* pNode, FbxAnimLayer* pAnimLayer, AnimationNode& animnode)
{
	LoadChannel(pNode->LclTranslation.GetCurve(pAnimLayer, FBXSDK_CURVENODE_COMPONENT_X), animnode.mTranslation[0]);
	LoadChannel(pNode->LclTranslation.GetCurve(pAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y), animnode.mTranslation[1]);
	LoadChannel(pNode->LclTranslation.GetCurve(pAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z), animnode.mTranslation[2]);

	LoadChannel(pNode->LclScaling.GetCurve(pAnimLayer, FBXSDK_CURVENODE_COMPONENT_X), animnode.mScale[0]);
	LoadChannel(pNode->LclScaling.GetCurve(pAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y), animnode.mScale[1]);
	LoadChannel(pNode->LclScaling.GetCurve(pAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z), animnode.mScale[2]);

	LoadChannel(pNode, pAnimLayer, animnode.mRotation);
}

void ProcessAnimationLayer(FbxAnimLayer* pAnimLayer, FbxNode* pNode, AnimationNode& parent)
{
	parent.mChildren.push_back({});
	AnimationNode& n = parent.mChildren.back();

	auto tr = pNode->LclTranslation.Get();
	n.mLocalTransform.mV = { tr.mData[0], tr.mData[1], tr.mData[2] };
	
	auto sc = pNode->LclScaling.Get();
	n.mLocalTransform.mS = { sc.mData[0], sc.mData[1], sc.mData[2] };
	
	auto rot = pNode->LclRotation.Get();
	n.mLocalTransform.mQ = FTEQUAT{ Vec3{ rot.mData[0], rot.mData[1], rot.mData[2] } };

	n.mName = pNode->GetName();

	LoadAnimChannels(pNode, pAnimLayer, n);

	for (int i = 0; i < pNode->GetChildCount(); i++)
		ProcessAnimationLayer(pAnimLayer, pNode->GetChild(i), n);
}

void ProcessAnimationStack(FbxAnimStack* pAnimStack, FbxNode* pNode, Animation& anim)
{
	auto t = pAnimStack->GetLocalTimeSpan();

	anim.mDuration = (unsigned)t.GetDuration().GetMilliSeconds();
	anim.mFrames = (unsigned)t.GetStop().GetFrameCount();

	int num = pAnimStack->GetMemberCount<FbxAnimLayer>();
	for (int l = 0; l < num; l++)
	{
		auto& n = anim.mRootNode;

		auto rotlim = pNode->GetRotationLimits();
		auto rotmin = rotlim.GetMin();

		Vec3 minrot = { rotmin.mData[0], rotmin.mData[1], rotmin.mData[2] };

		rotmin = rotlim.GetMax();

		Vec3 maxrot = { rotmin.mData[0], rotmin.mData[1], rotmin.mData[2] };

		if (minrot != Vec3{ 0 })
			minrot = minrot;

		if (maxrot != Vec3{ 0 })
			minrot = minrot;

		auto tr = pNode->LclTranslation.Get();
		n.mLocalTransform.mV = { tr.mData[0], tr.mData[1], tr.mData[2] };
		
		auto sc = pNode->LclScaling.Get();
		n.mLocalTransform.mS = { sc.mData[0], sc.mData[1], sc.mData[2] };
		
		auto rot = pNode->LclRotation.Get();
		n.mLocalTransform.mQ = FTEQUAT{ Vec3{ rot.mData[0], rot.mData[1], rot.mData[2] } };
		//n.mLocalTransform.mRotation[0] = -90;

		ProcessAnimationLayer(pAnimStack->GetMember<FbxAnimLayer>(l), pNode, anim.mRootNode);
	}
}

void LoadAnimation(FbxScene* pScene, Animation& anim)
{
	int num = pScene->GetSrcObjectCount<FbxAnimStack>();
	for (int i = 0; i < num; i++)
	{
		FbxAnimStack* lAnimStack = pScene->GetSrcObject<FbxAnimStack>(i);
		auto n = lAnimStack->GetName();
		UNUSED_PARAM(n);

		ProcessAnimationStack(lAnimStack, pScene->GetRootNode(), anim);
	}
}

void Importer_Animation::Import(const std::string& name, const std::string& path)
{
	UNUSED_PARAM(path);
	UNUSED_PARAM(name);
}

void Importer_Animation::LoadFBXAnimation(void* stack, void* scene, Asset* asset)
{
	ProcessAnimationStack((FbxAnimStack*)stack, ((FbxScene*)scene)->GetRootNode(), *((Animation*)(asset)));
}