#pragma once

#include "DataTypes.h"

class EntitySpace;
class Entity;

class Editor
{
	friend class EditorSystem;

public:
	void RegisterWindows();

private:
	void Window_Entities();
	void ShowEntitySpaceGUI(EntitySpace* sp);

	WK_PTR<Entity> mSelectedEntity;
};