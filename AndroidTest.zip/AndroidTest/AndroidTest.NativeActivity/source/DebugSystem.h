#pragma once

#include <iostream>
#include <cstdarg>
#include <sstream>

#include "System.h"
#include "Console.h"

#include "FoxTracerEngine.h"

#define PRINT_LINE FoxTracerEngine::GetSystem<DebugSystem>().WriteLine()
#define PRINT_ERROR FoxTracerEngine::GetSystem<DebugSystem>().WriteError()	
#define PRINT_WARNING FoxTracerEngine::GetSystem<DebugSystem>().WriteWarning()
#define ASSERT FoxTracerEngine::GetSystem<DebugSystem>().WriteError()

class DebugSystem : public System
{
	RTTI_DECLARATION(DebugSystem)

public:
	struct FTEStreamBuffer : public std::stringstream
	{
		friend class DebugSystem;
		~FTEStreamBuffer();
	private:
		FTEStreamBuffer() = default;
		FTEStreamBuffer(const FTEStreamBuffer&);
		FTEStreamBuffer& operator= (const FTEStreamBuffer&) = delete;
		Vec3 mColor{1, 1, 1};
		unsigned mType{0};
	};

	void Initialize() override;
	void Update() override;
	void ShowDebug() override;
	void Shutdown() override;

	FTEStreamBuffer WriteLine(const Vec3& color = {1, 1, 1});
	std::stringstream& Write();

	FTEStreamBuffer WriteError();
	FTEStreamBuffer WriteWarning();

private:
	Console mConsole;
	std::stringstream mFrameLog;
};
	