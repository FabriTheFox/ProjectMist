#include "Editor.h"
#include "ImGUIHeaders.h"

#include "FoxTracerEngine.h"
#include "FTESystems.h"

void Editor::RegisterWindows()
{
	auto& s = FoxTracerEngine::GetSystem<EditorSystem>();
	s.AddGUIWindow(&Editor::Window_Entities, this, "Entities", "", 1);
}

void Editor::Window_Entities()
{
	auto& s = FoxTracerEngine::GetSystem<EntitySystem>();

	Entity* pent = nullptr;
	if (!mSelectedEntity.expired())
		pent = mSelectedEntity.lock().get();
	if (pent)
	{
		bool destroyit = false;

		ImGui::Columns(2);

		std::string entname = pent->GetName();

		char newname[50] = { 0 };
		for (unsigned i = 0; i < entname.size(); ++i)
			newname[i] = entname[i];

		ImGui::InputText("Name", newname, 50);

		if (std::string(newname) != entname)
			pent->SetName(newname);

		ImGui::NextColumn();

		if (ImGui::Button("Delete", { 300, ImGui::GetItemRectSize().y }))
			destroyit = true;

		ImGui::Columns(1);

		FoxTracerEngine::GetSystem<SceneSystem>().ShowComponentGUI(Entity::RTTI_, pent);
		auto& comps = pent->GetComponents();
		for (auto& cmp : comps)
			FoxTracerEngine::GetSystem<SceneSystem>().ShowComponentGUI(cmp.second->GetRTTI(), cmp.second.get());

		if (destroyit)
			pent->Destroy();
	}
	else
		ImGui::Text("No entities selected");

	ImGui::Separator();

	ImGui::BeginChild(std::to_string((int)this).c_str(), ImGui::GetContentRegionAvail(), false, ImGuiWindowFlags_HorizontalScrollbar);

	ShowEntitySpaceGUI(&s.mDefaultEntitySpace);

	ImGui::EndChild();
}

void Editor::ShowEntitySpaceGUI(EntitySpace* sp)
{
	std::string name = sp->GetName();

	if (name == "Default")
	{
		for (auto& c : sp->mChildren.AlivePtrs_)
			ShowEntitySpaceGUI(c.get());
		return;
	}

	if (name.empty())
		name = "Default";

	if (sp->mEntities.AlivePtrs_.empty() && sp->mChildren.AlivePtrs_.empty())
		return;

	if (ImGui::TreeNodeEx((void*)(intptr_t)sp, 0, name.c_str()))
	{
		for (auto& en : sp->mEntities.AlivePtrs_)
		{
			ImGuiTreeNodeFlags node_flags = ImGuiTreeNodeFlags_Leaf | ImGuiTreeNodeFlags_NoTreePushOnOpen;
			if (en == mSelectedEntity.lock())
				node_flags |= ImGuiTreeNodeFlags_Selected;
			ImGui::TreeNodeEx((void*)(intptr_t)en.get(), node_flags, en->GetName().c_str());
			if (ImGui::IsItemClicked())
				mSelectedEntity = en;
		}

		if (!sp->mEntities.AlivePtrs_.empty() && !sp->mChildren.AlivePtrs_.empty())
			ImGui::Separator();

		for (auto& c : sp->mChildren.AlivePtrs_)
			ShowEntitySpaceGUI(c.get());

		ImGui::TreePop();
	}

	if (!sp->mChildren.AlivePtrs_.empty())
		ImGui::Separator();
}