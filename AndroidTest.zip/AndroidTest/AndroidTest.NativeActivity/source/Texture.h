#pragma once

#include "DataTypes.h"
#include "Asset.h"
#include <string>

class Texture :
	public Asset,
	public std::enable_shared_from_this<Texture>
{
	ASSET_DECLARATION(Texture)
	friend class Importer_Texture;
	
public:
	Texture() = default;
	void Bind(int unit = 0);

	const IVec2& GetTextureSize();
	const unsigned& GetIndex();
	void Load(unsigned char * pixels, unsigned w, unsigned h);
	void Free();

	void SaveToFile(std::string& name);

private:
	unsigned mIndex{ 0 };
	IVec2 mTextureSize;
};