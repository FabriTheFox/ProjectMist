#pragma once

#include "System.h"
#include <unordered_map>
#include "DebugSystem.h"

#include "Importer.h"

#include "Shader.h"
#include "Model.h"

class Asset;

class AssetSystem : public System
{
	RTTI_DECLARATION(AssetSystem)

public:
	void Initialize() override;
	void Update() override;

	void LoadAsset(const std::string& path, const std::string& name = "");

	template <typename T>
	SHD_PTR<T> GetAsset(const std::string& name)
	{
		auto itr = mAssets.find(T::RTTI_.mTypehash);
		if (itr == mAssets.end())
			PRINT_ERROR << "Asset type not existent" << std::endl;
		auto asset = itr->second.find(name);
		if (asset == itr->second.end())
			PRINT_ERROR << "Asset not existent" << std::endl;
		return SHD_CAST(T)(asset->second);
	}

	template <typename T>
	T& RegisterAsset(const std::string name)
	{
		auto& assettype = mAssets[T::RTTI_.mTypehash];
		auto itr = assettype.find(name);
		if (itr != assettype.end())
			return *(SHD_CAST(T)(itr->second));

		auto newasset = std::make_shared<T>();
		newasset->mName = name;
		assettype[name] = newasset;
		return *newasset;
	}

private:
	void LoadPrimitives();

	void LoadPrimitiveModels();
	void LoadPoint(std::vector<Vertex>& vert, std::vector<unsigned>& ind);
	void LoadQuad(std::vector<Vertex>& vert, std::vector<unsigned>& ind);
	void LoadLine(std::vector<Vertex>& vert, std::vector<unsigned>& ind);
	void LoadCube(std::vector<Vertex>& vert, std::vector<unsigned>& ind);
	void LoadWireCube(std::vector<Vertex>& vert, std::vector<unsigned>& ind);
	void LoadCloth(std::vector<Vertex>& vert, std::vector<unsigned>& ind);

	void LoadPrimitiveShaders();

	template <typename T>
	void AssignImporterExtension(const std::string& ext)
	{
		mImporters[ext] = T::GetInstance();
	}

	std::unordered_map<std::string, WK_PTR<Importer>> mImporters;
	std::unordered_map<size_t, std::unordered_map<std::string, SHD_PTR<Asset>>> mAssets;
};