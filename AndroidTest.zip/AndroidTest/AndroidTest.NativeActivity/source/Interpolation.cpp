#include "Interpolation.h"
#include "Utilities.h"

double QuadCurve::EvaluateAt(float tt) const
{
	double t = (double)tt;
	double t2 = t * t;
	double t3 = t2 * t;
	return (mA * t3) + (mB * t2) + (mC * t) + (mD);
}

double QuadCurve::EvaluateDerivativeAt(float tt) const
{
	double t = (double)tt;
	double t2 = t * t;
	return (3 * mA * t2) + (2 * mB * t) + (mC);
}

void BezierCurve::Construct(const double& p0, const double& p1, const double& p2, const double& p3)
{
	// Definition of Bezier curves of degree 4
	mCurve.mC = 3.0 * (p1 - p0);
	mCurve.mB = 3.0 * (p2 - p1) - mCurve.mC;
	mCurve.mA = p3 - p0 - mCurve.mC - mCurve.mB;
	mCurve.mD = p0;
}

void BezierCurve3D::Construct(const Vec3& p0, const Vec3& p1, const Vec3& p2, const Vec3& p3)
{
	mCurveX.Construct(p0.x, p1.x, p2.x, p3.x);
	mCurveY.Construct(p0.y, p1.y, p2.y, p3.y);
	mCurveZ.Construct(p0.z, p1.z, p2.z, p3.z);
}

void BezierCurve3D::Construct(const BezierCurve3D& derivstart, const Vec3& p0, const Vec3& p1, const Vec3& next)
{
	// Force first order continuity with the last curve
	// With points p0, p1, p2, p3, the first derivative at t = 0 is:
	// 3*p1 - 3*p0
	// So we make it equal to the derivative of the last curve at t = 1 and solve for p1
	auto p01 = (derivstart.EvaluateDerivativeAt(1) + (3.f * p0)) / 3.f;

	// Create p2 based on the next point to interpolate
	auto p02 = (p1 - ((next - p1)*0.5f));

	Construct(p0, p01, p02, p1);
}

Vec3 BezierCurve3D::EvaluateAt(float t) const
{
	return { mCurveX.mCurve.EvaluateAt(t), mCurveY.mCurve.EvaluateAt(t), mCurveZ.mCurve.EvaluateAt(t) };
}

Vec3 BezierCurve3D::LinearSpeedEvaluateAt(float t) const
{
	return LinearSpeedEvaluateAtDistance(GetTotalArclength() * t);
}

Vec3 BezierCurve3D::LinearSpeedEvaluateAtDistance(float dis) const
{
	// Get the corresponding index to the table
	int index = GetTCorrespondingToDistance(dis);

	auto& curr = mArclengthMarks[index];
	auto& next = mArclengthMarks[index + 1];

	// Linearly interpolate t between last and next t's
	float curr_t = Utilities::LERP(curr.mT, next.mT, (dis - curr.mArcLength) / (next.mArcLength - curr.mArcLength));

	// Evaluate it at that t, this gives a pseudo-correct inteporlation respect to the arclength
	return EvaluateAt(curr_t);
}

Vec3 BezierCurve3D::EvaluateDerivativeAt(float t) const
{
	return { mCurveX.mCurve.EvaluateDerivativeAt(t), mCurveY.mCurve.EvaluateDerivativeAt(t), mCurveZ.mCurve.EvaluateDerivativeAt(t) };
}

void BezierCurve3D::ConstructArcLengthTable(int precision)
{
	float accumulated = 0;
	Vec3 last = EvaluateAt(0);
	mArclengthMarks.clear();

	for (int i = 0; i <= precision; ++i)
	{
		// Evaluate at equally spaced t's
		float t = float(i) / precision;
		Vec3 curr = EvaluateAt(t);

		// Accumulate the distance between last and current evaluated points
		accumulated += glm::length(curr - last);

		// Store the accumulated arclength at its t
		mArclengthMarks.push_back({ t,  accumulated});
		last = curr;
	}
}

float BezierCurve3D::GetTotalArclength() const
{
	// The last stored value on the table constains the accumulated arclength of the curve
	return mArclengthMarks.back().mArcLength;
}

int BezierCurve3D::GetTCorrespondingToDistance(float dis) const
{
	// Perform binary search to find the corresponding t value to the given distance
	unsigned l = 0;
	int r = (int)mArclengthMarks.size() - 1;
	while (r - l > 1)
	{
		unsigned i = l + ((r - l) / 2);
		if (mArclengthMarks[i].mArcLength > dis)
			r = i;
		else if (mArclengthMarks[i].mArcLength < dis)
			l = i;
		else
			return i;
	}
	return l;
}

void MultiBezier3D::ConstructCircular(const std::vector<Vec3>& points)
{
	if (points.size() < 2)
		return;

	// Construct the first curve
	const Vec3& next = points.size() > 2 ? points[2] : points[0];
	mCurves.resize(points.size());
	mCurves[0].Construct(points[0], points[0], points[1] - ((next - points[1])*0.5f), points[1]);

	// For all the points on the vector
	for (unsigned i = 1; i < points.size() - 1; ++i)
	{
		// Get the next point to interpolate
		const Vec3& p1 = i < points.size() - 1 ? points[i + 1] : points[0];
		// Get the next-next point to approximate the shape of the curve
		const Vec3& next = i < points.size() - 2 ? points[i + 2] : points[i + 2 - points.size()];

		// Construct the curve
		mCurves[i].Construct(mCurves[i - 1], points[i], p1, next);
	}

	// Construct the last curve, matching with the first
	auto p2 = (mCurves[mCurves.size() - 1].EvaluateDerivativeAt(1) + (3.f * points.back())) / 3.f;
	auto p3 = (Vec3{0, 0, 0} -(3.f * points.front())) / -3.f;
	mCurves.back().Construct(points.back(), p2, p3, points.front());
}

void MultiBezier3D::Construct(const std::vector<Vec3>& points)
{
	if (points.size() < 2)
		return;

	// Construct the first curve
	const Vec3& next = points.size() > 2 ? points[2] : points[0];
	mCurves.resize(points.size());
	mCurves[0].Construct(points[0], points[0], points[1] - ((next - points[1])*0.5f), points[1]);

	// For all the points on the vector
	for (unsigned i = 1; i < points.size() - 1; ++i)
	{
		// Get the next point to interpolate
		const Vec3& p1 = i < points.size() - 1 ? points[i + 1] : points[0];
		// Get the next-next point to approximate the shape of the curve
		const Vec3& next = i < points.size() - 2 ? points[i + 2] : p1;

		// Construct the curve
		mCurves[i].Construct(mCurves[i - 1], points[i], p1, next);
	}
}

Vec3 MultiBezier3D::EvaluateAt(float t) const
{
	// Get how much of t corresponds to each curve
	float interval = 1.f / mCurves.size();
	
	// Get the curve index corresponding to this t
	int curveind = (int)(t / interval);

	// Remap t to (0 - 1) range
	float mappedt = (t / interval) - (int)(t / interval);

	// Evaluate the curve
	return mCurves[curveind].EvaluateAt(mappedt);
}

Vec3 MultiBezier3D::EvaluateAtDistance(float dis) const
{
	float arcl = 0;

	// Find what is the corresponding curve at the accumulated distance
	for (unsigned i = 0; i < mCurves.size(); ++i)
	{
		float nextdis = mCurves[i].GetTotalArclength();
		// Evaluate at the local curve distance
		if (dis <= (arcl + nextdis))
			return mCurves[i].LinearSpeedEvaluateAtDistance(dis - arcl);
		arcl += nextdis;
	}

	// If the distance is bigger than the multicurve, return the last point
	return mCurves.back().EvaluateAt(1.f);
}

Vec3 MultiBezier3D::LinearSpeedEvaluateAt(float t) const
{
	return EvaluateAtDistance(t * GetTotalArcLength());
}

float MultiBezier3D::GetTotalArcLength() const
{
	float total = 0;
	for (auto& c : mCurves)
		total += c.GetTotalArclength();
	return total;
}

void MultiBezier3D::ConstructArcLengthTables(int precisionpersegment)
{
	for (auto& c : mCurves)
		c.ConstructArcLengthTable(precisionpersegment);
}