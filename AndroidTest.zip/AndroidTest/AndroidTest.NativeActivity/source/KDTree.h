#pragma once

#include "SpacePartition.h"
#include "Intersection.h"

class KDTree
{
	//NON_COPYABLE(KDTree)

public:
	KDTree() = default;
	~KDTree();

	unsigned BuildKDTree(std::vector<FTEIntersection::Triangle>& triangles, unsigned maxlevel);

	void RenderTree(unsigned maxlevel, bool drawparents, const std::string& layer);
	void DeleteTree();

	FTEIntersection::IntersectionResult TraceRay(const Vec3& start, const Vec3& dir);

	float& GetIntersectionCost();
	float& GetTraverseCost();
	unsigned GetLevel();

private:
	struct KDNode
	{
		FTEIntersection::IntersectionResult TraceRay(const Vec3& start, const Vec3& dir);

		AABB mBoundingVolume;
		Vec2 mPlane;

		KDNode* mChildLeft{ nullptr };
		KDNode* mChildRight{ nullptr };

		std::vector<FTEIntersection::Triangle> mTriangles;
		unsigned mLevel{0};
	};

	struct KDEvent
	{
		enum Type
		{
			ENDING = 0,
			COPLANAR = 1,
			STARTING = 2
		};

		bool operator< (const KDEvent& rhs) const;

		unsigned mTriangleIndex;

		Type mEventType;
		float mPosition;
		float mEndPosition;
	};

	struct NodeToRender
	{
		NodeToRender(const AABB& aabb, const unsigned& level) : mBoundingVolume(aabb), mLevel(level) {}
		AABB mBoundingVolume;
		unsigned mLevel;
	};

	void InternalBuild(const std::vector<FTEIntersection::Triangle>& triangles, KDNode* node);
	Vec2 GetSplittingPlane(const std::vector<FTEIntersection::Triangle>& triangles, KDNode* node);
	void GenerateEventList(const std::vector<FTEIntersection::Triangle>& triangles, unsigned axis, std::vector<KDEvent>& evlist, const AABB& aabb);
	void DeleteNode(KDNode* node);
	FTEIntersection::IntersectionResult TraceRayNode(const Vec3& start, const Vec3& dir, KDNode* node);

	std::vector<FTEIntersection::Triangle> mTriangles;

	unsigned mMaxLevel;
	unsigned mTreeLevel;

	float mIntersectionCost{0.1f};
	float mTraverseCost{1.f};

	KDNode* mRoot{ nullptr };
	std::vector<KDEvent> mCurrEventList;
	std::vector<NodeToRender> mNodesToRender;
};