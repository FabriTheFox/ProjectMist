#include "Transform.h"

Transform::Transform(const Vec3& p, const Vec3& s, const Vec3& r) : mPosition(p), mScale(s), mRotation(r) {}

Mat4 Transform::GetModelMatrix()
{
	Mat4 Mat = GetRotationMatrix();
	Mat[3][0] = mPosition.x;
	Mat[3][1] = mPosition.y;
	Mat[3][2] = mPosition.z;
	Mat = glm::scale(Mat, mScale);
	return Mat;
}

Mat4 Transform::GetInvMatrix()
{
	Mat4 mat;
	mat = glm::scale(mat, 1.f / mScale);
	mat = glm::rotate(mat, glm::radians(-mRotation.z), glm::fvec3(0, 0, 1));
	mat = glm::rotate(mat, glm::radians(-mRotation.y), glm::fvec3(0, 1, 0));
	mat = glm::rotate(mat, glm::radians(-mRotation.x), glm::fvec3(1, 0, 0));
	mat = glm::translate(mat, -mPosition);
	return mat;
}

Mat4 Transform::GetRotationMatrix()
{
	Mat4 Mat;
	Mat = glm::rotate(Mat, glm::radians(mRotation.z), glm::fvec3(0, 0, 1));
	Mat = glm::rotate(Mat, glm::radians(mRotation.y), glm::fvec3(0, 1, 0));
	Mat = glm::rotate(Mat, glm::radians(mRotation.x), glm::fvec3(1, 0, 0));
	return Mat;
}

void Transform::OrientTo(const Vec3& target, const Vec3& axis, const Vec3& up)
{
	auto orient = glm::normalize(target - mPosition);
	auto naxis = glm::normalize(axis);

	auto around = glm::normalize(glm::cross(naxis, orient));

	Mat4 rotationmat;
	rotationmat = glm::rotate(rotationmat, glm::acos(glm::dot(naxis, orient)), around);

	mRotation = GetEulerAnglesFromMatrix(rotationmat);
	
	Vec3 nright = glm::normalize(glm::cross(orient, Vec3{0, 1, 0}));
	Vec3 nup = -glm::normalize(glm::cross(orient, nright));

	Vec3 v = VectorToLocal(up);
	float deg = -glm::degrees(glm::acos(glm::dot(v, nup)));

	if (glm::dot(nright, v) < 0)
		deg = -deg;
	
	RotateAround(axis, deg);
}

void Transform::RotateAround(const Vec3& axis, float deg)
{
	Mat4 rotationmat = glm::rotate(GetRotationMatrix(), glm::radians(deg), glm::normalize(axis));
	mRotation = GetEulerAnglesFromMatrix(rotationmat);
}

Vec3 Transform::GetEulerAnglesFromMatrix(const Mat4& mat)
{
	if (std::abs(mat[0][2]) != 1)
		return -glm::degrees(Vec3{atan2(-mat[1][2], mat[2][2]), asin(mat[0][2]), atan2(-mat[0][1], mat[0][0])});
	else
		return -glm::degrees(Vec3{ 0.f, mat[0][2] * glm::radians(90.f), atan2(mat[1][0], mat[1][1]) });
}

Vec3 Transform::VectorToLocal(const Vec3& vec)
{
	return glm::normalize(Vec3(GetModelMatrix() * Vec4 { vec, 0.f }));
}

Vec3 Transform::VectorToParent(const Vec3& vec)
{
	return glm::normalize(Vec3(GetInvMatrix() * Vec4 { vec, 0.f }));
}

Vec3 Transform::PositionToLocal(const Vec3& pos)
{
	return Vec3(GetModelMatrix() * Vec4{ pos, 1.f });
}

Vec3 Transform::PositionToParent(const Vec3& pos)
{
	return Vec3(GetInvMatrix() * Vec4{ pos, 1.f });
}

Vec3 Transform::TransformPosition(const Mat4& mat) const
{
	return Vec3(mat * Vec4(mPosition, 1));
}