#include "ClothAnimatorCmp.h"
#include "RTTI_imp.h"

#include "FrameRateController.h"
#include "Intersection.h"

#include "AssetSystem.h"

COMPONENT_SERIALIZABLE_IMPLEMENTATION(ClothAnimatorCmp);
REGISTER_PROPERTIES(ClothAnimatorCmp){}

void ClothAnimatorCmp::Initialize()
{
	Resize();

	// Initialize meshes for drawing
	mConstraintMesh.mMeshes.push_back({});
	mPointsMesh.mMeshes.push_back({});
	mTriangleMesh.mMeshes.push_back({});
}

#include <iostream>
void ClothAnimatorCmp::Update()
{
	// Precompute delta time and delta time^2
	mDeltaTime = FoxTracerEngine::GetSystem<FrameRateController>().GetFrameTimeMilliseconds() * 3.2f;
	mDeltaTimeSQ = mDeltaTime * mDeltaTime;

	VerletIntegration();	// Resolve particle's position based on its acc.
	SatisfyConstraints();	// Apply mesh links restrictions
	ApplyGravity();			// Reset acc to gravity value for next frame
}

void ClothAnimatorCmp::Reset()
{
	GenerateInitialPositions();
	for (auto& c : mConstraints)
		c.mActive = true;
}

void ClothAnimatorCmp::Resize(const Vec2& length, const IVec2& pointres)
{
	// Do not support smaller meshes than 2x2
	if (pointres.x < 2 || pointres.y < 2)
		return;
	if (length == mLength && pointres == mPointsSize)
		return;

	// Resize if the sizes have changed
	mPointsSize = pointres;
	mLength = length;
	Resize();
}

void ClothAnimatorCmp::ApplyWindForce(const Vec3& dir, float strength)
{
	auto compute_normal = [](const Vec3& a, const Vec3& b, const Vec3& c){
		return glm::normalize(glm::cross(b - a, c - a)); };

	// COmpute the normalized and scaled wind directions
	auto ndir = glm::normalize(dir);
	auto sc = ndir * strength;

	// For every particle
	for (int y = 0; y < mPointsSize.y - 1; ++y)
	{
		for (int x = 0; x < mPointsSize.x - 1; ++x)
		{
			int curr = (y*mPointsSize.x) + x;

			// Get the normal of both triangles
			auto n0 = compute_normal(mPos[curr], mPos[curr + 1], mPos[curr + mPointsSize.x]);
			auto n1 = compute_normal(mPos[curr+1], mPos[curr + 1+mPointsSize.x], mPos[curr + mPointsSize.x]);

			// Get the force to apply based on the triangles' normal and the wind direction
			auto f0 = glm::abs(glm::dot(n0, ndir)) * sc;
			auto f1 = glm::abs(glm::dot(n1, ndir)) * sc;

			// Apply the force to every particle on the two triangles
			ApplyForceTo(curr, f0);
			ApplyForceTo(curr+1, f0);
			ApplyForceTo(curr + mPointsSize.x, f0);

			ApplyForceTo(curr+1, f1);
			ApplyForceTo(curr + 1 + mPointsSize.x, f1);
			ApplyForceTo(curr + mPointsSize.x, f1);
		}
	}
}

void ClothAnimatorCmp::CollideWithSphereAt(const Vec3& center, float radius)
{
	auto c = center;

	// Use the radius^2 for compraison
	float radsq = radius * radius;

	for (unsigned i = 0; i < mNumPoints; ++i)
	{
		// Do not displace particles if has infinite mass
		if (mInvMass[i] == 0)
			continue;

		auto& p = mPos[i];

		// COmpute particles distance to the sphere center
		auto v = c - p;
		float distsq = glm::dot(v, v);

		// smaller than radius?
		if (distsq < radsq)
		{
			// Push the particle to the sphere surface
			float m = radius - glm::sqrt(distsq);
			p += glm::normalize(v) * (-m);
		}
	}
}

void ClothAnimatorCmp::CollideWithBoxAt(const Vec3& size)
{
	// Make every particle stay inside of the box
	for (auto& p : mPos)
	{
		p.x = Utilities::Clamp(p.x, -size.x, size.x);
		p.y = Utilities::Clamp(p.y, -size.y, size.y);
		p.z = Utilities::Clamp(p.z, -size.z, size.z);
	}
}

void ClothAnimatorCmp::CutConstraintsThrough(const Vec3& a, const Vec3& b, const Vec3& c)
{
	// Construct a triangle based on the points
	FTEIntersection::Triangle tr(a, b, c);
	tr.ComputeNormal();

	// For every constraint link
	for (auto& c : mConstraints)
	{
		// Get the link segment representation
		auto v = mPos[c.mB] - mPos[c.mA];
		auto res = tr.TraceRay(mPos[c.mA], glm::normalize(v));

		// Check intersection plane - link and disable the link if true
		if (res.HasCollided() && res.mDis < glm::length(v))
			c.mActive = false;
	}
}

void ClothAnimatorCmp::ReleaseBars(bool a, bool b, bool c, bool d)
{
	// Make the top particles mass not equal to 0
	unsigned qs = mPointsSize.x / 4;
	if (mBars[0] && !a)
	{
		mBars[0] = false;
		for (unsigned i = 0; i < qs; ++i)
			mInvMass[i] = Utilities::Random(0.4f, 0.6f);
	}
	if (mBars[1] && !b)
	{
		mBars[1] = false;
		for (unsigned i = qs; i < 2*qs; ++i)
			mInvMass[i] = Utilities::Random(0.4f, 0.6f);
	}
	if (mBars[2] && !c)
	{
		mBars[2] = false;
		for (unsigned i = qs * 2; i < 3*qs; ++i)
			mInvMass[i] = Utilities::Random(0.4f, 0.6f);
	}
	if (mBars[3] && !d)
	{
		mBars[3] = false;
		for (unsigned i = qs * 3; i < (unsigned)mPointsSize.x; ++i)
			mInvMass[i] = Utilities::Random(0.4f, 0.6f);
	}
}

void ClothAnimatorCmp::ApplyForceTo(int indx, const Vec3& f)
{
	mAcceleration[indx] += mInvMass[indx] * f;
}

void ClothAnimatorCmp::Resize()
{
	mNumPoints = mPointsSize.x * mPointsSize.y;

	mPos.resize(mNumPoints);
	mLastPos.resize(mNumPoints);
	mAcceleration.resize(mNumPoints);
	mInvMass.resize(mNumPoints);

	mConstraints.clear();
	mConstraints.reserve(mNumPoints);

	GenerateInitialPositions();
	GenerateConstraints();
}

void ClothAnimatorCmp::GenerateInitialPositions()
{
	// Make the top part stay at the owner's position
	Vec3& orig = GetTransform().mPosition;

	// For every particle
	for (int y = 0; y < mPointsSize.y; ++y)
	{
		for (int x = 0; x < mPointsSize.x; ++x)
		{
			// Compute the position in a 1x1 plane
			float xx = ((float)x / (mPointsSize.x-1)) - 0.5f;
			float yy = -((float)y / (mPointsSize.y-1));

			// Scale it to the actual size
			xx = (xx * mLength.x) + orig.x;
			yy = (yy * mLength.y) + orig.y;

			int idx = (y * mPointsSize.x) + x;

			// Initialize every particle
			mPos[idx] = { xx, yy, 00 };
			mLastPos[idx] = { xx, yy, 00 };
			mAcceleration[idx] = { 0, 0, 0 };
			mInvMass[idx] = Utilities::Random(0.4f, 0.6f);
		}
	}

	// Make the top particles (first row) have infinite mass not to move
	for (int x = 0; x < mPointsSize.x; ++x)
		mInvMass[x] = 0;
	for (int i = 0; i < 4; ++i)
		mBars[i] = true;
}

void ClothAnimatorCmp::PushConstraint(int a, int b, float dis)
{
	mConstraints.push_back({});
	Constraint& c = mConstraints.back();
	c.mA = a;
	c.mB = b;
	c.mLength = dis;
}

void ClothAnimatorCmp::GenerateConstraints()
{
	// Precompute resting positions for the links
	float strucx = glm::length(mPos[0] - mPos[1]);
	float strucy = glm::length(mPos[0] - mPos[mPointsSize.x]);
	float shear = glm::length(mPos[0] - mPos[mPointsSize.x + 1]);

	// Generate first all the structural links (for easier creation of the triangle mesh)
	for (int y = 0; y < mPointsSize.y; ++y)
	{
		for (int x = 0; x < mPointsSize.x; ++x)
		{
			int curr = (y*mPointsSize.x) + x;

			// Structural
			if (x < mPointsSize.x - 1)
				PushConstraint(curr, curr + 1, strucx);					// Horizontal
			
			if (y < mPointsSize.y - 1)
				PushConstraint(curr, curr + mPointsSize.x, strucy);		// Vertical
		}
	}

	// Generate the shear and bend constraints
	for (int y = 0; y < mPointsSize.y; ++y)
	{
		for (int x = 0; x < mPointsSize.x; ++x)
		{
			int curr = (y*mPointsSize.x) + x;

			// Shear
			if (x < mPointsSize.x - 1 && y < mPointsSize.y - 1)
				PushConstraint(curr, curr + mPointsSize.x + 1, shear);

			if (x > 0 && y < mPointsSize.y - 1)
				PushConstraint(curr, curr + mPointsSize.x - 1, shear);

			// Bend
			if (x < mPointsSize.x - 2)
				PushConstraint(curr, curr + 2, 2 * strucx);

			if (y < mPointsSize.y - 2)
				PushConstraint(curr, curr + (2 * mPointsSize.x), 2 * strucy);
		}
	}
}

void ClothAnimatorCmp::VerletIntegration()
{
	for (unsigned i = 0; i < mNumPoints; ++i)
	{
		Vec3& curr = mPos[i];
		Vec3& last = mLastPos[i];
		Vec3& acc = mAcceleration[i];
		Vec3 temp = curr;

		// Use each particle's last position instead of its velocity
		curr += ((1-mDrag)*(curr - last)) + (acc * mDeltaTimeSQ);
		last = temp;
	}
}

void ClothAnimatorCmp::ApplyGravity()
{
	for (unsigned i = 0; i < mNumPoints; ++i)
		mAcceleration[i] = mGravity * mInvMass[i] * mGravityStrength;
}

void ClothAnimatorCmp::SatisfyConstraints()
{
	// Apply the relaxation N times
	for (unsigned i = 0; i < mRestrictionIterations; ++i)
	{
		// First resolve the collisions
		CollideWithBoxAt(mBoxLimits);
		CollideWithSphereAt(mSpherePosition, mSphereRadius);

		// Then resolve the interparticle links
		for (auto& c : mConstraints)
		{
			if (!c.mActive)
				continue;

			// Get both particles
			Vec3& x1 = mPos[c.mA];
			Vec3& x2 = mPos[c.mB];

			// Get direction from A to B
			Vec3 d = x2 - x1;

			// Check if the particles have infinite mass
			float masses = mInvMass[c.mA] + mInvMass[c.mB];
			if (masses == 0)
				continue;

			// Get the distance between them
			float dl = glm::sqrt(glm::dot(d, d));
			// Get the amount to move each particle
			float diff = (dl - c.mLength) / (dl * masses);

			// Scale the force to the mass and restitution of the system
			x1 += d * mInvMass[c.mA] * diff * mRestitution;
			x2 -= d * mInvMass[c.mB] * diff * mRestitution;
		}
	}
}


void ClothAnimatorCmp::UpdateWireMeshes()
{
	std::vector<Vertex> vert;
	vert.reserve(mNumPoints);

	std::vector<unsigned> ind;
	ind.reserve(mConstraints.size() * 2);

	for (auto& p : mPos)
		vert.push_back({ p, { 0, 0 }, { 0, 0, 0 } });
	for (auto& c : mConstraints)
	{
		if (!c.mActive)
			continue;
		ind.push_back(c.mA);
		ind.push_back(c.mB);
	}

	if (mConstraintMesh.mMeshes.back().mVertexCount == 0)
		mConstraintMesh.mMeshes.back().UploadToGpu(vert, ind);
	else
		mConstraintMesh.mMeshes.back().UploadToGpuUpdate(vert, ind);

	ind.clear();
	for (unsigned i = 0; i < mNumPoints; ++i)
		ind.push_back(i);

	if (mPointsMesh.mMeshes.back().mVertexCount == 0)
		mPointsMesh.mMeshes.back().UploadToGpu(vert, ind);
	else
		mPointsMesh.mMeshes.back().UploadToGpuUpdate(vert, ind);
}

void ClothAnimatorCmp::UpdateTriangleMesh()
{
	std::vector<Vertex> vert(mNumPoints);

	std::vector<unsigned> ind;
	ind.reserve(mConstraints.size() * 2);

	auto compute_normal = [](const Vec3& a, const Vec3& b, const Vec3& c){
		return glm::normalize(glm::cross(b - a, c - a)); };

	for (int y = 0; y < mPointsSize.y - 1; ++y)
	{
		for (int x = 0; x < mPointsSize.x - 1; ++x)
		{
			int curr = (y*mPointsSize.x) + x;
			int curr_c = (y*(2 * mPointsSize.x - 1)) + (2*x);

			int a = curr_c;
			int b = curr_c + 1;

			int c = (x == mPointsSize.x - 2) ? curr_c + 2 : curr_c + 3;
			int d = (y == mPointsSize.y - 2) ? (((mPointsSize.x - x) * 2) - 1) + x + curr_c : curr_c + (2 * mPointsSize.x - 1);

			if (mConstraints[a].mActive && mConstraints[b].mActive)
			{
				ind.push_back(curr);
				ind.push_back(curr+1);
				ind.push_back(curr+mPointsSize.x);

				vert[curr].mNormal = compute_normal(mPos[curr], mPos[curr + 1], mPos[curr + mPointsSize.x]);
			}

			if (mConstraints[c].mActive && mConstraints[d].mActive)
			{
				ind.push_back(curr + 1);
				ind.push_back(curr + 1 + mPointsSize.x);
				ind.push_back(curr + mPointsSize.x);

				vert[curr].mNormal = compute_normal(mPos[curr + 1], mPos[curr + 1 + mPointsSize.x], mPos[curr + mPointsSize.x]);
			}
		}
	}

	for (int y = 0; y < mPointsSize.y; ++y)
	{
		for (int x = 0; x < mPointsSize.x; ++x)
		{
			float tx = ((float)x / (mPointsSize.x - 1));
			float ty = ((float)y / (mPointsSize.y - 1));
			int idx = (y * mPointsSize.x) + x;
			vert[idx].mPosition = mPos[idx];
			vert[idx].mTexCoord = { tx, 1 - ty };
		}
	}

	if (mTriangleMesh.mMeshes.back().mVertexCount == 0)
		mTriangleMesh.mMeshes.back().UploadToGpu(vert, ind);
	else
		mTriangleMesh.mMeshes.back().UploadToGpuUpdate(vert, ind);
}