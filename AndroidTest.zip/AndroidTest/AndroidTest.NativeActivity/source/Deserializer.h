#pragma once

#include <string>
#include <fstream>

#include "SerData.h"
#include "DataTypes.h"
#include "Property.h"

class Deserializer
{
public:
	Deserializer();
	Deserializer& operator=(const Deserializer&) = delete;

	void LoadLevel(const std::string& level);
	void LoadConfigFile();

private:
	void RegisterBasicTypes();

	template <typename T>
	void RegisterBasicType() { mBasicTypes[typeid(T).hash_code()] = typeid(T).name();}

	void InternalLoad(std::ifstream& file);
	void LoadProperties(std::ifstream& file, std::unordered_map<std::string, SHD_PTR<IProperty>>& parent_prop, void* parent);
	void LoadComponents(std::ifstream& file, void* parent);
	bool LoadBasic(size_t hash, const std::string& data, SerData& d);

	void ReadVector(const std::string& line, std::vector<float>& vec);

	void RemoveTabsAndSpaces(std::string& str);
	void RemoveTabsAndCornerSpaces(std::string& str);

	std::unordered_map<std::string, std::unordered_map<std::string, SHD_PTR<IProperty>>>& mProperties;
	//std::unordered_map<std::string, FoxTracerEngine::RTTI>& mRTTIs;
	std::unordered_map<size_t, std::string> mBasicTypes;
};