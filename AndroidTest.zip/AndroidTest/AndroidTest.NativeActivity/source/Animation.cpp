#include "Animation.h"
#include "FoxTracerEngine.h"
#include "FrameRateController.h"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "RTTI_imp.h"
#include <cmath>

VQS_Transform AnimationNode::GetLocalTransform(float frame)
{
	VQS_Transform CurrentTransform = mLocalTransform;
	
	// Update every channel of pos
	for (unsigned i = 0; i < 3; ++i)
		mTranslation[i].Evaluate(frame, CurrentTransform.mV[i]);
	// Update every channel od the scale
	for (unsigned i = 0; i < 3; ++i)
		mScale[i].Evaluate(frame, CurrentTransform.mS[i]);
	// Update the rotation
	mRotation.Evaluate(frame, CurrentTransform.mQ);
	return CurrentTransform;
}

AnimationNode* AnimationNode::GetAnimationNode(const std::string& name)
{
	if (mName == name)
		return this;
	for (auto& c : mChildren)
	{
		auto n = c.GetAnimationNode(name);
		if (n)
			return n;
	}
	return nullptr;
}

bool AnimationNode::Constraint::ApplyConstraint(Vec3& v)
{
	bool changed = false;
	for (int i = 0; i < 3; ++i)
	{
		if (v[i] > mMax[i])
		{
			changed = true;
			v[i] = mMax[i];
		}
		if (v[i] < mMin[i])
		{
			changed = true;
			v[i] = mMin[i];
		}
	}
	return changed;
}

void AnimationNode::Constraint::Set(const Vec3& min, const Vec3& max)
{
	mMin = min;
	mMax = max;
}

ASSET_IMPLEMENTATION(Animation);

void Animation::GetAnimationInstance(AnimationInstance& anim)
{
	anim.mAnimation = shared_from_this();
	CopyAnimationInstanceNode(anim.mRootNode, nullptr, mRootNode);
}

void Animation::CopyAnimationInstanceNode(AnimationInstanceNode& instnode, AnimationInstanceNode* parent, AnimationNode& node)
{
	instnode.mParent = parent;
	instnode.mLocalTransform = node.GetLocalTransform(0.f);
	instnode.mAnimationNode = &node;

	instnode.mChildren.resize(node.mChildren.size());
	for (unsigned i = 0; i < node.mChildren.size(); ++i)
		CopyAnimationInstanceNode(instnode.mChildren[i], &instnode, node.mChildren[i]);
}

void AnimationInstanceNode::UpdateNodeTransformRecurse(float fr, AnimationNode& node, const VQS_Transform& tr)
{
	mLocalTransform = node.GetLocalTransform(fr);
	mWorldTransform = mLocalTransform;
	mWorldTransform.Concatenate(tr);
	for (unsigned i = 0; i < mChildren.size(); ++i)
		mChildren[i].UpdateNodeTransformRecurse(fr, node.mChildren[i], mWorldTransform);
}

void AnimationInstanceNode::UpdateNodeTransformRecurse(const VQS_Transform& tr)
{
	mWorldTransform = mLocalTransform;
	mWorldTransform.Concatenate(tr);
	for (unsigned i = 0; i < mChildren.size(); ++i)
		mChildren[i].UpdateNodeTransformRecurse(mWorldTransform);
}

void AnimationInstanceNode::UpdateNodeTransform(const VQS_Transform& tr)
{
	mWorldTransform = mLocalTransform;
	mWorldTransform.Concatenate(tr);
}

const VQS_Transform& AnimationInstanceNode::GetWorldTransform()
{
	return mWorldTransform;
}

const Vec3& AnimationInstanceNode::GetWorldPos()
{
	return mWorldTransform.mV;
}

void AnimationInstance::UpdateAnimation(float fr, const VQS_Transform& parent)
{
	if (mAnimation.expired())
		return;
	mRootNode.UpdateNodeTransformRecurse(fr, mAnimation.lock()->mRootNode, parent);
}

void AnimationInstance::UpdateAnimation(const VQS_Transform& parent)
{
	if (mAnimation.expired())
		return;
	mRootNode.UpdateNodeTransformRecurse(parent);
}

WK_PTR<Animation> AnimationInstance::GetAnimation()
{
	return mAnimation;
}

AnimationInstanceNode& AnimationInstance::GetAnimationNode(const std::string& name)
{
	return *FindAnimationNodeInternal(mRootNode, name);
}

AnimationInstanceNode* AnimationInstance::FindAnimationNodeInternal(AnimationInstanceNode& node, const std::string& name)
{
	if (node.mAnimationNode->mName == name)
		return &node;
	for (auto& c : node.mChildren)
		if (auto n = FindAnimationNodeInternal(c, name))
			return n;
	return nullptr;
}