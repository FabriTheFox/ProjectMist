#include "EditorSystem.h"
#include "FoxTracerEngine.h"
#include "FTESystems.h"
#include "RTTI_imp.h"

#include "OpenGLHeaders.h"
#include "ImGUIHeaders.h"

RTTI_IMPLEMENTATION(EditorSystem);

std::vector<std::vector<EditorSystem::GUIWindow*>>* EditorSystem::GUIWindow::mpActiveWindowList = nullptr;
std::vector<std::vector<EditorSystem::GUIWindow*>>* EditorSystem::GUIWindow::mpDeleteWindowList = nullptr;

void EditorSystem::Initialize() 
{
	GUIWindow::mpActiveWindowList = &mActiveWindowList;
	GUIWindow::mpDeleteWindowList = &mDeleteWindowList;

	mActiveWindowList.resize(2);
	mDeleteWindowList.resize(2);

	mEditor.RegisterWindows();
}

void EditorSystem::Update() 
{
	mWindowProperties.UpdateWindowLayoutProperties();

	if (mEditorEnabled)
	{
		RenderMainMenuBar();
		RenderEditorWindows();
	}
}

void EditorSystem::ShowDebug()  {}
void EditorSystem::Shutdown() {}
void EditorSystem::EnableEditor(bool enable) { mEditorEnabled = enable; }
bool EditorSystem::IsEnabled() { return mEditorEnabled; }

void EditorSystem::AddGUIWindow(void(*fp)(), const std::string& name, const std::string& cathegory, unsigned editorside)
{
	GUIWindow* parent = &mGUIWindows;
	std::string cath = cathegory;

	while (cath != "")
	{
		auto next = cath.find_first_of('/');
		std::string curr_cath = cath.substr(0, next);
		cath = cath.substr(next + 1, std::string::npos);

		parent = parent->mChildren[curr_cath];

		if (!parent)
			parent = new GUIWindow;

		parent->mName = curr_cath;
	}

	auto& child = parent->mChildren[name];
	child = new GUIWindow;

	child->mName = name;
	child->mFunct = fp;
	child->mPath = cathegory + "/" + name;
	child->mEditorSide = editorside;
}

void EditorSystem::RenderEditorWindows()
{
	static bool open = true;

	Vec2 bl = mWindowProperties.mGameWindowBL;
	Vec2 tr = mWindowProperties.mGameWindowTR;
	ImVec2 size1 = (Vec2)mWindowProperties.mWindowResolution - tr;
	ImVec2 size0 = (Vec2)mWindowProperties.mWindowResolution - bl;
	size0.x -= size1.x;

	RemoveInactiveWindows();

	if (mWindowProperties.mHasChanged)
		ImGui::SetNextWindowPos(bl);
	ImGui::SetNextWindowSize(size0, ImGuiSetCond_Always);
	ImGui::SetNextWindowPosConstraints(Vec2{0, -1});
	ImGui::SetNextWindowSizeConstraints(size0);

	ImGui::Begin("Window0", &open, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_ShowBorders);
		
	unsigned y = (unsigned)ImGui::GetWindowPos().y;
	y = y - mWindowProperties.mMenuBarSize;
	float relativesize = (float)y / (float)mWindowProperties.mWindowResolution.y;
	if (ImGui::IsWindowFocused())
		mWindowProperties.mGameWindowRelativeSize = { relativesize , relativesize };

	if (mActiveWindowList.at(0).size() > 0)
	{
		ImGui::Columns((int)mActiveWindowList.at(0).size());

		for (auto& w : mActiveWindowList.at(0))
		{
			w->RenderWindowHorizontal();
			ImGui::NextColumn();
		}

		ImGui::Columns(1);
	}
	
	ImGui::End();

	if (mWindowProperties.mHasChanged)
		ImGui::SetNextWindowPos(tr);
	ImGui::SetNextWindowSize(size1, ImGuiSetCond_Always);
	ImGui::SetNextWindowSizeConstraints(size1);
	ImGui::SetNextWindowPosConstraints(Vec2{ -1, tr.y });

	ImGui::Begin("Window1", &open, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_ShowBorders);
	
	unsigned x = (unsigned)ImGui::GetWindowPos().x;
	relativesize = (float)x / (float)mWindowProperties.mWindowResolution.x;
	if (ImGui::IsWindowFocused())
		mWindowProperties.mGameWindowRelativeSize = { relativesize , relativesize };

	RenderSideWindows(1);

	ImGui::End();

	ImGui::ShowTestWindow();
}

void EditorSystem::RenderSideWindows(unsigned side)
{
	for (auto& w : mActiveWindowList.at(side))
		w->RenderWindowVertical();
}

void EditorSystem::RemoveInactiveWindows()
{
	for (unsigned i = 0; i < mActiveWindowList.size(); ++i)
	{
		Utilities::DeleteMatches<EditorSystem::GUIWindow*>(mActiveWindowList[i], mDeleteWindowList[i]);
		mDeleteWindowList[i].clear();
	}
}

void EditorSystem::RenderMainMenuBar()
{
	if (ImGui::BeginMainMenuBar())
	{
		if (ImGui::BeginMenu("| Windows |"))
		{
			mGUIWindows.ShowActive();
			ImGui::EndMenu();
		}

		ImGui::EndMainMenuBar();
	}
}

void EditorSystem::SetGameViewPort()
{
	if (!mEditorEnabled)
	{
		gl::Viewport(0, 0, mWindowProperties.mWindowResolution.x, mWindowProperties.mWindowResolution.y);
		return;
	}

	auto& w = mWindowProperties.mGameWindowSize;
	auto& res = mWindowProperties.mWindowResolution;

	int y = res.y - unsigned((mWindowProperties.mGameWindowSize.y) + mWindowProperties.mMenuBarSize);
	gl::Viewport(0, y, w.x, w.y);
}

void EditorSystem::GUIWindow::ShowActive()
{
	std::string name = mName + "##" + std::to_string((int)this);

	if (mName == "")
	{
		for (auto& c : mChildren)
			c.second->ShowActive();
		return;
	}

	if (!mChildren.empty())
	{
		if (ImGui::BeginMenu(name.c_str()))
		{
			for (auto& c : mChildren)
				c.second->ShowActive();
			ImGui::EndMenu();
		}

		return;
	}

	bool before = mActive;
	ImGui::Checkbox(name.c_str(), &mActive);

	if (!before && mActive)
		AddToActiveList();
	if (before && !mActive)
		RemoveFromActiveList();
}

void EditorSystem::GUIWindow::RenderWindowHorizontal()
{
	std::string name = mName + "##" + std::to_string((int)(this));
	if (mActive)
	{
		if (ImGui::CollapsingHeader(name.c_str(), &mActive, ImGuiTreeNodeFlags_DefaultOpen ))
		{
			auto wd = ImGui::GetContentRegionAvailWidth();
			auto hd = ImGui::GetWindowSize().y - (unsigned)ImGui::GetItemRectSize().y - (unsigned)ImGui::GetStyle().ScrollbarSize;

			ImGui::BeginChild(std::to_string((int)this).c_str(), ImVec2(wd, hd), false, ImGuiWindowFlags_HorizontalScrollbar);

			CallFunction();

			ImGui::EndChild();
		}
		if (!mActive)
			RemoveFromActiveList();
	}
}

void EditorSystem::GUIWindow::RenderWindowVertical()
{
	std::string name = mName + "##" + std::to_string((int)(this));
	if (mActive)
	{
		if (ImGui::CollapsingHeader(name.c_str(), &mActive, ImGuiTreeNodeFlags_DefaultOpen))
			CallFunction();
		if (!mActive)
			RemoveFromActiveList();
	}
}

void EditorSystem::GUIWindow::AddToActiveList()
{
	mpActiveWindowList->at(mEditorSide).push_back(this);
}

void EditorSystem::GUIWindow::RemoveFromActiveList()
{
	mpDeleteWindowList->at(mEditorSide).push_back(this);
}

void EditorSystem::WindowLayoutProperties::UpdateWindowLayoutProperties()
{
	mMenuBarSize = (unsigned)ImGui::GetItemRectSize().y;
	mWindowResolution = FoxTracerEngine::Display_.GetWindowSize();
	mGameWindowSize = Vec2(mWindowResolution) * mGameWindowRelativeSize;

	mGameWindowTL = {0, mMenuBarSize };
	mGameWindowTR = { mGameWindowSize.x, mMenuBarSize };
	mGameWindowBL = { 0, mGameWindowSize.y + mMenuBarSize };
	mGameWindowBR = { mGameWindowSize.x, mGameWindowBL.y };

	static Vec2 lastgamewn;
	static IVec2 lastwinres;
	static unsigned lastmenubarsize;

	mHasChanged = false;
	if (lastgamewn != mGameWindowRelativeSize || lastwinres != mWindowResolution || lastmenubarsize != mMenuBarSize)
		mHasChanged = true;

	lastgamewn = mGameWindowRelativeSize;
	lastwinres = mWindowResolution;
	lastmenubarsize = mMenuBarSize;
}

IVec2 EditorSystem::WindowLayoutProperties::GetGameWindowSize()
{
	return mGameWindowSize;
}

