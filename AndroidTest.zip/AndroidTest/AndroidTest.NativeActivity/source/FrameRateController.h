#pragma once

#include "System.h"

class FrameRateController : public System
{
	RTTI_DECLARATION(FrameRateController)
public:
	void Initialize() override;
	void Update() override;

	float GetFrameTimeMilliseconds();
	float GetFrameTime();
	float GetFrameRate();

private:
	unsigned mLastTicks{0};
	float mFrameRate{0};
	float mFrameTime{0};
};