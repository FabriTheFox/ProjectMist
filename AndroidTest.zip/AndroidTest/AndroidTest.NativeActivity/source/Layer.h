#pragma once

#include <string>
#include <vector>
#include <unordered_map>
#include "System.h"
#include "DataTypes.h"
#include "Renderer.h"
#include "Camera.h"
#include "Texture.h"
#include "LightingSystem.h"
#include "RT_Layer.h"

class Renderable;
class DebugRender;

class Layer : public std::enable_shared_from_this<Layer>
{
	friend class RayTracerSystem;
	friend class GraphicSystem;

public:
	
	Layer(const std::string& name);
	void Shutdown();

	void Render();

	const std::string& GetName();

	template <typename T>
	void CreateRenderer(const std::string& name, const std::string& shader)
	{
		mRenderers[name] = std::make_shared<T>(shader, mName);
	}

	Renderer& GetRenderer(const std::string name);
	LightingSystem& GetLightingSystem();

	void SetCamera(SHD_PTR<Camera> cam);
	SHD_PTR<Camera> GetCamera();

	// Ray tracing ==========================================
	void FillRTData(RT_Layer& layer);
	// ======================================================

	// Debug Render =========================================
	void RenderDebugPoint(const Vec3& pos, const Vec4& color, float size);
	void RenderDebugLine(const Vec3& start, const Vec3& end, const Vec4& color = {1, 1, 1, 1}, const float& width = 1);
	void RenderDebugScreenLine(const Vec2& start, const Vec2& end, const Vec4& color = { 1, 1, 1, 1 }, const float& width = 1);
	void RenderDebugWireCube(const Transform& tr = {}, const Vec4& color = { 1, 1, 1, 1 }, const float& width = 1);
	void RenderDebugScreenQuad(Texture& texture);
	void RenderDebugScreenTRQuad(Texture& texture, const Transform& tr);
	// ======================================================

private:
	void ShowGUI();
	void RenderDebugObjects();

	std::unordered_map<std::string, SHD_PTR<Renderer>> mRenderers;
	std::vector<SHD_PTR<DebugRender>> mDebugRenders;
	SHD_PTR<Camera> mCamera{nullptr};
	LightingSystem mLightingSystem;

	std::string mName;
};