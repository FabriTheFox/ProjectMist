#pragma once

#include "Utilities.h"
#include "RTTI.h"
#include <unordered_map>

template <typename T>
class SHDPtrVec 
{
public:
	void AddPtr(SHD_PTR<T> ptr)
	{
		AlivePtrs_.push_back(ptr);
	}
	void RemovePtr(SHD_PTR<T> ptr)
	{
		auto itr = std::find(AlivePtrs_.begin(), AlivePtrs_.end(), ptr);
		if (itr == AlivePtrs_.end())
			return;
		*itr = AlivePtrs_.back();
		AlivePtrs_.pop_back();
	}
	std::vector<SHD_PTR<T>> AlivePtrs_;
};

template <typename T>
class WKPtrVec
{
public:
	void AddPtr(SHD_PTR<T> ptr)
	{
		AlivePtrs_.push_back(ptr);
	}
	void Update()
	{
		for (unsigned i = 0; i < AlivePtrs_.size(); ++i)
		{
			auto& ptr = AlivePtrs_[i];
			if (ptr.expired())
			{
				ptr = AlivePtrs_.back();
				AlivePtrs_.pop_back();
			}
		}
	}
	std::vector<WK_PTR<T>> AlivePtrs_;
};

class SystemConfig
{
public:
	~SystemConfig();
	SystemConfig() = default;
	SystemConfig(const SystemConfig& rhs);
	SystemConfig& operator= (const SystemConfig& rhs);

	template <typename T>
	void Create(const std::string& name, const T& val)
	{
		char* ptr = new char[sizeof(T)];
		*((T*)(ptr)) = val;
		mVariables[name] = Data(typeid(T).hash_code(), sizeof(T), ptr);
	}

	template <typename T>
	void SetValue(const std::string& name, const T& val)
	{
		*((T*)mVariables.at(name).mData) = val;
	}

	template <typename T>
	T& GetValue(const std::string& name)
	{
		return *((T*)mVariables.at(name).mData);
	}

	bool HasChanged();
	void Update();

	struct Data
	{
		Data(size_t t = 0, size_t s = 0, void* d = nullptr) : mType(t), mData(d), mDataSize(s) {}
		size_t mDataSize;
		size_t mType;
		void* mData;
	};

	std::unordered_map<std::string, Data> mVariables;
	std::unordered_map<std::string, Data> mLastVariables;
	bool mHasChanged{ false };

private:
	void Clear();
};

class System : public Base
{
public:
	void UpdateSystem()
	{
		Update();
		mConfiguration.Update();
	}

	virtual void Initialize() {};
	virtual void Update() {};
	virtual void Shutdown() {};
	virtual void ShowDebug() {};

	const bool& IsActive() { return mActive; }
	void SetActive(bool active) { mActive = active; }

	SystemConfig& GetConfiguration() { return mConfiguration; };

protected:
	bool mActive{ true };
	SystemConfig mConfiguration;
};