#pragma once

#include "DataTypes.h"
#include "Asset.h"
#include <string>

#define IMPORTER_DECLARATION(classname)																						\
	static WK_PTR<classname> GetInstance() { static SHD_PTR<classname> inst = std::make_shared<classname>(); return inst; }

class Importer
{
public:
	virtual void Import(const std::string& name, const std::string& path) { UNUSED_PARAM(path); UNUSED_PARAM(name);}
private:
};