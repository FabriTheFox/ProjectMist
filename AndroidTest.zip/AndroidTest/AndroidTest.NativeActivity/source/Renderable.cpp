#include "Renderable.h"
#include "FoxTracerEngine.h"
#include "RTTI_imp.h"

#include "FTESystems.h"

SERIALIZABLE_IMPLEMENTATION(Renderable)

REGISTER_PROPERTIES(Renderable)
{
	PROPERTY(Renderable, Vec4, mModulationColor);
	PROPERTY(Renderable, std::string, mRenderer);
	PROPERTY(Renderable, std::string, mLayer);
	PROPERTY(Renderable, std::string, mModel);
	PROPERTY(Renderable, bool, mVisible);

	PROPERTY(Renderable, bool, mCastsShadow);
}

void Renderable::AddToSystem()
{
	FoxTracerEngine::GetSystem<GraphicSystem>().GetLayer(mLayer).GetRenderer(mRenderer).AddRenderer(shared_from_this());
}

void Renderable::RemoveFromSystem()
{
	FoxTracerEngine::GetSystem<GraphicSystem>().GetLayer(mLayer).GetRenderer(mRenderer).RemoveRenderable(shared_from_this());
}

const std::string& Renderable::GetLayer(){ return mLayer; }
const std::string& Renderable::GetRenderer() { return mRenderer; }
void Renderable::SetCastShadow(bool cast) { mCastsShadow = cast; }
bool Renderable::CastsShadow() { return mCastsShadow; }
Model& Renderable::GetModel() { return *mpModel.lock(); }
bool Renderable::IsVisible() { return mVisible; }
void Renderable::SetVisible(bool visible) { mVisible = visible; }
const Vec4& Renderable::GetModulationColor() { return mModulationColor; }
void Renderable::SetModulationColor(const Vec4& color) { mModulationColor = color; }
void Renderable::SetModel(const std::string& name){ mpModel = FoxTracerEngine::GetSystem<AssetSystem>().GetAsset<Model>(name); mModel = name; }

void Renderable::SetRenderer(const std::string& name)
{
	if (mRenderer == name)
		return;
	RemoveFromSystem();
	mRenderer = name;
	AddToSystem();
}

std::vector<FTEIntersection::Triangle>& Renderable::UpdateTransformedVertices()
{
	auto modelmat = GetOwner().GetTransform().GetModelMatrix();
	auto trinv = Mat3(glm::transpose(glm::inverse(modelmat)));
	mTransformedVertices.clear();

	for (auto& mesh : mpModel.lock()->mMeshes)
	{
		for (unsigned i = 0; i < mesh.mIndices.size(); i += 3)
		{
			mTransformedVertices.emplace_back(
				Vec3(modelmat * Vec4(mesh.mVertices[i + 0].mPosition, 1)),
				Vec3(modelmat * Vec4(mesh.mVertices[i + 1].mPosition, 1)),
				Vec3(modelmat * Vec4(mesh.mVertices[i + 2].mPosition, 1)));
				
			auto& t = mTransformedVertices.back();
			t.mNormals[0] = glm::normalize(trinv * mesh.mVertices[i + 0].mNormal);
			t.mNormals[1] = glm::normalize(trinv * mesh.mVertices[i + 1].mNormal);
			t.mNormals[2] = glm::normalize(trinv * mesh.mVertices[i + 2].mNormal);

			mTransformedVertices.back().ComputeNormal();
		}
	}

	return mTransformedVertices;
}

void Renderable::Load(SerDataPack& data)
{
	mLayer = "World";
	mRenderer = "BasicRenderer";
	RemoveFromSystem();
	mLayer = data.GetData("mLayer").GetData<std::string>();
	mRenderer = data.GetData("mRenderer").GetData<std::string>();
	SetModel(data.GetData("mModel").GetData<std::string>());
	AddToSystem();
}

void Renderable::FillRTData(RT_Renderable& renderable)
{
	UpdateTransformedVertices();
	renderable.mWorldTriangles = mTransformedVertices;

	auto& tr = GetTransform();
	if (mModel == "Sphere")
	{
		if (tr.mScale.x == tr.mScale.y && tr.mScale.x == tr.mScale.z)
			renderable.mTraceFunction = &RT_Renderable::TraceRay_Sphere;
		else
			renderable.mTraceFunction = &RT_Renderable::TraceRay_Ellipsoid;
	}
	else if (mModel == "Cube")
	{
		if (tr.mRotation == Vec3{0})
			renderable.mTraceFunction = &RT_Renderable::TraceRay_AACube;
		else 
			renderable.mTraceFunction = &RT_Renderable::TraceRay_OCube;
	}
	else
	{
		renderable.mTraceFunction = &RT_Renderable::TraceRay_Mesh;
		renderable.mKDTree = new KDTree;
		renderable.mKDTree->BuildKDTree(renderable.mWorldTriangles, 100);
	}

	renderable.mModulationColor = mModulationColor;
	renderable.mTransform = GetTransform();
	renderable.mWorldToModel = glm::inverse(tr.GetModelMatrix());
	renderable.mCastsShadow = mCastsShadow;
	renderable.mVisible = mVisible;

}
