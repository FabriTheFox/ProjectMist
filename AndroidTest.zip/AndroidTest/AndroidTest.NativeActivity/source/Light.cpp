#include "Light.h"
#include "FoxTracerEngine.h"
#include "Debug.h"
#include "RTTI_imp.h"
#include "Renderable.h"

#include "FTESystems.h"

COMPONENT_IMPLEMENTATION(Light);

SERIALIZABLE_IMPLEMENTATION(Light::Attenuation)
REGISTER_PROPERTIES(Light::Attenuation)
{
	PROPERTY(Light::Attenuation, float, mInnerRadius);
	PROPERTY(Light::Attenuation, float, mOuterRadius);
}

void Light::FillRTData(RT_Light& light)
{
	light.mDiffuse = mDiffuse;
	light.mAmbient = mAmbient;
	light.mSpecular = mSpecular;

	light.mAttenuation.mInnerRadius = mAttenuation.mInnerRadius;
	light.mAttenuation.mOuterRadius = mAttenuation.mOuterRadius;

	light.mPosition = GetTransform().mPosition;

	auto type = GetRTTI().mTypehash;
	if (type == OmniLight::RTTI_.mTypehash)
		light.mRenderFN = &RT_Light::ComputeColor_Omni;
}

Light::Light(const std::string& layer) : mLayer(FoxTracerEngine::GetSystem<GraphicSystem>().GetLayer(layer)) {}

void Light::ShowGUI()
{
	FTEDebug::EditColor3(mDiffuse, "Diffuse");
	FTEDebug::EditColor3(mSpecular, "Specular");
	FTEDebug::EditColor3(mAmbient, "Ambient");

	std::string name = "Inner radius##" + std::to_string((int)&mAttenuation.mInnerRadius);
	ImGui::SliderFloat(name.c_str(), &mAttenuation.mInnerRadius, 0, 500);

	name = "Outer radius##" + std::to_string((int)&mAttenuation.mOuterRadius);
	ImGui::SliderFloat(name.c_str(), &mAttenuation.mOuterRadius, 0, 500);
}

void Light::FillShaderData(std::vector<float>& vec)
{
	auto pos = GetOwner().GetTransform().TransformPosition(mLayer.GetCamera()->GetCameraMatrix());
	vec.push_back(pos.x);
	vec.push_back(pos.y);
	vec.push_back(pos.z);
	
	vec.push_back(mDiffuse.x);
	vec.push_back(mDiffuse.y);
	vec.push_back(mDiffuse.z);
	
	vec.push_back(mSpecular.x);
	vec.push_back(mSpecular.y);
	vec.push_back(mSpecular.z);
	
	vec.push_back(mAmbient.x);
	vec.push_back(mAmbient.y);
	vec.push_back(mAmbient.z);
	
	vec.push_back(mAttenuation.mInnerRadius * mAttenuation.mInnerRadius);
	vec.push_back(mAttenuation.mOuterRadius * mAttenuation.mOuterRadius);

	GetShaderData(vec);
}

void Light::AddToSystem()
{
	mLayer.GetLightingSystem().mLights[GetRTTI().mTypehash].push_back(shared_from_this());
}


SERIALIZABLE_IMPLEMENTATION(OmniLight)

REGISTER_PROPERTIES(OmniLight)
{
	PROPERTY(OmniLight, Vec3, mDiffuse);
	PROPERTY(OmniLight, Vec3, mSpecular);
	PROPERTY(OmniLight, Vec3, mAmbient);
	PROPERTY(OmniLight, Attenuation, mAttenuation);
}

OmniLight::OmniLight(const std::string& layer) : Light(layer) {}

void OmniLight::GetShaderData(std::vector<float>& vec)
{
	UNUSED_PARAM(vec);
}