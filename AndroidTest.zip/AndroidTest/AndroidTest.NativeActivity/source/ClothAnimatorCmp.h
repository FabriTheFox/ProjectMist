#pragma once

#include "Component.h"
#include <vector>

#include "Model.h"

class ClothAnimatorCmp :
	public Component,
	public std::enable_shared_from_this<ClothAnimatorCmp>
{
	friend class ClothRenderer;
	COMPONENT_SERIALIZABLE_DECLARATION(ClothAnimatorCmp)

public:
	ClothAnimatorCmp() = default;

	// Init simulation
	void Initialize();
	// Update simulation
	void Update();

	// Applies wind force on the desired direction and speed
	void ApplyWindForce(const Vec3& dir, float strength);
	// Makes the particles check collision against a sphere
	void CollideWithSphereAt(const Vec3& center, float radius);
	// Makes the particle check collision against a centered box
	void CollideWithBoxAt(const Vec3& size);

	// Reset the simulation
	void Reset();
	// Change the size or resolution of the particle mesh
	void Resize(const Vec2& length, const IVec2& pointres);

	// Disables the interparticle links that cross the plane defined by abc
	void CutConstraintsThrough(const Vec3& a, const Vec3& b, const Vec3& c);
	// Releases the top constraints
	void ReleaseBars(bool a, bool b, bool c, bool d);

//private:

	// Generates the initial particle data
	void Resize();
	// Fills the particles vectors data
	void GenerateInitialPositions();
	// Generates the initial interparticle links
	void GenerateConstraints();
	// Helper
	void PushConstraint(int a, int b, float dis);

	// Performs verlet integration based on the acceleration and last pos of each particle
	void VerletIntegration();
	// Sets each particles' acc. to gravity
	void ApplyGravity();
	// Solves the system based on the collisions and particle links constraints
	void SatisfyConstraints();

	// Applies a force to a particle, takes into account its mass
	void ApplyForceTo(int indx, const Vec3& f);

	// Upload the wireframe mesh to the gpu
	void UpdateWireMeshes();
	// Upload the triangle mesh to the gpu
	void UpdateTriangleMesh();

	class Constraint
	{
	public:
		int mA;					// Particle A
		int mB;					// Particle B
		float mLength;			// Resting length
		bool mActive{ true };	// To perform cuts
	private:
	};

	Vec2 mLength = {15, 15};			// World size of the mesh
	IVec2 mPointsSize{35, 35};			// Resolution of the mesh

	Vec3 mSpherePosition{0, 0, 5.f};	// Collision objects data
	float mSphereRadius{3.f};
	Vec3 mBoxLimits{15, 15, 15};

	unsigned mNumPoints;				// Total number of particles

	float mDeltaTime;					
	float mDeltaTimeSQ;

	unsigned mRestrictionIterations{10};	// Number of iterations for the mesh relaxation
	float mDrag{0.001f};					// Drag effect to compute on the verlet integration
	float mRestitution{ 1.f };				// Overall restitution force of the mesh

	std::vector<Vec3> mPos;					// World positions
	std::vector<Vec3> mLastPos;				// World last positions
	std::vector<Vec3> mAcceleration;		// Acceleration (resets every frame)
	std::vector<float> mInvMass;			// 1 / particle's masss
	std::vector<Constraint> mConstraints;	// Array of particle links

	Vec3 mGravity{ 0, -2, 0 };	
	float mGravityStrength{1};
	bool mBars[4];

	Model mConstraintMesh;					// For rendering
	Model mPointsMesh;
	Model mTriangleMesh;
};