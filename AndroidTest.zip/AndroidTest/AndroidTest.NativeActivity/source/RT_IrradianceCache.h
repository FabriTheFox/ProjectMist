#pragma once

#include "DataTypes.h"
#include "RT_Renderer.h"
#include "PointOctree.h"
#include <vector>

class RenderJob;

class RT_IrradianceCache
{
public:
	enum IrradianceCacheStatus
	{
		IC_WAITING,
		IC_SEARCHING_CACHE_POINTS,
		IC_COMPUTING_CACHE,
		IC_BUILDING_OCTREE,
		IC_FINISHED
	};
	~RT_IrradianceCache();
	RT_IrradianceCache();

	void Launch(RenderJob* renderjob);
	Vec3 ComputeIrradianceAt(const Vec3& pos, const Vec3& n);

	IrradianceCacheStatus mStatus{ IC_WAITING };

//private:
	void Initialize();
	void SearchCachePoints();
	void ComputeCache();
	void BuildOctree();

	bool EvaluateSample(unsigned x, unsigned y);
	void TestCache(unsigned x, unsigned y, float radius);

	struct IrradianceValue
	{
		Vec3 mPos;
		Vec3 mNormal;
		IVec2 mScreen;
		Vec4 mColor;
	};

	RenderJob* mRenderJob;
	IVec2 mResolution;

	std::vector<IrradianceValue> mHotValues;
	std::vector<FTEIntersection::IntersectionResult> mScreen;

	PointOctree<IrradianceValue>* mIrradianceTree{nullptr};

	float mRadius;
	float mSQRadius;
};