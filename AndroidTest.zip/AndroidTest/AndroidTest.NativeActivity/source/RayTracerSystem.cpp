#include "RayTracerSystem.h"
#include "Camera.h"
#include "Layer.h"
#include "Intersection.h"
#include "FoxTracerEngine.h"
#include "OpenGLHeaders.h"
#include <glm/gtc/type_ptr.hpp>
#include "ImGUIHeaders.h"
#include "RTTI_imp.h"

#include "FTESystems.h"

RTTI_IMPLEMENTATION(RayTracerSystem);

void RayTracerSystem::Initialize()
{
	mConfiguration.Create<IVec2>("resolution", { 1920, 1080 });
	mConfiguration.Create<Vec4>("background_color", {0, 0, 0, 1});
	mConfiguration.Create<unsigned>("cluster_size", 150);
	mConfiguration.Create<unsigned>("num_threads", 4);
	mConfiguration.Create<unsigned>("samples_per_texel", 4);
	mConfiguration.Create<unsigned>("max_reflection_levels", 4);

	// DOF
	mConfiguration.Create<bool>("depth_of_field", false);
	mConfiguration.Create<unsigned>("dof_samples", 1);
	mConfiguration.Create<float>("dof_aperture", 0.5f);

	// GI
	mConfiguration.Create<bool>("enable_gi", false);
	mConfiguration.Create<unsigned>("gi_method", 0);				// 0 ->Montecarlo, 1->Photon mapping

	// Montecarlo
	mConfiguration.Create<unsigned>("montecarlo_samples", 10);

	// Photon mapping
	mConfiguration.Create<unsigned>("photon_gather_method", 0);		// 0 ->direct, 1->scatter
	mConfiguration.Create<unsigned>("gather_samples", 50);
	mConfiguration.Create<unsigned>("photons_per_light", 100000);
	mConfiguration.Create<unsigned>("photon_bounces", 1);
	mConfiguration.Create<float>("photon_radius", 2.f);
	mConfiguration.Create<unsigned>("photon_intensity", 100);

	// Irradiance cache
	mConfiguration.Create<bool>("enable_irr_caching", false);
	mConfiguration.Create<float>("irradiance_radius", 10.f);

	//unsigned char color[4] = { 0, 0, 0, 128 };
	//mTexture.Load(color, 1, 1);
}

#include "PointKDTree.h"
typedef PointKDTree<RT_PhotonMap::PhotonData> photonmap;
void RayTracerSystem::Update()
{
	UpdateRenderJobs();
	RenderImage();

	//if (HasRenderJobs())
	//{
	//	auto& rn = mRenderJobs.front();
	//	static int level = 0;
	//	ImGui::SliderInt("Level", &level, 0, ((photonmap*)(rn->GetRTLayer().mPhotonMap.mPhotonMap))->GetLevel());
	//	ImGui::Text("Levels: %i", ((photonmap*)(rn->GetRTLayer().mPhotonMap.mPhotonMap))->GetLevel());
	//	((photonmap*)(rn->GetRTLayer().mPhotonMap.mPhotonMap))->RenderTree(level, true, "World");
	//}
}

bool RayTracerSystem::IsRendering()
{
	return mIsRendering;
}

bool RayTracerSystem::HasRenderJobs()
{
	return !mRenderJobs.empty();
}

void RayTracerSystem::RenderImage()
{
	if (mShowRender)
	{
		if (HasRenderJobs())
		{
			//GetCurrentRenderJob().GetLayer().RenderDebugScreenQuad(mTexture);
			GetCurrentRenderJob().RenderClusterHighlights();
		}	
	}
}

void RayTracerSystem::PauseRender(bool pause)
{
	mIsPaused = pause;
	if (HasRenderJobs())
		GetCurrentRenderJob().Pause(pause);
}

void RayTracerSystem::CancelRender()
{
	if (HasRenderJobs())
		GetCurrentRenderJob().Interrupt();
}

void RayTracerSystem::CleanRenderJobs()
{
	mRenderJobs.clear();
	mCurrentRenderJob = 0;
}

RenderJob& RayTracerSystem::GetCurrentRenderJob()
{
	if (mCurrentRenderJob >= mRenderJobs.size())
		return *mRenderJobs.back();
	return *mRenderJobs[mCurrentRenderJob];
}

void RayTracerSystem::UpdateRenderJobs()
{
	if (!mIsRendering)
		return;

	if (mCurrentRenderJob >= mRenderJobs.size())
	{
		mIsRendering = false;
		return;
	}

	if (GetCurrentRenderJob().mStatus == RenderJob::FINISHED)
	{
		//auto d = Utilities::GetDate();
		//std::string path = "renders/" + d;
		//mTexture.SaveToFile(path);
		++mCurrentRenderJob;
	}
	//GetCurrentRenderJob().Update(mTexture);
}

void RayTracerSystem::RenderLayer(const std::string& layer)
{
	CleanRenderJobs();
	auto& lay = FoxTracerEngine::GetSystem<GraphicSystem>().GetLayer(layer);

	mIsRendering = true;
	mIsPaused = false;
	mRenderJobs.push_back(std::make_shared<RenderJob>(mConfiguration, lay));
	mRenderJobs.back()->SetupAndRender();
}

void RayTracerSystem::ShowDebug()
{
	static bool open = false;
	if (ImGui::BeginMenu("| Ray Tracer |"))
	{
		open = true;
		ImGui::EndMenu();
	}
	if (open)
		ShowGUIWindow(open);
}

void RayTracerSystem::ShowPhotonMappingProgress()
{
	if (mConfiguration.GetValue<bool>("enable_gi"))
	{
		if (mConfiguration.GetValue<unsigned>("gi_method") == 1)
		{
			auto& map = GetCurrentRenderJob().GetPhotonMap();

			ImGui::Text("========= Photon mapping =========");
			ImGui::Spacing();

			if (map.mStatus == RT_PhotonMap::PM_WAITING)
			{
				ImGui::Text("Phase 1: Photon tracing");
				ImGui::Spacing();
				ImGui::Text("Phase 2: KD Tree building");
			}

			if (map.mStatus == RT_PhotonMap::PM_TRACING_PHOTONS)
			{
				ImGui::TextColored({0, 1, 0, 1}, "Phase 1: Photon tracing");
				ImGui::Spacing();
				ImGui::Text("Phase 2: KD Tree building");
			}

			if (map.mStatus == RT_PhotonMap::PM_BUILDING_KDTREE)
			{
				ImGui::TextDisabled("Phase 1: Photon tracing");
				ImGui::Spacing();
				ImGui::TextColored({ 0, 1, 0, 1 }, "Phase 2: KD Tree building");
			}

			if (map.mStatus == RT_PhotonMap::PM_FINISHED)
			{
				ImGui::TextDisabled("Phase 1: Photon tracing");
				ImGui::Spacing();
				ImGui::TextDisabled("Phase 2: KD Tree building");
			}

			ImGui::Spacing();

			auto& tree = *((photonmap*)(map.mPhotonMap));
			ImGui::Text("-- Level:             %i", tree.GetLevel());
			ImGui::Text("-- Stored photons     %i", tree.GetStats().mTotalElements);
			ImGui::Text("-- Duplicated photons %i", tree.GetStats().mDuplicatedElements);
			ImGui::Text("-- Nodes              %i", tree.GetStats().mNodes);
			ImGui::Text("-- Avg. Elems/Node:   %.1f", tree.GetStats().mAvgElementsPerNode);
			ImGui::Text("-- Plane splits       %i", tree.GetStats().mPlaneSplits);

			ImGui::Spacing();
			ImGui::Separator();
		}
	}
}

void RayTracerSystem::ShowIrradianceCachingProgress()
{
	if (mConfiguration.GetValue<bool>("enable_gi"))
	{
		if (mConfiguration.GetValue<bool>("enable_irr_caching"))
		{
			auto& irr = GetCurrentRenderJob().GetIrradianceCache();

			ImGui::Text("======= Irradiance caching =======");
			ImGui::Spacing();

			if (irr.mStatus == RT_IrradianceCache::IC_WAITING)
			{
				ImGui::Text("Phase 1: Search cache spots");
				ImGui::Text("Phase 2: Compute irradiance at spots");
				ImGui::Text("Phase 3: Build octree");
			}

			if (irr.mStatus == RT_IrradianceCache::IC_SEARCHING_CACHE_POINTS)
			{
				ImGui::TextColored({ 0, 1, 0, 1 }, "Phase 1: Search cache spots");
				ImGui::Text("Phase 2: Compute irradiance at spots");
				ImGui::Text("Phase 3: Build octree");
			}

			if (irr.mStatus == RT_IrradianceCache::IC_COMPUTING_CACHE)
			{
				ImGui::TextDisabled("Phase 1: Search cache spots");
				ImGui::TextColored({ 0, 1, 0, 1 }, "Phase 2: Compute irradiance at spots");
				ImGui::Text("Phase 3: Build octree");
			}

			if (irr.mStatus == RT_IrradianceCache::IC_BUILDING_OCTREE)
			{
				ImGui::TextDisabled("Phase 1: Search cache spots");
				ImGui::TextDisabled("Phase 2: Compute irradiance at spots");
				ImGui::TextColored({ 0, 1, 0, 1 }, "Phase 3: Build octree");
			}

			if (irr.mStatus == RT_IrradianceCache::IC_FINISHED)
			{
				ImGui::TextDisabled("Phase 1: Search cache spots");
				ImGui::TextDisabled("Phase 2: Compute irradiance at spots");
				ImGui::TextDisabled("Phase 3: Build octree");
			}

			auto& tree = irr.mIrradianceTree;
			auto stats = tree->GetStats();

			ImGui::Spacing();
			ImGui::Text("-- Level:             %i", stats.mLevel);
			ImGui::Text("-- Stored points      %i", stats.mTotalElements);
			ImGui::Text("-- Nodes              %i", stats.mNodes);
			ImGui::Text("-- Avg. Elems/Node:   %.1f", stats.AvgElementsPerNode);

			ImGui::Spacing();
			ImGui::Separator();
		}
	}
}

void RayTracerSystem::ShowRenderProgress()
{
	ImGui::Text("========= Scene Rendering ========");
	ImGui::Spacing();

	if (GetCurrentRenderJob().mStatus == RenderJob::WAITING)
		ImGui::Text("Render scene");
	if (GetCurrentRenderJob().mStatus == RenderJob::RUNNING)
	{
		if (mIsPaused)
			ImGui::TextColored({ 0, 1, 0, 1 }, "Paused");
		else
			ImGui::TextColored({ 0, 1, 0, 1 }, "Render scene");
	}
		
	else if (GetCurrentRenderJob().mStatus == RenderJob::FINISHED)
		ImGui::TextDisabled("Render scene");

	ImGui::Spacing();
	ImGui::Text(GetCurrentRenderJob().mTimer.GetTime_DaysHoursMinutesSecondsMillisecs().c_str());

	ImGui::Separator();
}

void RayTracerSystem::ShowGUIWindow(bool& open)
{
	ImGui::SetNextWindowPos(ImVec2(200, 200), ImGuiSetCond_Once);
	ImGui::Begin("Rendering settings", &open, ImGuiWindowFlags_AlwaysAutoResize);

	ImGui::Checkbox("Show render", &mShowRender);

	if (ImGui::CollapsingHeader("General"))
	{
		auto& res = mConfiguration.GetValue<IVec2>("resolution");
		ImGui::DragInt2("Resolution", &res.x, 1, 1, 5000);

		ImGui::Spacing();
		ImGui::Text("Multithreading");
		auto& num_threads = mConfiguration.GetValue<unsigned>("num_threads");
		ImGui::SliderInt("Threads", (int*)&num_threads, 1, 10);

		auto& clus_size = mConfiguration.GetValue<unsigned>("cluster_size");
		ImGui::SliderInt("Cluster size", (int*)&clus_size, 10, 1000);

		ImGui::Spacing();
		ImGui::Text("Antialising");
		auto& samples = mConfiguration.GetValue<unsigned>("samples_per_texel");
		ImGui::SliderInt("Samples per texel", (int*)&samples, 1, 36);

		ImGui::Spacing();
		ImGui::Text("Reflection");
		auto& ref = mConfiguration.GetValue<unsigned>("max_reflection_levels");
		ImGui::SliderInt("Reflection levels", (int*)&ref, 1, 25);
	}

	if (ImGui::CollapsingHeader("Global illumination"))
	{
		auto& enable_gi = mConfiguration.GetValue<bool>("enable_gi");
		ImGui::Checkbox("Enable Global illumination", &enable_gi);
		if (enable_gi)
		{
			ImGui::Spacing();

			auto& gi_method = mConfiguration.GetValue<unsigned>("gi_method");
			ImGui::Text("Method: ");
			ImGui::RadioButton("Monte Carlo", (int*)&gi_method, 0);
			ImGui::SameLine();
			ImGui::RadioButton("Photon mapping", (int*)&gi_method, 1);

			ImGui::Separator();

			if (gi_method == 0)
			{
				auto& mcsamples = mConfiguration.GetValue<unsigned>("montecarlo_samples");
				ImGui::SliderInt("Monte Carlo samples", (int*)&mcsamples, 1, 1000);
			}

			if (gi_method == 1)
			{
				auto& gather = mConfiguration.GetValue<unsigned>("photon_gather_method");
				ImGui::Text("Photon gather method");
				ImGui::RadioButton("Direct", (int*)&gather, 0);
				ImGui::SameLine();
				ImGui::RadioButton("Scatter", (int*)&gather, 1);
				ImGui::Spacing();

				if (gather == 1)
				{
					auto& sc_samples = mConfiguration.GetValue<unsigned>("gather_samples");
					ImGui::DragInt("Scatter samples", (int*)&sc_samples, 1, 1, 1000);
				}

				auto& num_photons = mConfiguration.GetValue<unsigned>("photons_per_light");
				ImGui::DragInt("Photons per light", (int*)&num_photons, 1, 1, 10000000);

				auto& bounces = mConfiguration.GetValue<unsigned>("photon_bounces");
				ImGui::SliderInt("Photon bounces", (int*)&bounces, 1, 10);

				auto& intensity = mConfiguration.GetValue<unsigned>("photon_intensity");
				ImGui::DragInt("Photon intensity multiplier", (int*)&intensity, 10, 0, 100000);

				auto& radius = mConfiguration.GetValue<float>("photon_radius");
				ImGui::DragFloat("Photon search radius", &radius, 1, 0, 25);
			}

			if (enable_gi)
			{
				auto& enable_ci = mConfiguration.GetValue<bool>("enable_irr_caching");
				ImGui::Checkbox("Enable Irradiance caching", &enable_ci);
			}

			ImGui::Separator();
		}
	}

	ImGui::Spacing();

	if (mIsRendering)
	{
		if (!mIsPaused)
		{
			if (HasRenderJobs())
			{
				ImGui::SameLine();
				if (ImGui::Button("Pause"))
					PauseRender(true);
				ImGui::SameLine();
				if (ImGui::Button("Cancel"))
					CancelRender();
			}
		}
		else
		{
			ImGui::SameLine();
			if (ImGui::Button("Resume"))
				PauseRender(false);
			ImGui::SameLine();
			if (ImGui::Button("Cancel"))
				CancelRender();
		}
	}
	else
	{
		if (ImGui::Button("Render"))
		{
			RenderLayer("World");
		}
	}

	if (!mRenderJobs.empty())
	{
		ShowPhotonMappingProgress();
		ShowIrradianceCachingProgress();
		ShowRenderProgress();
	}

	ImGui::End();
}