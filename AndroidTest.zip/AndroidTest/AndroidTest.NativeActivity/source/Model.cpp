#include "Model.h"

void Mesh::Draw(unsigned mode)
{
	glBindVertexArray(mVAO);
	glDrawElements(mode, mIndiceCount, GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);
}

void Mesh::DrawInstanced(unsigned count)
{
	glBindVertexArray(mVAO);
	glDrawElementsInstanced(GL_TRIANGLES, mIndiceCount, GL_UNSIGNED_INT, 0, count);
	glBindVertexArray(0);
}

void Mesh::UploadToGpu(const std::vector<Vertex>& vertices, const std::vector<unsigned>& indices)
{
	glGenVertexArrays(1, &mVAO);
	glGenBuffers(1, &mVBO);
	glGenBuffers(1, &mEBO);

	UploadToGpuUpdate(vertices, indices);
}

void Mesh::UploadToGpuUpdate(const std::vector<Vertex>& vertices, const std::vector<unsigned>& indices)
{
	mIndiceCount = (unsigned)indices.size();
	mVertexCount = (unsigned)vertices.size();
	mVertices = vertices;
	mIndices = indices;

	glBindVertexArray(mVAO);

	glBindBuffer(GL_ARRAY_BUFFER, mVBO);
	glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(Vertex), &vertices[0], GL_DYNAMIC_DRAW);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mEBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, mIndiceCount * sizeof(unsigned), &indices[0], GL_DYNAMIC_DRAW);

	// Vertex Positions
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, mPosition));

	// Vertex Texture Coords
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, mTexCoord));

	// Vertex Normals
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, mNormal));

	glBindVertexArray(0);
}

void Model::Draw(unsigned mode)
{
	for (auto& mesh : mMeshes)
		mesh.Draw(mode);
}

void Model::DrawInstanced(unsigned count)
{
	for (auto& mesh : mMeshes)
		mesh.DrawInstanced(count);
}