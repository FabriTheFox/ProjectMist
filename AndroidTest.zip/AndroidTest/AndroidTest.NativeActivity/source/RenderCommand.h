#pragma once

#include "Shader.h"
#include "Model.h"

class RenderConfig
{
public:
	RenderConfig(bool depthtest = true, bool depthwrite = true, bool wireframe = false);
	void ApplyConfig();

	bool mDepthTest{true};
	bool mDepthWriting{ true };
	bool mWireframe{ false };

	static void EnableDepthTest(bool enable);
	static void EnableDepthWrite(bool enable);
	static void EnableWireFrame(bool enable);
};

class RenderCommand
{
public:
	RenderCommand(WK_PTR<Shader> sh = {}, WK_PTR<Model> model = {}, RenderConfig renderconfig = {});

	void SetRenderConfig(const RenderConfig& config);
	void SetModel(WK_PTR<Model> model);
	void SetShader(WK_PTR<Shader> sh);

	RenderConfig& GetRenderConfig();
	WK_PTR<Model>& GetModel();
	WK_PTR<Shader>& GetShader();

	void ApplyConfig();

	void Render(unsigned mode = 4, SHD_PTR<Model> mod = {});
	void Render(unsigned mode, Model& mod);
	void RenderInstanced(unsigned count, SHD_PTR<Model> mod = {});

	void EnableDepthTest(bool enable);
	void EnableDepthWriting(bool enable);
	void EnableWireFrame(bool enable);

	void SetUniformfloat(const std::string& name, float data);
	void SetUniformfloatVec(const std::string& name, float* data, unsigned count);

	void SetUniformInt(const std::string& name, int data);
	void SetUniformIntVec(const std::string& name, int* data, unsigned count);

	void SetUniformVec2(const std::string& name, const Vec2& data);
	void SetUniformVec2Vec(const std::string& name, Vec2* data, unsigned count);

	void SetUniformVec3(const std::string& name, const Vec3& data);
	void SetUniformVec3Vec(const std::string& name, Vec3* data, unsigned count);

	void SetUniformVec4(const std::string& name, const Vec4& data);
	void SetUniformVec4Vec(const std::string& name, Vec4* data, unsigned count);

	void SetUniformMat4(const std::string& name, const Mat4& data);
	void SetUniformMat4Vec(const std::string& name, Mat4* data, unsigned count);

private:
	bool HasShader();
	bool HasModel();

	bool HasShader_Warning();
	bool HasModel_Warning();

	RenderConfig mRenderConfig;

	WK_PTR<Shader> mpShader;
	WK_PTR<Model> mpModel;
};