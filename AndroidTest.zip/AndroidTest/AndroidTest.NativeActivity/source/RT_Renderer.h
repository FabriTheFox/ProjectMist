#pragma once

#include "RT_Renderable.h"
#include "Intersection.h"
#include "RT_PhotonMap.h"
#include <vector>

class RT_Layer;

class RT_Renderer
{
public:
	struct RenderData
	{
		unsigned mBounces{ 0 };
		unsigned mGIBounces{ true };
		bool mFirstBounce{ true };
		Vec2 mRefract_Reflect_mult{ 1.f };
		RT_Renderable* mpRT_Renderable{ nullptr };
	};

	FTEIntersection::IntersectionResult GetNearestIntersection(const Vec3& start, const Vec3& dir, RenderData& data);
	FTEIntersection::IntersectionResult GetNearestIntersection_Shadow(const Vec3& start, const Vec3& dir, RenderData& data);

	void EmitPhoton(RT_PhotonMap& map, RT_PhotonMap::PhotonData& photon, FTEIntersection::IntersectionResult& at, RT_Renderer::RenderData& data);

	Vec4 Render(FTEIntersection::IntersectionResult& res, RenderData& data);
	Vec4 Render_Basic(FTEIntersection::IntersectionResult& res, RenderData& data);
	Vec4 Render_Phong(FTEIntersection::IntersectionResult& res, RenderData& data);
	Vec4 Render_ReflectivePhong(FTEIntersection::IntersectionResult& res, RenderData& data);
	Vec4 Render_RefractivePhong(FTEIntersection::IntersectionResult& res, RenderData& data);

	typedef Vec4(RT_Renderer::*pRenderFN)(FTEIntersection::IntersectionResult&, RenderData&);

	pRenderFN mRenderFN{nullptr};
	std::vector<RT_Renderable> mRenderables;
	RT_Layer* mpLayer;

	static bool mRenderDebugLines;
};