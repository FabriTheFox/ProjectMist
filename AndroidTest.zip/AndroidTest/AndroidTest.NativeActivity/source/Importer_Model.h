#pragma once

#include "Importer.h"

class Importer_Model : public Importer
{
public:
	IMPORTER_DECLARATION(Importer_Model)
	void Import(const std::string& name, const std::string& patht) override;
	void LoadFBXModel(void* pNode, Asset* asset);
private:
};