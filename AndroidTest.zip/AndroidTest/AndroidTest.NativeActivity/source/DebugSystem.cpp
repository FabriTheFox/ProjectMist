#include "DebugSystem.h"
#include "FoxTracerEngine.h"
#include "EditorSystem.h"

#include "RTTI_imp.h"

RTTI_IMPLEMENTATION(DebugSystem);

void DebugSystem::Initialize()
{
	FoxTracerEngine::GetSystem<EditorSystem>().AddGUIWindow(&Console::ShowGUI, &mConsole, "Console", "", 0);
}

void DebugSystem::Update() 
{
	mConsole.WriteLine(mFrameLog.str());

#if FTE_WINDOWS_CONSOLE_OUTPUT
	std::cout << mFrameLog.str();
#endif

	mFrameLog.clear();
}

void DebugSystem::ShowDebug() {}
void DebugSystem::Shutdown() {}

std::stringstream& DebugSystem::Write()
{
	return mFrameLog;
}

DebugSystem::FTEStreamBuffer DebugSystem::WriteError()
{
	DebugSystem::FTEStreamBuffer sb;
	sb.mType = 2;
	return sb;
}

DebugSystem::FTEStreamBuffer DebugSystem::WriteWarning()
{
	DebugSystem::FTEStreamBuffer sb;
	sb.mType = 1;
	return sb;
}

DebugSystem::FTEStreamBuffer DebugSystem::WriteLine(const Vec3& color)
{
	DebugSystem::FTEStreamBuffer sb;
	sb.mColor = color;
	return sb;
}

DebugSystem::FTEStreamBuffer::~FTEStreamBuffer()
{
	auto string = str();
	if (string.empty())
		return;

	static auto& deb = FoxTracerEngine::GetSystem<DebugSystem>();

	static std::string wn = "[WARNING] ";
	static std::string err = "[ERROR] ";

	switch (mType)
	{
	// Standard
	case 0:
		deb.mConsole.WriteLine(string, mColor);
		break;
	// Warning
	case 1:
		deb.mConsole.WriteLine(wn + string, {1, 1, 0});
		break;
	// Error
	case 2:
		deb.mConsole.WriteLine(err + string, { 1, 0, 0 });
		break;
	default:
		break;
	}
}

DebugSystem::FTEStreamBuffer::FTEStreamBuffer(const FTEStreamBuffer& rhs)
{
	mColor = rhs.mColor;
	mType = rhs.mType;
}