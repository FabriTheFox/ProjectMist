#pragma once

#include "Entity.h"
#include "System.h"

class EntitySpace
{
	friend class Entity;
	friend class Editor;
	friend class EntitySystem;

public:
	const std::string& GetName();
	void SetName(const std::string& name);

	Entity& GetEntity(const std::string& name);
	EntitySpace& GetChildSpace(const std::string& name);
	SHD_PTR<Entity> GetEntityPtr(const std::string& name);
	std::vector<SHD_PTR<Entity>>& GetEntities();
	void GetAllEntities(std::vector<SHD_PTR<Entity>>& vec);

private:
	SHDPtrVec<EntitySpace> mChildren;
	SHDPtrVec<Entity> mEntities;

	std::string mName;
};