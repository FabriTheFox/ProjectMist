#pragma once

#include <deque>
#include <string>

#include "DataTypes.h"

class Console
{
public:
	void ShowGUI();
	void WriteLine(const std::string& line, Vec3 color = {1, 1, 1});

	void Clear();

private:
	struct ConsoleEntry
	{
		std::string mData;
		Vec3 mColor;
	};

	bool mScrollToBottom{ false };
	std::deque<ConsoleEntry> mEntries;
};