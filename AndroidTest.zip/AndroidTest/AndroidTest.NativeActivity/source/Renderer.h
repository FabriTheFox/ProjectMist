#pragma once

#include "Shader.h"
#include "Renderable.h"
#include "System.h"
#include "Camera.h"
#include "RT_Renderer.h"
#include "RenderCommand.h"

class Layer;

class Renderer : public Base
{
	RTTI_DECLARATION(Renderer)
	NON_COPYABLE(Renderer)
public:
	Renderer(const std::string& shader, const std::string& layer);

	virtual void Render() = 0;
	virtual void AddRenderer(SHD_PTR<Renderable> pren);
	virtual void RemoveRenderable(SHD_PTR<Renderable> pren);
	SHDPtrVec<Renderable>& GetRenderables();
	Shader& GetShader();
	Camera& GetLayerCamera();

	// Ray tracing ================================================================================
	void FillRTData(RT_Renderer& renderer);
	// ============================================================================================

protected:
	Shader& mShader;
	Layer& mLayer;
	Camera& mCamera;

	SHDPtrVec<Renderable> mRenderables;
};

class BasicRenderer : public Renderer
{
	RTTI_DECLARATION(BasicRenderer)
	NON_COPYABLE(BasicRenderer)
public:
	BasicRenderer(const std::string& name, const std::string& layer);
	void Render() override;
};

class PhongLightRenderer : public Renderer
{
	RTTI_DECLARATION(PhongLightRenderer)
	NON_COPYABLE(PhongLightRenderer)
public:
	PhongLightRenderer(const std::string& name, const std::string& layer);
	void Render() override;
};

class ReflectivePhongLightRenderer : public PhongLightRenderer
{
	RTTI_DECLARATION(ReflectivePhongLightRenderer)
	NON_COPYABLE(ReflectivePhongLightRenderer)
public:
	ReflectivePhongLightRenderer(const std::string& name, const std::string& layer);
};

class RefractivePhongLightRenderer : public PhongLightRenderer
{
	RTTI_DECLARATION(RefractivePhongLightRenderer)
	NON_COPYABLE(RefractivePhongLightRenderer)
public:
	RefractivePhongLightRenderer(const std::string& name, const std::string& layer);
};

class AnimationRenderer : public Renderer
{
	RTTI_DECLARATION(AnimationRenderer)
	NON_COPYABLE(AnimationRenderer)
public:
	AnimationRenderer(const std::string& name, const std::string& layer);
	void Render() override;
	void RenderAnimationNode(AnimationInstanceNode& node, RenderCommand& rc, SHD_PTR<Renderable> ren);
};

class CameraLightRenderer : public Renderer
{
	RTTI_DECLARATION(CameraLightRenderer)
	NON_COPYABLE(CameraLightRenderer)
public:
	CameraLightRenderer(const std::string& name, const std::string& layer);
	void Render() override;
};

class ClothMeshRenderer : public Renderer
{
	RTTI_DECLARATION(ClothMeshRenderer)
	NON_COPYABLE(ClothMeshRenderer)
public:
	ClothMeshRenderer(const std::string& name, const std::string& layer);
	void Render() override;
};

class ClothTextureRenderer : public Renderer
{
	RTTI_DECLARATION(ClothTextureRenderer)
	NON_COPYABLE(ClothTextureRenderer)
public:
	ClothTextureRenderer(const std::string& name, const std::string& layer);
	void Render() override;
};