#include "AssetSystem.h"
#include "Model.h"
#include "RTTI_imp.h"
#include <stb_image\stb_image.h>
#include <stb_image\stb_image_write.h>

#include "Importer_Model.h"
#include "Importer_Animation.h"
#include "Importer_Scene.h"
#include "Importer_Shader.h"
#include "Importer_Texture.h"

RTTI_IMPLEMENTATION(AssetSystem);

void AssetSystem::Initialize()
{
	AssignImporterExtension<Importer_Scene>("fbx");

	AssignImporterExtension<Importer_Model>("obj");

	AssignImporterExtension<Importer_Shader>("vert");
	AssignImporterExtension<Importer_Shader>("frag");
	AssignImporterExtension<Importer_Shader>("geom");

	AssignImporterExtension<Importer_Texture>("jpg");
	AssignImporterExtension<Importer_Texture>("png");

	LoadPrimitives();
}

void AssetSystem::Update()
{
	for (auto& type : mAssets)
		for (auto& asset : type.second)
			asset.second->ReloadAsset();
}

void AssetSystem::LoadAsset(const std::string& path, const std::string& username)
{
	std::string ext = Utilities::GetFileExtension(path);
	std::string name = username.empty() ? Utilities::GetFileName(path) : username;
	auto importer = mImporters.find(ext);
	importer->second.lock()->Import(name, path);
}

void AssetSystem::LoadPrimitives()
{
	LoadPrimitiveModels();
	LoadPrimitiveShaders();
}

void AssetSystem::LoadPrimitiveModels()
{
	auto loadmodel = [&](const std::string& name, std::vector<Vertex>& vert, std::vector<unsigned>& ind)
	{
		auto newasset = std::make_shared<Model>();
		newasset->mMeshes.push_back(Mesh());
		newasset->mMeshes.back().UploadToGpu(vert, ind);
		vert.clear();
		ind.clear();
		(mAssets[Model::RTTI_.mTypehash])[name] = newasset;
	};

	std::vector<Vertex> vert;
	std::vector<unsigned> ind;

	// Point
	LoadPoint(vert, ind);
	loadmodel("Point", vert, ind);

	// Quad
	LoadQuad(vert, ind);
	loadmodel("Quad", vert, ind);

	// Line
	LoadLine(vert, ind);
	loadmodel("Line", vert, ind);

	// Cube
	LoadCube(vert, ind);
	loadmodel("Cube", vert, ind);

	// WireCube
	LoadWireCube(vert, ind);
	loadmodel("WireCube", vert, ind);

	// Cloth
	LoadCloth(vert, ind);
	loadmodel("Cloth", vert, ind);
}

void AssetSystem::LoadPrimitiveShaders()
{
	LoadAsset("assets/shaders/LinesShader.frag,assets/shaders/LinesShader.vert", "LinesShader");
	LoadAsset("assets/shaders/PointShader.frag,assets/shaders/PointShader.vert", "PointShader");
}

void AssetSystem::LoadPoint(std::vector<Vertex>& vert, std::vector<unsigned>& ind)
{
	vert.push_back({ { 0, 0, 0 }, { 1, 1 }, { 0, 0, 0 } });
	ind.push_back(0);
}

void AssetSystem::LoadQuad(std::vector<Vertex>& vert, std::vector<unsigned>& ind)
{
	vert.push_back({ { +0.5f, +0.5f, 0 },{ 1, 1 },{ 0, 0, 1 } });
	vert.push_back({ { -0.5f, +0.5f, 0 },{ 0, 1 },{ 0, 0, 1 } });
	vert.push_back({ { -0.5f, -0.5f, 0 },{ 0, 0 },{ 0, 0, 1 } });
	vert.push_back({ { +0.5f, -0.5f, 0 },{ 1, 0 },{ 0, 0, 1 } });

	ind.push_back(0);
	ind.push_back(1);
	ind.push_back(2);

	ind.push_back(0);
	ind.push_back(2);
	ind.push_back(3);
}

void AssetSystem::LoadLine(std::vector<Vertex>& vert, std::vector<unsigned>& ind)
{
	vert.resize(2);
	ind.push_back(0);
	ind.push_back(1);
}

void AssetSystem::LoadCube(std::vector<Vertex>& vert, std::vector<unsigned>& ind)
{
	vert.push_back({{-0.5, -0.5, +0.5}, {0.0, 1.0}, {0.0, 0.0, 1.0}});
	vert.push_back({{+0.5, -0.5, +0.5}, {1.0, 1.0}, {0.0, 0.0, 1.0}});
	vert.push_back({{+0.5, +0.5, +0.5}, {1.0, 0.0}, {0.0, 0.0, 1.0}});
	vert.push_back({{-0.5, -0.5, +0.5}, {0.0, 1.0}, {0.0, 0.0, 1.0}});
	vert.push_back({{+0.5, +0.5, +0.5}, {1.0, 0.0}, {0.0, 0.0, 1.0}});
	vert.push_back({{-0.5, +0.5, +0.5}, {0.0, 0.0}, {0.0, 0.0, 1.0}});

	vert.push_back({{+0.5, -0.5, +0.5}, {0.0, 1.0}, {1.0, 0.0, 0.0}});
	vert.push_back({{+0.5, -0.5, -0.5}, {1.0, 1.0}, {1.0, 0.0, 0.0}});
	vert.push_back({{+0.5, +0.5, -0.5}, {1.0, 0.0}, {1.0, 0.0, 0.0}});
	vert.push_back({{+0.5, -0.5, +0.5}, {0.0, 1.0}, {1.0, 0.0, 0.0}});
	vert.push_back({{+0.5, +0.5, -0.5}, {1.0, 0.0}, {1.0, 0.0, 0.0}});
	vert.push_back({{+0.5, +0.5, +0.5}, {0.0, 0.0}, {1.0, 0.0, 0.0}});

	vert.push_back({{+0.5, -0.5, -0.5}, {0.0, 1.0}, {0.0, 0.0, -1.0}});
	vert.push_back({{-0.5, -0.5, -0.5}, {1.0, 1.0}, {0.0, 0.0, -1.0}});
	vert.push_back({{-0.5, +0.5, -0.5}, {1.0, 0.0}, {0.0, 0.0, -1.0}});
	vert.push_back({{+0.5, -0.5, -0.5}, {0.0, 1.0}, {0.0, 0.0, -1.0}});
	vert.push_back({{-0.5, +0.5, -0.5}, {1.0, 0.0}, {0.0, 0.0, -1.0}});
	vert.push_back({{+0.5, +0.5, -0.5}, {0.0, 0.0}, {0.0, 0.0, -1.0}});

	vert.push_back({{-0.5, -0.5, -0.5}, {0.0, 1.0}, {-1.0, 0.0, 0.0}});
	vert.push_back({{-0.5, -0.5, +0.5}, {1.0, 1.0}, {-1.0, 0.0, 0.0}});
	vert.push_back({{-0.5, +0.5, +0.5}, {1.0, 0.0}, {-1.0, 0.0, 0.0}});
	vert.push_back({{-0.5, -0.5, -0.5}, {0.0, 1.0}, {-1.0, 0.0, 0.0}});
	vert.push_back({{-0.5, +0.5, +0.5}, {1.0, 0.0}, {-1.0, 0.0, 0.0}});
	vert.push_back({{-0.5, +0.5, -0.5}, {0.0, 0.0}, {-1.0, 0.0, 0.0}});

	vert.push_back({{-0.5, +0.5, +0.5}, {0.0, 1.0}, {0.0, 1.0, 0.0}});
	vert.push_back({{+0.5, +0.5, +0.5}, {1.0, 1.0}, {0.0, 1.0, 0.0}});
	vert.push_back({{+0.5, +0.5, -0.5}, {1.0, 0.0}, {0.0, 1.0, 0.0}});
	vert.push_back({{-0.5, +0.5, +0.5}, {0.0, 1.0}, {0.0, 1.0, 0.0}});
	vert.push_back({{+0.5, +0.5, -0.5}, {1.0, 0.0}, {0.0, 1.0, 0.0}});
	vert.push_back({{-0.5, +0.5, -0.5}, {0.0, 0.0}, {0.0, 1.0, 0.0}});

	vert.push_back({{-0.5, -0.5, -0.5}, {0.0, 1.0}, {0.0, -1.0, 0.0}});
	vert.push_back({{+0.5, -0.5, -0.5}, {1.0, 1.0}, {0.0, -1.0, 0.0}});
	vert.push_back({{+0.5, -0.5, +0.5}, {1.0, 0.0}, {0.0, -1.0, 0.0}});
	vert.push_back({{-0.5, -0.5, -0.5}, {0.0, 1.0}, {0.0, -1.0, 0.0}});
	vert.push_back({{+0.5, -0.5, +0.5}, {1.0, 0.0}, {0.0, -1.0, 0.0}});
	vert.push_back({{-0.5, -0.5, +0.5}, {0.0, 0.0}, {0.0, -1.0, 0.0}});

	for (int i = 0; i < 36; ++i)
		ind.push_back(i);
}

void AssetSystem::LoadWireCube(std::vector<Vertex>& vert, std::vector<unsigned>& ind)
{
	vert.push_back({ {  0.5,  0.5,  0.5 }, { 0, 0 }, { 0, 0, 0 } });
	vert.push_back({ {  0.5,  0.5, -0.5 }, { 0, 0 }, { 0, 0, 0 } });
	vert.push_back({ {  0.5, -0.5,  0.5 }, { 0, 0 }, { 0, 0, 0 } });
	vert.push_back({ {  0.5, -0.5, -0.5 }, { 0, 0 }, { 0, 0, 0 } });
	vert.push_back({ { -0.5,  0.5,  0.5 }, { 0, 0 }, { 0, 0, 0 } });
	vert.push_back({ { -0.5,  0.5, -0.5 }, { 0, 0 }, { 0, 0, 0 } });
	vert.push_back({ { -0.5, -0.5,  0.5 }, { 0, 0 }, { 0, 0, 0 } });
	vert.push_back({ { -0.5, -0.5, -0.5 }, { 0, 0 }, { 0, 0, 0 } });

	ind.push_back(0);
	ind.push_back(1);
	ind.push_back(2);
	ind.push_back(3);
	ind.push_back(4);
	ind.push_back(5);
	ind.push_back(6);
	ind.push_back(7);
	ind.push_back(0);
	ind.push_back(2);
	ind.push_back(2);
	ind.push_back(6);
	ind.push_back(6);
	ind.push_back(4);
	ind.push_back(4);
	ind.push_back(0);
	ind.push_back(1);
	ind.push_back(3);
	ind.push_back(3);
	ind.push_back(7);
	ind.push_back(7);
	ind.push_back(5);
	ind.push_back(5);
	ind.push_back(1);
}

void AssetSystem::LoadCloth(std::vector<Vertex>& vert, std::vector<unsigned>& ind)
{
	const int X = 10;
	const int Y = 10;

	for (int y = 0; y < Y; ++y)
	{
		for (int x = 0; x < X; ++x)
		{
			float xx = ((float)x / X) - 0.5f;
			float yy = ((float)y / Y) - 0.5f;

			vert.push_back({ { xx, 0.f, yy }, { 0, 0 }, { 0, 0, 0 } });
		}
	}

	for (int y = 0; y < Y - 1; ++y)
	{
		for (int x = 0; x < X - 1; ++x)
		{
			int curr = (y*X) + x;

			ind.push_back(curr);
			ind.push_back(curr + 1);
			ind.push_back(curr + X);

			ind.push_back(curr + 1);
			ind.push_back(curr + 1 + X);
			ind.push_back(curr + X);
		}
	}
}