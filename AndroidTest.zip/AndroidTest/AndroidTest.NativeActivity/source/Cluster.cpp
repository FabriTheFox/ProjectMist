#include "Cluster.h"

Cluster::Cluster(RenderJob& renjob, const IVec2& start, const IVec2& size, unsigned samples, ClusterState state) :
	mStart(start),
	mSize(size),
	mState(state),
	mRenderJob(renjob),
	mSamples(samples)
{}

void Cluster::Render()
{
	mState = RUNNING;

	auto res = mRenderJob.mResolution;
	auto back_color = mRenderJob.mConfig.GetValue<Vec4>("background_color");
	auto campos = mRenderJob.mCamera.GetTransform().mPosition;
	unsigned samples = (unsigned)std::sqrt(mSamples);
	unsigned ref = mRenderJob.mConfig.GetValue<unsigned>("max_reflection_levels");

	mDOF_Enabled = mRenderJob.mConfig.GetValue<bool>("depth_of_field");
	mDOF_Samples = mRenderJob.mConfig.GetValue<unsigned>("dof_samples");
	mDOF_Aperture = mRenderJob.mConfig.GetValue<float>("dof_aperture");

	Vec3 sampleoffset = -((mRenderJob.mTexelSizeX * 0.5f) + (mRenderJob.mTexelSizeY * 0.5f)) + (mRenderJob.mTexelSizeX * (0.5f / samples)) + (mRenderJob.mTexelSizeY * (0.5f / samples));
	float samplesize = 1.f / samples;
	Vec3 samplesize_x = mRenderJob.mTexelSizeX * samplesize;
	Vec3 samplesize_y = mRenderJob.mTexelSizeY * samplesize;

	if (!mDOF_Enabled)
		mDOF_Aperture = 0;

	for (int y = mStart.y; y < mStart.y + mSize.y; ++y)
	{
		for (int x = mStart.x; x < mStart.x + mSize.x; ++x)
		{
			Vec4 color = {0, 0, 0, 0};

			for (unsigned sy = 0; sy < samples; ++sy)
			{
				for (unsigned sx = 0; sx < samples; ++sx)
				{
					for (unsigned dof = 0; dof < mDOF_Samples; ++dof)
					{
						// If interrupt signal is on, exit from here
						if (mInterrupt) {
							mState = FINISHED;
							return;
						}

						// Wait here if its paused
						while (mPaused) {
							if (mInterrupt) {
								mState = FINISHED;
								return;
							}
						}

						Vec3 sample = { Utilities::Random(-1.f, 1.f) , Utilities::Random(-1.f, 1.f) , Utilities::Random(-1.f, 1.f) };
						sample *= mDOF_Aperture;

						auto proj = mRenderJob.mProjPlanePositions[(y * res.x) + x];
						proj += sampleoffset;
						proj += (samplesize_x * (float)sx) + (samplesize_y * (float)sy);

						Vec3 raydir = glm::normalize(proj - (campos + sample));

						RT_Renderer::RenderData data;
						data.mBounces = ref;
						data.mGIBounces = 1;

						color += mRenderJob.mRTLayer.ComputeColor(campos + sample, raydir, back_color, data);
					}

					color /= mDOF_Samples;
				}
			}

			color /= mSamples;

			auto& tex = mRenderJob.mTexelArray;
			unsigned off = ((y * res.x) + x) * 4;

			tex[off + 0] = (unsigned char)(color.x * 255);
			tex[off + 1] = (unsigned char)(color.y * 255);
			tex[off + 2] = (unsigned char)(color.z * 255);
			tex[off + 3] = (unsigned char)(color.w * 255);
		}
	}

	mState = FINISHED;
}

void Cluster::RenderHighlight()
{
	if (mState == RUNNING)
	{
		auto p0 = mRenderJob.mProjPlanePositions[(mStart.y * mRenderJob.mResolution.x) + mStart.x];
		auto p1 = mRenderJob.mProjPlanePositions[(mStart.y * mRenderJob.mResolution.x) + (mStart.x + (mSize.x - 1))];
		auto p2 = mRenderJob.mProjPlanePositions[((mStart.y + (mSize.y - 1)) * mRenderJob.mResolution.x) + mStart.x];
		auto p3 = mRenderJob.mProjPlanePositions[((mStart.y + (mSize.y - 1)) * mRenderJob.mResolution.x) + (mStart.x + (mSize.x - 1))];

		mRenderJob.mLayer.RenderDebugLine(p0, p1, { 1, 1, 1, 1 }, 3);
		mRenderJob.mLayer.RenderDebugLine(p0, p2, { 1, 1, 1, 1 }, 3);
		mRenderJob.mLayer.RenderDebugLine(p1, p3, { 1, 1, 1, 1 }, 3);
		mRenderJob.mLayer.RenderDebugLine(p2, p3, { 1, 1, 1, 1 }, 3);
	}
}

void Cluster::Interrupt()
{
	mInterrupt = true;
}

void Cluster::Pause(bool pause)
{
	mPaused = pause;
}