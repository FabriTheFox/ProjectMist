#include "RT_IrradianceCache.h"
#include "RenderJob.h"

RT_IrradianceCache::RT_IrradianceCache()
{
	mIrradianceTree = new PointOctree<IrradianceValue>;
}

RT_IrradianceCache::~RT_IrradianceCache()
{
	if(mIrradianceTree)
		delete mIrradianceTree;
}

void RT_IrradianceCache::Launch(RenderJob* renderjob)
{
	mRenderJob = renderjob;
	Initialize();

	SearchCachePoints();
	ComputeCache();
	BuildOctree();

	mStatus = IC_FINISHED;
}

void RT_IrradianceCache::Initialize()
{
	mResolution = mRenderJob->mResolution;
	mRadius = mRenderJob->mConfig.GetValue<float>("irradiance_radius");
	mSQRadius = mRadius * mRadius;
}

Vec3 RT_IrradianceCache::ComputeIrradianceAt(const Vec3& pos, const Vec3& norm)
{
	std::vector<IrradianceValue> neigh;
	mIrradianceTree->GetNearbyElements(pos, mRadius, neigh);
	
	Vec3 total_irradiance;
	float total_weight = 0;
	
	for (auto& n : neigh)
	{
		auto disvec = n.mPos - pos;
		float sqdis = glm::dot(disvec, disvec);
	
		if (sqdis <= mSQRadius && glm::dot(norm, n.mNormal) > 0.95f)
		{
			total_irradiance += Vec3(n.mColor);
			float weight = 1.f / ((glm::sqrt(sqdis) / mRadius) + glm::sqrt(1 + glm::dot(n.mNormal, norm)));
			total_weight += weight;
		}
	}
	
	Color color;
	color.mColor = Vec4(Vec3(total_irradiance / total_weight), 1.f);
	
	color.ClampMaxTo(1.f);
	return color;
}

void RT_IrradianceCache::SearchCachePoints()
{
	mStatus = IC_SEARCHING_CACHE_POINTS;

	mScreen.resize(mResolution.x * mResolution.y);

	for (int y = 0; y < mResolution.y; ++y)
	{
		for (int x = 0; x < mResolution.x; ++x)
		{
			auto proj = mRenderJob->mProjPlanePositions[(y * mResolution.x) + x];
			Vec3 raydir = glm::normalize(proj - (mRenderJob->mCamera.GetTransform().mPosition));

			RT_Renderer::RenderData data;
			auto& res = mScreen[((y * mResolution.x) + x)];
			res = mRenderJob->mRTLayer.TraceRay(mRenderJob->mCamera.GetTransform().mPosition, raydir, data);
			res.mNormal = glm::normalize(res.mNormal);
		}
	}

	for (int y = 0; y < mResolution.y; ++y)
		for (int x = 0; x < mResolution.x; ++x)
			EvaluateSample(x, y);
}		

void RT_IrradianceCache::ComputeCache()
{
	mStatus = IC_COMPUTING_CACHE;

	for (auto& val : mHotValues)
	{
		unsigned off = ((val.mScreen.y * mResolution.x) + val.mScreen.x);
		auto proj = mRenderJob->mProjPlanePositions[off];
		Vec3 raydir = glm::normalize(proj - (mRenderJob->mCamera.GetTransform().mPosition));

		RT_Renderer::RenderData data;
		auto color = mRenderJob->mRTLayer.ComputeGI(mRenderJob->mCamera.GetTransform().mPosition, raydir, data);

		auto& tex = mRenderJob->mTexelArray;
		tex[(off * 4) + 0] = (unsigned char)(255 * color.x);
		tex[(off * 4) + 1] = (unsigned char)(255 * color.y);
		tex[(off * 4) + 2] = (unsigned char)(255 * color.z);
		tex[(off * 4) + 3] = (unsigned char)(255 * color.w);

		val.mColor = color;
	}
}

void RT_IrradianceCache::BuildOctree()
{
	mStatus = IC_BUILDING_OCTREE;

	std::vector<PointOctree<IrradianceValue>::OCTData> datavec;
	std::vector<Vec3> positions;
	for (auto& irr : mHotValues)
	{
		positions.push_back(irr.mPos);
		datavec.push_back({});
		datavec.back().mData = irr;
		datavec.back().mPosition = irr.mPos;
	}

	AABB bb(positions);
	positions.clear();

	mIrradianceTree->Initialize(bb, 5);
	for (auto& irr : datavec)
		mIrradianceTree->InsertElement(irr);
}

bool RT_IrradianceCache::EvaluateSample(unsigned x, unsigned y)
{
	auto& res = mScreen[((y * mResolution.x) + x)];
	if (!res.HasCollided())
		return false;

	auto& camerapos = mRenderJob->mCamera.GetTransform().mPosition;
	auto topoint = res.mIntersectionPoint - camerapos;
	float distance = glm::dot(topoint, topoint);

	float amount = 0;

	unsigned samples = 32;
	for (unsigned i = 0; i < samples; ++i)
	{
		auto sample = glm::normalize(Vec3{ Utilities::Random(-1.f, 1.f) , Utilities::Random(-1.f, 1.f) , Utilities::Random(-1.f, 1.f) });
		if (glm::dot(sample, res.mNormal) < 0)
			sample = -sample;
		float ran = Utilities::Random(0.5f, 1.f);
		sample *= ran * ran;

		IVec2 screen_coord = Utilities::WorldToScreenCoords(res.mIntersectionPoint + (sample * mRadius), mRenderJob->mWorldToScreen, mResolution);

		if (screen_coord.x < 0 || screen_coord.y < 0 || screen_coord.x >= mResolution.x || screen_coord.y >= mResolution.y)
			continue;

		auto& sample_pos = mScreen[((screen_coord.y * mResolution.x) + screen_coord.x)];

		auto tosample = sample_pos.mIntersectionPoint - camerapos;
		if (glm::dot(tosample, tosample) < distance)
			amount += 1;
	}

	amount = (1.1f - (amount / samples));
	TestCache(x, y, mRadius * amount* amount);

	return true;
}

void RT_IrradianceCache::TestCache(unsigned x, unsigned y, float radius)
{
	float radsq = radius * radius;
	auto& res = mScreen[((y * mResolution.x) + x)];

	for (int i = (int)mHotValues.size() - 1; i >= 0; i--)
	{
		auto disvec = mHotValues[i].mPos - res.mIntersectionPoint;
		float sqdis = glm::dot(disvec, disvec);

		if (sqdis <= radsq && glm::dot(res.mNormal, mHotValues[i].mNormal) > 0.95f)
			return;
	}

	mHotValues.push_back(IrradianceValue());
	auto& val = mHotValues.back();
	val.mNormal = res.mNormal;
	val.mPos = res.mIntersectionPoint;
	val.mScreen = { x, y };

	auto& tex = mRenderJob->mTexelArray;
	int off = ((y * mResolution.x) + x) * 4;
	tex[off + 0] = (unsigned char)(255);
	tex[off + 1] = (unsigned char)(255);
	tex[off + 2] = (unsigned char)(255);
	tex[off + 3] = (unsigned char)(255);
}