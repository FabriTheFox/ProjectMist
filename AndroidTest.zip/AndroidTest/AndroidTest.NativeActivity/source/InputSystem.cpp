#include "InputSystem.h"
#include "SDLHeaders.h"
#include "RTTI_imp.h"

RTTI_IMPLEMENTATION(InputSystem)

void InputSystem::Initialize()
{
	memset(mCurrentKeys, 0, MAX_SCANCODES);
	memset(mPreviousKeys, 0, MAX_SCANCODES);

	memset(mCurrentMouse, 0, 6);
	memset(mPreviousMouse, 0, 6);
}

void InputSystem::EnableInput(bool enable)
{
	mEnableInput = enable;

	if (!enable)
		ResetInput();
}

void InputSystem::StartOfFrame()
{
	mMouseMotion = { 0, 0 };
}

void InputSystem::ResetInput()
{
	memset(mCurrentKeys, 0, MAX_SCANCODES);
	memset(mPreviousKeys, 0, MAX_SCANCODES);

	memset(mCurrentMouse, 0, 6);
	memset(mPreviousMouse, 0, 6);
}

void InputSystem::Update() 
{
	for (int i = 0; i < SDL_NUM_SCANCODES; ++i)
	{
		if (mCurrentKeys[i] == 1 && (mPreviousKeys[i] == 1 || mPreviousKeys[i] == 2))
			mCurrentKeys[i] = 2;
		if (mPreviousKeys[i] == 3)
			mCurrentKeys[i] = 0;
	}

	for (int i = 0; i < 6; ++i)
	{
		if (mCurrentMouse[i] == 1 && (mPreviousMouse[i] == 1 || mPreviousMouse[i] == 2))
			mCurrentMouse[i] = 2;
		if (mPreviousMouse[i] == 3)
			mCurrentMouse[i] = 0;
	}

	for (int i = 0; i < SDL_NUM_SCANCODES; ++i)
		mPreviousKeys[i] = mCurrentKeys[i];
	for (int i = 0; i < 6; ++i)
		mPreviousMouse[i] = mCurrentMouse[i];
}

void InputSystem::ProcessSDLEvent(void* ev)
{
	if (!mEnableInput)
		return;

	auto& sld_ev = *(SDL_Event*)(ev);

	switch (sld_ev.type)
	{
	case SDL_KEYDOWN:
		mCurrentKeys[sld_ev.key.keysym.scancode] = 1;
		break;
	case SDL_KEYUP:
		mCurrentKeys[sld_ev.key.keysym.scancode] = 3;
		break;
	case SDL_MOUSEMOTION:
		mMouseMotion = { sld_ev.motion.xrel, sld_ev.motion.yrel };
		break;
	case SDL_MOUSEBUTTONDOWN:
		mCurrentMouse[sld_ev.button.button] = 1;
		break;
	case SDL_MOUSEBUTTONUP:
		mCurrentMouse[sld_ev.button.button] = 3;
		break;
	}
}


bool InputSystem::KeyTriggered(unsigned key) { return mCurrentKeys[key] == 1; }
bool InputSystem::KeyPressed(unsigned key) { return mCurrentKeys[key] == 2 || mCurrentKeys[key] == 1; }
bool InputSystem::KeyReleased(unsigned key) { return mCurrentKeys[key] == 3; }

bool InputSystem::MouseTriggered(char button) { return mCurrentMouse[button] == 1; }
bool InputSystem::MousePressed(char button) { return mCurrentMouse[button] == 2 || mCurrentMouse[button] == 1; }
bool InputSystem::MouseReleased(char button) { return mCurrentMouse[button] == 3; }

const Vec2& InputSystem::GetMouseMotion() { return mMouseMotion; }
IVec2 InputSystem::GetMousePosition()
{
	IVec2 pos;
	SDL_GetMouseState(&pos.x, &pos.y);
	return pos;
}