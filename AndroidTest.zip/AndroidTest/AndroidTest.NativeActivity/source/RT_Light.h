#pragma once

#include "DataTypes.h"
#include "Intersection.h"
#include "RT_Renderer.h"
#include "RT_PhotonMap.h"
#include <thread>

class RT_Layer;

class RT_Light
{
public:
	struct Attenuation
	{
		float mInnerRadius{ 0 };
		float mOuterRadius{ 25 };
	};

	Vec3 mDiffuse{ 1, 1, 1 };
	Vec3 mSpecular{ 1, 1, 1 };
	Vec3 mAmbient{ 0.1f, 0.1f, 0.1f };
	Attenuation mAttenuation;

	Vec3 mPosition;
	RT_Layer* mpLayer;

	Vec4 ComputeColor(FTEIntersection::IntersectionResult& inters, RT_Renderer::RenderData& data) { return (this->*mRenderFN)(inters, data); }
	void EmitPhotons(RT_PhotonMap& map, RT_Renderer::RenderData& data, unsigned photon_num, unsigned photon_intensity);
	void ThreadEmitPhotons(unsigned num, unsigned photon_num, RT_PhotonMap* map, RT_Renderer::RenderData& data, unsigned photon_intensity);

	float ComputeShadow(const Vec3& start);
	float ComputeShadowSample(const Vec3& start, const Vec3& end);

	Vec4 ComputeColor_Omni(FTEIntersection::IntersectionResult& inters, RT_Renderer::RenderData& data);

	typedef Vec4(RT_Light::*pRenderFN)(FTEIntersection::IntersectionResult&, RT_Renderer::RenderData&);

	pRenderFN mRenderFN;
	static std::vector<std::thread> mThreads;
};