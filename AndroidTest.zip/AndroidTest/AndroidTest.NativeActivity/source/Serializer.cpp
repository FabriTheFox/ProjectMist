#include "Serializer.h"
#include "FoxTracerEngine.h"
#include "SceneSystem.h"
#include "Component.h"
#include "FTESystems.h"

Serializer::Serializer() : mProperties(SceneSystem::GetProperties()) { RegisterBasicTypes(); }

void Serializer::SaveConfigFile()
{
	std::ofstream file("config.cfg");
	if (file.is_open())
	{
		for (auto& sys : FoxTracerEngine::Systems_)
		{
			auto& cfg = sys.second->GetConfiguration();

			if (!cfg.mVariables.empty())
			{
				if (sys.first == typeid(RayTracerSystem).hash_code())
					file << "RayTracer:" << std::endl;

				for (auto& var : cfg.mVariables)
				{
					std::string str = "\t" + var.first;
					WriteBasic(var.second.mType, str, var.second.mData);
					file << str << std::endl;
				}
			}
		}
	}
}

void Serializer::SaveScene(const std::string& name)
{
	std::ofstream file(name);
	if (file.is_open())
	{
		auto v = FoxTracerEngine::GetSystem<EntitySystem>().GetAllEntities();
		for (auto& sp : v)
			WriteEntity(file, sp);
	}
}

void Serializer::WriteEntity(std::ofstream& file, SHD_PTR<Entity> entity)
{
	auto& entprop = mProperties[typeid(Entity).name()];

	file << typeid(Entity).name() << std::endl;
	file << "{" << std::endl;
	for (auto& p : entprop)
		WriteProperty(file, entity.get(), p.second, 1);
	file << "\t:Components:" << std::endl;
	file << "\t{" << std::endl;
	for (auto& c : entity->GetComponents())
		WriteComponent(file, c.second->GetRTTI(), entity, 2);
	file << "\t}" << std::endl;
	file << "}" << std::endl;
}

void Serializer::WriteComponent(std::ofstream& file, RTTI& type, SHD_PTR<Entity> entity, unsigned tabs)
{
	auto& entprop = mProperties[type.mTypename];
	std::string tabz;
	WriteTabs(tabz, tabs);

	file << tabz << type.mTypename << std::endl;
	file << tabz << "{" << std::endl;
	for (auto& p : entprop)
		WriteProperty(file, entity->GetComponent(type.mTypehash).get(), p.second, tabs + 1);
	file << tabz << "}" << std::endl;
}

void Serializer::WriteProperty(std::ofstream& file, void* parent, SHD_PTR<IProperty> prop, unsigned tabs)
{
	std::string line;
	WriteTabs(line, tabs);

	line += prop->mName;
	if (!WriteBasic(prop->mClassType, line, prop->GetPtr(parent)))
	{
		file << line << std::endl;

		std::string tab;
		WriteTabs(tab, tabs);

		file << tab << "{" << std::endl;
		void* par = prop->GetPtr(parent);
		for (auto& p : mProperties[prop->mClassName])
			WriteProperty(file, par, p.second, tabs + 1);
		file << tab << "}" << std::endl;
	}
	else
		file << line << std::endl;
}

bool Serializer::WriteBasic(size_t hash, std::string& str, void* data)
{
	auto itr = mBasicTypes.find(hash);
	if (itr == mBasicTypes.end())
		return false;

	str += " = ";
	std::vector<float> f;
	if (hash == typeid(int).hash_code())
	{
		str += std::to_string(*((int*)(data)));
	}
	else if (hash == typeid(std::string).hash_code())
	{
		str += *((std::string*)(data));
	}
	else if (hash == typeid(float).hash_code())
	{
		str += std::to_string(*((float*)(data)));
	}
	else if (hash == typeid(unsigned).hash_code())
	{
		str += std::to_string(*((unsigned*)(data)));
	}
	else if (hash == typeid(double).hash_code())
	{
		str += std::to_string(*((double*)(data)));
	}
	else if (hash == typeid(bool).hash_code())
	{
		if (*((bool*)(data)) == true)
			str += "true";
		else
			str += "false";
	}
	else if (hash == typeid(IVec2).hash_code())
	{
		IVec2 v = *((IVec2*)(data));
		std::vector<int> f{ v.x, v.t};
		WriteVectorInt(str, f);
	}
	else if (hash == typeid(Vec3).hash_code())
	{
		Vec3 v = *((Vec3*)(data));
		std::vector<float> f{ v.x, v.t, v.z };
		WriteVector(str, f);
	}
	else if (hash == typeid(Vec4).hash_code())
	{
		Vec4 v = *((Vec4*)(data));
		std::vector<float> f{ v.x, v.t, v.z, v.w };
		WriteVector(str, f);
	}
	else if (hash == typeid(std::vector<float>).hash_code())
	{
		WriteVector(str, *((std::vector<float>*)(data)));
	}
	return true;
}

void Serializer::WriteVector(std::string& str, std::vector<float>& f)
{
	str += "[";
	for (unsigned i = 0; i < f.size(); ++i)
	{
		str += std::to_string(f[i]);
		if (i + 1 < f.size())
			str += ", ";
	}
	str += "]";
}

void Serializer::WriteVectorInt(std::string& str, std::vector<int>& f)
{
	str += "[";
	for (unsigned i = 0; i < f.size(); ++i)
	{
		str += std::to_string(f[i]);
		if (i + 1 < f.size())
			str += ", ";
	}
	str += "]";
}

void Serializer::WriteTabs(std::string& str, unsigned num)
{
	for (unsigned i = 0; i < num; ++i)
		str += "\t";
}

void Serializer::RegisterBasicTypes()
{
	RegisterBasicType<int>();
	RegisterBasicType<float>();
	RegisterBasicType<unsigned>();
	RegisterBasicType<double>();
	RegisterBasicType<bool>();
	RegisterBasicType<std::string>();
	RegisterBasicType<IVec2>();
	RegisterBasicType<Vec3>();
	RegisterBasicType<Vec4>();
	RegisterBasicType<std::vector<float>>();
}