#include "GraphicSystem.h"
#include "OpenGLHeaders.h"
#include "ImGUIHeaders.h"
#include "FoxTracerEngine.h"
#include "EditorSystem.h"
#include "Light.h"
#include "RTTI_imp.h"

RTTI_IMPLEMENTATION(GraphicSystem);

void GraphicSystem::Initialize() 
{
	
}

void GraphicSystem::Shutdown()
{
	for (auto& layer : mLayers)
		layer.Shutdown();
}

void GraphicSystem::Update()
{
	gl::DepthMask(1);
	gl::DepthFunc(gl::LESS);

	gl::ClearColor(0.1f, 0.1f, 0.1f, 0.1f);
	gl::Clear(gl::COLOR_BUFFER_BIT | gl::DEPTH_BUFFER_BIT | gl::STENCIL_BUFFER_BIT);

	FoxTracerEngine::GetSystem<EditorSystem>().SetGameViewPort();

	gl::Enable(gl::BLEND);
	gl::BlendFunc(gl::SRC_ALPHA, gl::ONE_MINUS_SRC_ALPHA);

	RenderAllLayers();
}

void GraphicSystem::ShowDebug()
{
	static bool open = false;
	if (ImGui::BeginMenu("| Layers |"))
	{
		open = true;
		ImGui::EndMenu();
	}
	if (open)
		ShowGUIWindow(open);

	for (auto& l : mLayers)
	{
		for (auto& r : l.mRenderers)
		{
			for (auto ren : r.second->GetRenderables().AlivePtrs_)
			{
				auto lc = ren->GetOwner().GetComponent<OmniLight>();
				if (lc)
					ren->SetModulationColor(Vec4(lc->mDiffuse, 1));
			}
		}	
	}
}

void GraphicSystem::ShowGUIWindow(bool& open)
{
	ImGui::SetNextWindowPos(ImVec2(200, 200), ImGuiSetCond_Once);
	ImGui::Begin("| Graphic System |", &open, ImGuiWindowFlags_AlwaysAutoResize);

	for (auto& layer : mLayers)
	{
		layer.ShowGUI();
		ImGui::Separator();
	}

	ImGui::End();
}

void GraphicSystem::CreateLayer(const std::string& name)
{
	mLayers.emplace_back(name);
}

Layer& GraphicSystem::GetLayer(const std::string name)
{
	for (auto& l : mLayers)
		if (l.GetName() == name)
			return l;
	return mLayers.back();
}

void GraphicSystem::RenderAllLayers()
{
	for (auto& layer : mLayers)
		layer.Render();
}