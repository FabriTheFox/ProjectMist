#pragma once

#include "Intersection.h"
#include "DataTypes.h"
#include "Transform.h"
#include "KDTree.h"

class RT_Renderable
{
public:
	FTEIntersection::IntersectionResult TraceRay(const Vec3& start, const Vec3& dir) { return (this->*mTraceFunction)(start, dir); }

	FTEIntersection::IntersectionResult TraceRay_Sphere(const Vec3& start, const Vec3& dir);
	FTEIntersection::IntersectionResult TraceRay_Ellipsoid(const Vec3& start, const Vec3& dir);
	FTEIntersection::IntersectionResult TraceRay_AACube(const Vec3& start, const Vec3& dir);
	FTEIntersection::IntersectionResult TraceRay_OCube(const Vec3& start, const Vec3& dir);
	FTEIntersection::IntersectionResult TraceRay_Mesh(const Vec3& start, const Vec3& dir);

	typedef FTEIntersection::IntersectionResult(RT_Renderable::*TraceFN)(const Vec3& start, const Vec3& dir);
	TraceFN mTraceFunction;

	Transform mTransform;
	Mat4 mWorldToModel;

	Vec4 mModulationColor{ 1, 1, 1, 1 };

	std::vector<FTEIntersection::Triangle> mWorldTriangles;
	KDTree* mKDTree{nullptr};

	bool mCastsShadow;
	bool mVisible;
};