#include "Asset.h"
#include "Utilities.h"
#include "AssetSystem.h"

void Asset::InternalLoad()
{
	if (mPath.empty())
		return;

	auto paths = Utilities::GetIndividualPaths(mPath);

	time_t recent = 0;
	for (auto& p : paths)
	{
		auto t = Utilities::GetFileWritingTime(p);
		if (t > recent)
			recent = t;
	}

	if (mLastReadingTime < recent)
	{
		FoxTracerEngine::GetSystem<AssetSystem>().LoadAsset(mPath, mName);
		mLastReadingTime = recent;
	}
}

void Asset::ReloadAsset()
{
	InternalLoad();
}