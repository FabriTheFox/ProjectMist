#include "FrameRateController.h"
#include "SDL\SDL_video.h"		
#include "SDL\SDL_timer.h"
#include "RTTI_imp.h"

RTTI_IMPLEMENTATION(FrameRateController)

void FrameRateController::Initialize() {}

void FrameRateController::Update()
{
	unsigned curr_ticks = SDL_GetTicks();
	mFrameTime = (float)(curr_ticks - mLastTicks);

	if (mFrameTime > 50)
		mFrameTime = 50;

	mFrameRate = 1000.f / mFrameTime;
	mLastTicks = curr_ticks;
}

float FrameRateController::GetFrameTimeMilliseconds() { return mFrameTime * 0.001f; }
float FrameRateController::GetFrameTime() { return mFrameTime; }
float FrameRateController::GetFrameRate() { return mFrameRate; }