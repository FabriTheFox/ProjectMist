#pragma once

#include "System.h"
#include "Shader.h"
#include <unordered_map>

class Light;

class LightingSystem : public System
{
	RTTI_DECLARATION(LightingSystem)
	friend class Light;
	friend class Layer;
public:
	void Shutdown() override;
	void Update() override;
	void UploadLights(Shader& shader);
	std::unordered_map<size_t, std::vector<WK_PTR<Light>>>& GetLights();

private:
	void ShowGUIWindow(bool& open);

	std::unordered_map<size_t, std::vector<WK_PTR<Light>>> mLights;
	std::vector<float> mLightShaderData;
};