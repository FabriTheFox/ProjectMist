#pragma once

// SDL headers
#include <SDL/SDL_main.h>
#include <SDL/SDL.h>
#include <SDL/SDL_opengl.h>
