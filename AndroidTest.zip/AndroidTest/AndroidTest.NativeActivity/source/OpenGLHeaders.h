#pragma once

#include <GL\gl_core_4_4.hpp>
//#include <GL/GL.h>
//#include <GL/glu.h>
//#include <GL/glext.h>