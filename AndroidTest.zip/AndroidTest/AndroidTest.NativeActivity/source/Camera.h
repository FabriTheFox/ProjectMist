#pragma once

#include "DataTypes.h"
#include "Entity.h"
#include <vector>

class Camera : public Entity
{
	CREATE_DECLARATION(Camera)

public:
	virtual void Update();

	virtual Mat4 GetCameraMatrix();
	Mat4& GetPerspectiveMatrix();
	Mat4& GetViewportMatrix();

	void SetAspectRatio(float aspectratio);
	float GetAspectRatio();

	void SetNearPlane(float nearplane);
	float GetNearPlane();

	void SetFarPlane(float farplane);
	float GetFarPlane();

	void SetVerticalFOV(float fov);
	float GetVerticalFOV();

	void SetFocalDistance(float foc);
	float GetFocalDistance();

	void SetTarget(const Vec3& tar);
	const Vec3& GetTarget();
	const Vec3 GetViewVector();
	const Vec3 GetRightVector();

	void SetUpVector(const Vec3& up);
	const Vec3& GetUpVector();
	Vec3 ComputeRealUpVector();

	std::vector<Vec3> GetProjectionPlane();

	void ShowGUI();

protected:
	void UpdateMatrices();
	virtual void ComputeCameraMatrix();
	void ComputePerspectiveMatrix();
	void ComputeViewportMatrix();

	Mat4 mCameraMatrix;
	Mat4 mPerspectiveMatrix;
	Mat4 mViewportMatrix;
	Vec3 mTarget{0, 0, -1};
	Vec3 mUp{0, 1, 0};

	float mAspectRatio{16.f/9.f};
	float mNearPlane{0.1f};
	float mFarPlane{500.f};
	float mFOV_V{45.f};
	float mFocalDistance{3.f};
};

class ArcballCamera : public Camera
{
	CREATE_DECLARATION(ArcballCamera)
public:
	void Update() override;

	void SetRadius(float radius);
	const float& GetRadius();

//private:
	float mRadius{ 5 };
	float mMoveSpeed{1};

	float mAngle_X{90};
	float mAngle_Y{0};
};