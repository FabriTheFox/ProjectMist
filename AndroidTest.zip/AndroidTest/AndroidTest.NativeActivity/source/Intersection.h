#pragma once

#include "DataTypes.h"
#include <vector>

class Renderable;
class RT_Renderable;

namespace FTEIntersection
{
	struct IntersectionResult
	{
		IntersectionResult(Vec3 point = { 0, 0, 0 }, float dis = FLT_MAX, Vec3 normal = {}, bool backface = false) :
			mIntersectionPoint(point), mDis(dis), mNormal(normal), mIsBackFace(backface) {}
		bool HasCollided() { return mDis < FLT_MAX; }

		Vec3 mIntersectionPoint;
		Vec3 mOriginPoint;
		Vec3 mNormal;
		float mDis{ FLT_MAX };
		bool mIsBackFace{false};
	};

	struct Triangle
	{
		Vec3 mVertices[3];
		Vec3 mNormals[3];
		Vec3 mN;

		Triangle(const Vec3& a, const Vec3& b, const Vec3& c) {
			mVertices[0] = a; mVertices[1] = b; mVertices[2] = c; }

		bool IsPointInside(const Vec3& p);
		IntersectionResult TraceRay(const Vec3& lineorig, const Vec3& linedir);
		bool TraceRay_Test(const Vec3& lineorig, const Vec3& linedir);
		void ComputeNormal();

		float GetMinValOnAxis(unsigned axis) const;
		float GetMaxValOnAxis(unsigned axis) const;
	};

	// Ray - Sphere
	IntersectionResult Ray_UnitarySphereOrigin(const Vec3& lineorig, const Vec3& linedir);
	IntersectionResult Ray_Sphere(const Vec3& sphcenter, float radius, const Vec3& lineorig, const Vec3& linedir);
	IntersectionResult Ray_Ellipsoid(const Mat4& worldtomodel, const Vec3& lineorig, const Vec3& linedir);

	// Ray - Plane
	IntersectionResult Ray_InfinitePlane(const Vec3& planepoint, const Vec3& normal, const Vec3& lineorig, const Vec3& linedir);

	// Ray - AABB
	bool Ray_AABB_Test(const Vec3& center, const Vec3& scale, const Vec3& lineorig, const Vec3& linedir);
	IntersectionResult Ray_AACubeOrigin(const Vec3& lineorig, const Vec3& linedir);
	IntersectionResult Ray_AABB(const Vec3& center, const Vec3& scale, const Vec3& lineorig, const Vec3& linedir);
	IntersectionResult Ray_OBB(const Mat4& worldtomodel, const Vec3& lineorig, const Vec3& linedir);

	Vec3 Refract(const Vec3& i, const Vec3& n, float eta);
}