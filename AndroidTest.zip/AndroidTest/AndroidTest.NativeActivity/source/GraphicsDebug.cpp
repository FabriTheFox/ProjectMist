#include "GraphicsDebug.h"

namespace GFX {

	void APIENTRY glDebugOutput(GLenum source, GLenum type, GLuint id, GLenum severity,
		GLsizei length, const GLchar *message, void *userParam)
	{
		(void)(userParam);
		(void)(length);

		if (id == 131169 || id == 131185 || id == 131218 || id == 131204) return;

		std::cout << "---------------" << std::endl;
		std::cout << "Debug message (" << id << "): " << message << std::endl;

		switch (source)
		{
		case gl::DEBUG_SOURCE_API:             std::cout << "Source: API"; break;
		case gl::DEBUG_SOURCE_WINDOW_SYSTEM:   std::cout << "Source: Window System"; break;
		case gl::DEBUG_SOURCE_SHADER_COMPILER: std::cout << "Source: Shader Compiler"; break;
		case gl::DEBUG_SOURCE_THIRD_PARTY:     std::cout << "Source: Third Party"; break;
		case gl::DEBUG_SOURCE_APPLICATION:     std::cout << "Source: Application"; break;
		case gl::DEBUG_SOURCE_OTHER:           std::cout << "Source: Other"; break;
		} std::cout << std::endl;

		switch (type)
		{
		case gl::DEBUG_TYPE_ERROR:               std::cout << "Type: Error"; break;
		case gl::DEBUG_TYPE_DEPRECATED_BEHAVIOR: std::cout << "Type: Deprecated Behaviour"; break;
		case gl::DEBUG_TYPE_UNDEFINED_BEHAVIOR:  std::cout << "Type: Undefined Behaviour"; break;
		case gl::DEBUG_TYPE_PORTABILITY:         std::cout << "Type: Portability"; break;
		case gl::DEBUG_TYPE_PERFORMANCE:         std::cout << "Type: Performance"; break;
		case gl::DEBUG_TYPE_MARKER:              std::cout << "Type: Marker"; break;
		case gl::DEBUG_TYPE_PUSH_GROUP:          std::cout << "Type: Push Group"; break;
		case gl::DEBUG_TYPE_POP_GROUP:           std::cout << "Type: Pop Group"; break;
		case gl::DEBUG_TYPE_OTHER:               std::cout << "Type: Other"; break;
		} std::cout << std::endl;

		switch (severity)
		{
		case gl::DEBUG_SEVERITY_HIGH:         std::cout << "Severity: high"; break;
		case gl::DEBUG_SEVERITY_MEDIUM:       std::cout << "Severity: medium"; break;
		case gl::DEBUG_SEVERITY_LOW:          std::cout << "Severity: low"; break;
		case gl::DEBUG_SEVERITY_NOTIFICATION: std::cout << "Severity: notification"; break;
		} std::cout << std::endl;
		std::cout << std::endl;
	}

	bool PrintOpenGLError(GLenum error, const char * function)
	{
		if (error == gl::NO_ERROR_)
			return false;

		const char * error_as_str = nullptr;

#define CASE_OGL_ERROR(e)	\
case e:	{	error_as_str = #e; } break

		switch (error)
		{
			CASE_OGL_ERROR(gl::INVALID_ENUM);
			CASE_OGL_ERROR(gl::INVALID_VALUE);
			CASE_OGL_ERROR(gl::INVALID_OPERATION);
			CASE_OGL_ERROR(gl::INVALID_FRAMEBUFFER_OPERATION);
			CASE_OGL_ERROR(gl::OUT_OF_MEMORY);
			CASE_OGL_ERROR(gl::STACK_OVERFLOW);
			CASE_OGL_ERROR(gl::STACK_UNDERFLOW);

		case gl::NO_ERROR_:	break;
		default:
		{
			error_as_str = "UNKOWN ERROR";
		} break;
		}
#undef CASE_OGL_ERROR

		std::cout << function << ": OpenGL error \"" << error_as_str << "\"" << std::endl;

#if 0
		return error != 0;
#else
		return false;
#endif
	}
}