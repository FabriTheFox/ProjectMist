#include "Importer_Texture.h"
#include "AssetSystem.h"
#include "Texture.h"

#include <stb_image\stb_image.h>

void Importer_Texture::Import(const std::string& name, const std::string& path)
{
	auto& sys = FoxTracerEngine::GetSystem<AssetSystem>();
	auto& asset = sys.RegisterAsset<Texture>(name);

	asset.mPath = path;
	asset.mName = name;

	int channels;
	IVec2 size;
	unsigned char* data = stbi_load(path.c_str(), &size.x, &size.y, &channels, STBI_rgb_alpha);

	asset.Load(data, size.x, size.y);
	stbi_image_free(data);
}