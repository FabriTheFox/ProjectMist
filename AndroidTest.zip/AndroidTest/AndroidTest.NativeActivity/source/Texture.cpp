#include "Texture.h"
#include "OpenGLHeaders.h"
#include "Utilities.h"
#include "DebugSystem.h"
#include "RTTI_imp.h"
#include <vector>

#define STB_IMAGE_WRITE_IMPLEMENTATION
#include <stb_image\stb_image.h>
#include <stb_image\stb_image_write.h>

ASSET_IMPLEMENTATION(Texture)

void Texture::Bind(int binding)
{
	gl::ActiveTexture(gl::TEXTURE0 + binding);
	gl::BindTexture(gl::TEXTURE_2D, mIndex);
}

void Texture::Free()
{
	if (mIndex != 0)
		gl::DeleteTextures(1, &mIndex);
}

void Texture::Load(unsigned char * pixels, unsigned w, unsigned h)
{
	Free();

	gl::GenTextures(1, &mIndex);
	mTextureSize = { w, h };

	Bind(0);

	gl::TexParameteri(gl::TEXTURE_2D, gl::TEXTURE_MIN_FILTER, gl::NEAREST);
	gl::TexParameteri(gl::TEXTURE_2D, gl::TEXTURE_MAG_FILTER, gl::NEAREST);
	gl::TexParameteri(gl::TEXTURE_2D, gl::TEXTURE_WRAP_S, gl::REPEAT);
	gl::TexParameteri(gl::TEXTURE_2D, gl::TEXTURE_WRAP_T, gl::REPEAT);

	gl::TexImage2D(gl::TEXTURE_2D, 0, gl::RGBA, w, h, 0, gl::RGBA, gl::UNSIGNED_BYTE, pixels);
	//gl::GenerateMipmap(gl::TEXTURE_2D);
}

const IVec2& Texture::GetTextureSize()
{
	return mTextureSize;
}

const unsigned& Texture::GetIndex()
{
	return mIndex;
}

void Texture::SaveToFile(std::string& name)
{
	Bind();

	int w = mTextureSize.x;
	int h = mTextureSize.y;

	std::vector<unsigned char> image_data(w * h * 3);
	gl::GetTexImage(gl::TEXTURE_2D, 0, gl::RGB, gl::UNSIGNED_BYTE, image_data.data());
	std::vector<unsigned char> flipped_data(image_data.size());

	for (int y = 0; y < h; ++y)
	{
		for (int x = 0; x < w * 3; x += 3)
		{
			flipped_data[y * w * 3 + x + 0] = image_data[(h - 1 - y) * w * 3 + x + 0];
			flipped_data[y * w * 3 + x + 1] = image_data[(h - 1 - y) * w * 3 + x + 1];
			flipped_data[y * w * 3 + x + 2] = image_data[(h - 1 - y) * w * 3 + x + 2];
		}
	}

	Utilities::RemoveCharFromString(name, ':');
	Utilities::RemoveCharFromString(name, ' ');
	name += ".png";

	const unsigned bytes = w * 3;
	if (stbi_write_png(name.c_str(), w, h, 3, image_data.data(), bytes) == 0)
		PRINT_WARNING << "Error trying to save texture" << std::endl;
}