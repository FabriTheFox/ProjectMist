#include "FoxTracerEngine.h"
#include "SDLHeaders.h"
#include "ImGUIHeaders.h"
#include <map>

#include "FTESystems.h"
#include "FTEComponents.h"

	struct Level
	{
		GlobalFP mInit;
		GlobalFP mRun;
		GlobalFP mTerminate;
		std::string mName;
	};

	bool Quit_ = false;
	std::map<std::string, Level> Levels_;
	Level* CurrentLevel_ = nullptr;

	std::map<size_t, SHD_PTR<System>> FoxTracerEngine::Systems_;
	std::vector<SHD_PTR<System>> FoxTracerEngine::SystemVec_;

	DisplayModule FoxTracerEngine::Display_;

	void FoxTracerEngine::Initialize()
	{
		RegisterSystemOrdered<InputSystem>();
		RegisterSystemOrdered<AssetSystem>();
		RegisterSystemOrdered<EntitySystem>();
		RegisterSystemOrdered<RayTracerSystem>();
		RegisterSystemOrdered<GraphicSystem>();
		RegisterSystemOrdered<FrameRateController>();
		RegisterSystemOrdered<SceneSystem>();
		RegisterSystemOrdered<EditorSystem>();
		RegisterSystemOrdered<DebugSystem>();

		Display_.Initialize();

		for (auto& sys : SystemVec_)
			sys->Initialize();
	}

	void FoxTracerEngine::Run()
	{
		SDL_Event sdlEvent;

		while (!Quit_)
		{
			GetSystem<InputSystem>().StartOfFrame();

			while (SDL_PollEvent(&sdlEvent))
			{
				ImGui_ImplSdlGL3_ProcessEvent(&sdlEvent);
				GetSystem<InputSystem>().ProcessSDLEvent(&sdlEvent);

				if (sdlEvent.quit.type == SDL_QUIT)
					Quit_ = true;
			}

			GetSystem<SceneSystem>().LoadSystemConfigs();

			ImGui_ImplSdlGL3_NewFrame((SDL_Window*)FoxTracerEngine::Display_.GetWindow());

			FoxTracerEngine::UpdateAllSystems();
			FoxTracerEngine::UpdateCurrentLevel();

			if (GetSystem<InputSystem>().KeyTriggered(SDL_SCANCODE_ESCAPE))
				Quit_ = true;

			GetSystem<SceneSystem>().SaveSystemConfigs();

			if (ImGui::IsMouseHoveringAnyWindow())
				GetSystem<InputSystem>().EnableInput(false);
			else
				GetSystem<InputSystem>().EnableInput(true);

			ImGui::Render();
			Display_.SwapWindow();
		}

		Display_.Terminate();

		ShutdownAllSystems();
		Clean();
	}

	void FoxTracerEngine::ShutdownAllSystems()
	{
		for (auto& sys : SystemVec_)
			sys->Shutdown();
	}

	void FoxTracerEngine::UpdateCurrentLevel()
	{
		if (!CurrentLevel_)
			PRINT_ERROR << "No level loaded" << std::endl;
		else
			CurrentLevel_->mRun();
	}

	void FoxTracerEngine::UpdateAllSystems()
	{
		for (auto& sys : SystemVec_)
			sys->UpdateSystem();
	}

	void FoxTracerEngine::UpdateDebugOfAllSystems()
	{
		if (ImGui::BeginMainMenuBar())
		{
			for (auto& sys : SystemVec_)
				sys->ShowDebug();

			ImGui::EndMainMenuBar();
		}
	}

	void FoxTracerEngine::Clean()
	{
		SystemVec_.clear();
		Systems_.clear();
	}

	void FoxTracerEngine::Terminate()
	{
		Quit_ = true;
	}

	void FoxTracerEngine::AddLevel(const std::string& name, GlobalFP init, GlobalFP run, GlobalFP terminate)
	{
		if (Levels_.find(name) != Levels_.end())
		{
			PRINT_ERROR << "Trying to add a duplicated level" << std::endl;
			return;
		}
		Levels_[name] = { init, run, terminate, name };
	}

	void FoxTracerEngine::SetLevel(const std::string& name)
	{
		if (Levels_.find(name) == Levels_.end())
		{
			PRINT_ERROR << "Trying to execute a non-existent level" << std::endl;
			return;
		}

		if (CurrentLevel_ && CurrentLevel_->mName == name)
			return;

		if (CurrentLevel_ && CurrentLevel_->mTerminate)
			CurrentLevel_->mTerminate();
		CurrentLevel_ = &Levels_.at(name);
		if (CurrentLevel_->mInit)
			CurrentLevel_->mInit();
	}

	std::unordered_map<std::string, RTTI>& FoxTracerEngine::GetRTTIs()
	{
		static std::unordered_map<std::string, RTTI> rtti;
		return rtti;
	}

	std::vector<GlobalFP>& FoxTracerEngine::GetRegisterPropertyFunctions()
	{
		static std::vector<GlobalFP> funs;
		return funs;
	}