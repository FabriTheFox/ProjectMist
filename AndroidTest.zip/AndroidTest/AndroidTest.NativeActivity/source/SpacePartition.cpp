#include "SpacePartition.h"

AABB::AABB(const std::vector<Vec3>& points)
{
	if (points.empty())
		return;

	Vec3 max = points.front();
	Vec3 min = points.front();

	for (auto& p : points)
	{
		for (unsigned i = 0; i < 3; ++i)
		{
			if (p[i] > max[i])
				max[i] = p[i];
			if (p[i] < min[i])
				min[i] = p[i];
		}
	}

	mCenter = (min + max) / 2.f;
	mExtent = (max - min) / 2.f;
}

AABB::AABB(const std::vector<FTEIntersection::Triangle>& triangles)
{
	if (triangles.empty())
		return;

	Vec3 max = { -FLT_MAX, -FLT_MAX, -FLT_MAX };
	Vec3 min = { FLT_MAX, FLT_MAX, FLT_MAX };

	for (auto& t : triangles)
	{
		for (unsigned i = 0; i < 3; ++i)
		{
			auto& p = t.mVertices[i];
			for (unsigned j = 0; j < 3; ++j)
			{
				if (p[j] > max[j])
					max[j] = p[j];
				if (p[j] < min[j])
					min[j] = p[j];
			}
		}
	}

	mCenter = (min + max) / 2.f;
	mExtent = (max - min) / 2.f;
}

void AABB::MakeItCube()
{
	float ex = mExtent.x;
	if (mExtent.y > ex)
		ex = mExtent.y;
	if (mExtent.z > ex)
		ex = mExtent.z;
	mExtent = Vec3{ ex };
}

bool AABB::IsPointInside(const Vec3& point)
{
	if (point.x > mCenter.x + mExtent.x ||
		point.x < mCenter.x - mExtent.x ||
		point.y > mCenter.y + mExtent.y ||
		point.y < mCenter.y - mExtent.y ||
		point.z > mCenter.z + mExtent.z ||
		point.z < mCenter.z - mExtent.z)
		return false;
	return true;
}

bool AABB::IsSphereInside(const Vec3& c, float radius)
{
	if (!IsPointInside(c))
		return false;
	if (+(mCenter.x + mExtent.x) - c.x < radius || 
		-(mCenter.x - mExtent.x) - c.x < radius ||
		+(mCenter.y + mExtent.y) - c.y < radius ||
		-(mCenter.y - mExtent.y) - c.y < radius ||
		+(mCenter.z + mExtent.z) - c.z < radius ||
		-(mCenter.z - mExtent.z) - c.z < radius)
		return false;
	return true;
}

bool AABB::IsCollidingWithAABB(const AABB& bb)
{
	auto min = mCenter - mExtent;
	auto max = mCenter + mExtent;

	auto othermin = bb.mCenter - bb.mExtent;
	auto othermax = bb.mCenter + bb.mExtent;

	if (min.x > othermax.x ||
		min.y > othermax.y ||
		min.z > othermax.z ||
		max.x < othermin.x ||
		max.y < othermin.y ||
		max.z < othermin.z)
		return false;
	return true;
}

std::vector<AABB> AABB::SplitByAAPlane(const Vec2& aaplane)
{
	std::vector<AABB> cubes(2);

	// Left BB
	Vec3 left_min = mCenter - mExtent;
	Vec3 left_max = (mCenter + mExtent);
	left_max[(int)(aaplane.x)] = aaplane.y;

	cubes[0].mCenter = (left_min + left_max) / 2.f;
	cubes[0].mExtent = (left_max - left_min) / 2.f;

	// Right BB
	Vec3 right_min = left_min;
	right_min[(int)(aaplane.x)] = aaplane.y;
	Vec3 right_max = (mCenter + mExtent);

	cubes[1].mCenter = (right_min + right_max) / 2.f;
	cubes[1].mExtent = (right_max - right_min) / 2.f;

	return cubes;
}

float AABB::GetArea()
{
	return 8 * glm::dot(mExtent, mExtent);
}

float AABB::GetSurfaceArea()
{
	Vec3 dim = 2.f * mExtent;
	return 2 * (dim.x * dim.y + dim.y * dim.z + dim.x * dim.z);
}