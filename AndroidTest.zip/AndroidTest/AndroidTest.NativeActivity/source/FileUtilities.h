#pragma once

#include <string>

namespace FileUtilities
{
	std::string SelectFile();
}