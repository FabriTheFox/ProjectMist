#include "EntitySpace.h"
#include "DebugSystem.h"

#include "ImGUIHeaders.h"

const std::string& EntitySpace::GetName() { return mName; }
void EntitySpace::SetName(const std::string& name) { mName = name; }

std::vector<SHD_PTR<Entity>>& EntitySpace::GetEntities()
{
	return mEntities.AlivePtrs_;
}

void EntitySpace::GetAllEntities(std::vector<SHD_PTR<Entity>>& vec)
{
	for (auto& e : mEntities.AlivePtrs_)
		vec.push_back(e);
	for (auto& c : mChildren.AlivePtrs_)
		c->GetAllEntities(vec);
}

EntitySpace& EntitySpace::GetChildSpace(const std::string& name)
{
	for (auto& c : mChildren.AlivePtrs_)
		if (c->GetName() == name)
			return *c;

	mChildren.AlivePtrs_.emplace_back(std::make_shared<EntitySpace>());
	mChildren.AlivePtrs_.back()->SetName(name);
	return *mChildren.AlivePtrs_.back();
}

Entity& EntitySpace::GetEntity(const std::string& name)
{
	auto pt = GetEntityPtr(name);
	if (!pt)
		ASSERT << "ENTITY NOT FOUND";
	return *GetEntityPtr(name);
}

SHD_PTR<Entity> EntitySpace::GetEntityPtr(const std::string& name)
{
	for (auto e : mEntities.AlivePtrs_)
		if (e->GetName() == name)
			return e;
	return nullptr;
}