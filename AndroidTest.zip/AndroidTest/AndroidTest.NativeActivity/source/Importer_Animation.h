#pragma once

#include "Importer.h"

class Importer_Animation : public Importer
{
public:
	IMPORTER_DECLARATION(Importer_Animation)
	void Import(const std::string& name, const std::string& path) override;
	void LoadFBXAnimation(void* stack, void* scene, Asset* asset);
private:
};