#include "RenderCommand.h"
#include "OpenGLHeaders.h"
#include "DebugSystem.h"

#include "GraphicsDebug.h"

RenderConfig::RenderConfig(bool depthtest, bool depthwrite, bool wireframe) :
	mDepthTest(depthtest),
	mDepthWriting(depthwrite),
	mWireframe(wireframe)
{}

void RenderConfig::ApplyConfig()
{
	EnableDepthTest(mDepthTest);
	EnableDepthWrite(mDepthWriting);
	EnableWireFrame(mWireframe);
}

void RenderConfig::EnableDepthTest(bool enable)
{
	if (enable)
		gl::Enable(gl::DEPTH_TEST);
	else
		gl::Disable(gl::DEPTH_TEST);
}

void RenderConfig::EnableDepthWrite(bool enable)
{
	if (enable)
		gl::DepthMask(1);
	else
		gl::DepthMask(0);
}

void RenderConfig::EnableWireFrame(bool enable)
{
	if (enable)
		gl::PolygonMode(gl::FRONT_AND_BACK, gl::LINE);
	else
		gl::PolygonMode(gl::FRONT_AND_BACK, gl::FILL);
}

RenderCommand::RenderCommand(WK_PTR<Shader> sh, WK_PTR<Model> model, RenderConfig renderconfig) :
	mpShader(sh),
	mpModel(model),
	mRenderConfig(renderconfig) 
{}

void RenderCommand::ApplyConfig()
{
	mRenderConfig.ApplyConfig();
}

void RenderCommand::Render(unsigned mode, SHD_PTR<Model> mod)
{
	if (!HasShader_Warning()) {
		PRINT_WARNING << "Attempted to render without shader" << std::endl;
		return; }

	if (mod) {
		mod->Draw(mode);
		return; }

	if (!HasModel_Warning()) {
		PRINT_WARNING << "Attempted to render without model" << std::endl;
		return; }

	mpModel.lock()->Draw(mode);
}

void RenderCommand::Render(unsigned mode, Model& mod)
{
	if (!HasShader_Warning()) {
		PRINT_WARNING << "Attempted to render without shader" << std::endl;
		return;
	}

	mod.Draw(mode);
}

void RenderCommand::RenderInstanced(unsigned count, SHD_PTR<Model> mod)
{
	if (!HasShader_Warning()) {
		PRINT_WARNING << "Attempted to render without shader" << std::endl;
		return; }

	if (mod) {
		mod->DrawInstanced(count);
		return; }

	if (!HasModel_Warning()) {
		PRINT_WARNING << "Attempted to render without model" << std::endl;
		return; }

	mpModel.lock()->DrawInstanced(count);
}

void RenderCommand::EnableDepthTest(bool enable) { mRenderConfig.mDepthTest = enable; }
void RenderCommand::EnableDepthWriting(bool enable) { mRenderConfig.mDepthWriting = enable; }
void RenderCommand::EnableWireFrame(bool enable) { mRenderConfig.mWireframe = enable; }

bool RenderCommand::HasShader() { return mpShader.lock() && !mpShader.expired(); }
bool RenderCommand::HasModel() { return mpModel.lock() && !mpModel.expired(); }

bool RenderCommand::HasShader_Warning() { auto b = HasShader(); if (!b) PRINT_WARNING << "Render command has no shader" << std::endl; return b; }
bool RenderCommand::HasModel_Warning() { auto b = HasModel(); if (!b) PRINT_WARNING << "Render command has no model" << std::endl; return b; }

void RenderCommand::SetRenderConfig(const RenderConfig& config) { mRenderConfig = config; }
void RenderCommand::SetModel(WK_PTR<Model> model) { mpModel = model; }
void RenderCommand::SetShader(WK_PTR<Shader> sh) { mpShader = sh; }

RenderConfig& RenderCommand::GetRenderConfig() { return mRenderConfig; }
WK_PTR<Model>& RenderCommand::GetModel() { return mpModel; }
WK_PTR<Shader>& RenderCommand::GetShader() { return mpShader; }

void RenderCommand::SetUniformfloat(const std::string& name, float data) { if (!HasShader_Warning()) return; mpShader.lock()->SetUniformfloat(name, data); }
void RenderCommand::SetUniformfloatVec(const std::string& name, float* data, unsigned count) { if (!HasShader_Warning()) return; mpShader.lock()->SetUniformfloatVec(name, data, count); };
void RenderCommand::SetUniformInt(const std::string& name, int data) { if (!HasShader_Warning()) return; mpShader.lock()->SetUniformInt(name, data); }
void RenderCommand::SetUniformIntVec(const std::string& name, int* data, unsigned count) { if (!HasShader_Warning()) return; mpShader.lock()->SetUniformIntVec(name, data, count); }
void RenderCommand::SetUniformVec2(const std::string& name, const Vec2& data) { if (!HasShader_Warning()) return; mpShader.lock()->SetUniformVec2(name, data); };
void RenderCommand::SetUniformVec2Vec(const std::string& name, Vec2* data, unsigned count) { if (!HasShader_Warning()) return; mpShader.lock()->SetUniformVec2Vec(name, data, count); }
void RenderCommand::SetUniformVec3(const std::string& name, const Vec3& data) { if (!HasShader_Warning()) return; mpShader.lock()->SetUniformVec3(name, data); };
void RenderCommand::SetUniformVec3Vec(const std::string& name, Vec3* data, unsigned count) { if (!HasShader_Warning()) return; mpShader.lock()->SetUniformVec3Vec(name, data, count); }
void RenderCommand::SetUniformVec4(const std::string& name, const Vec4& data) { if (!HasShader_Warning()) return; mpShader.lock()->SetUniformVec4(name, data); }
void RenderCommand::SetUniformVec4Vec(const std::string& name, Vec4* data, unsigned count) { if (!HasShader_Warning()) return; mpShader.lock()->SetUniformVec4Vec(name, data, count); }
void RenderCommand::SetUniformMat4(const std::string& name, const Mat4& data) { if (!HasShader_Warning()) return; mpShader.lock()->SetUniformMat4(name, data); }
void RenderCommand::SetUniformMat4Vec(const std::string& name, Mat4* data, unsigned count) { if (!HasShader_Warning()) return; mpShader.lock()->SetUniformMat4Vec(name, data, count); }