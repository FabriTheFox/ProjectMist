#pragma once

#include <string>
#include <unordered_map>
#include "DataTypes.h"

class Shader
{
public:
	Shader() = default;
	~Shader();

	void Free();

	void Bind();
	void Unbind();

	int GetUniformLocation(const std::string& name);

	void SetUniformfloat(const std::string& name, float data);
	void SetUniformfloatVec(const std::string& name, float* data, unsigned count);

	void SetUniformInt(const std::string& name, int data);
	void SetUniformIntVec(const std::string& name, int* data, unsigned count);

	void SetUniformVec2(const std::string& name, const Vec2& data);
	void SetUniformVec2Vec(const std::string& name, Vec2* data, unsigned count);

	void SetUniformVec3(const std::string& name, const Vec3& data);
	void SetUniformVec3Vec(const std::string& name, Vec3* data, unsigned count);

	void SetUniformVec4(const std::string& name, const Vec4& data);
	void SetUniformVec4Vec(const std::string& name, Vec4* data, unsigned count);

	void SetUniformMat4(const std::string& name, const Mat4& data);
	void SetUniformMat4Vec(const std::string& name, Mat4* data, unsigned count);

	const int& GetProgram();

//private:
    std::string LoadShader(const std::string& path);
	void CreateProgram(const std::string vtxshpath, const std::string frgshpath, const std::string geomshpath = "");
	int CreateShader(unsigned int shadertype, const std::string &path);

	int mProgram{-1};
	std::unordered_map<std::string, int> mUniformLocations;
};