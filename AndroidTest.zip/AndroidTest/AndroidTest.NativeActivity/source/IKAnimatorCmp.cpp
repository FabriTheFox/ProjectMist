#include "IKAnimatorCmp.h"
#include "RTTI_imp.h"
#include "FoxTracerEngine.h"
#include "AssetSystem.h"
#include "AnimatorCmp.h"
#include "GraphicSystem.h"

COMPONENT_SERIALIZABLE_IMPLEMENTATION(IKAnimatorCmp);
REGISTER_PROPERTIES(IKAnimatorCmp) {}

void IKAnimatorCmp::FindPathTo(const std::string& name, const Vec3& pos)
{
	// Check for animation existence
	mAnimationInstance = &GetOwner().GetComponent<AnimatorCmp>()->mAnimationInstance;
	if (mAnimationInstance->GetAnimation().expired())
		return;

	mTargetPos = pos;
	mEndEffector = &mAnimationInstance->GetAnimationNode(name);

	// Store the manipulator in a vector
	// We store it in ascending order of parentship, end effector goes first
	mManipulator.clear();
	IdentifyManipulator(*mEndEffector);
	mManipulator.pop_back();

	// Update the manipulator world transforms, return true if the 
	// End effector is close enough to the target
	if (UpdateManipulator())
		return;

	// Record current distance
	float dis = GetDistance();
	int iterations = 0;

	// UpdateNodeCCD returns true if it finds a solution
	while (!CCDIteration() && iterations < 100)
	{
		// Finish if the delta between distances is too small (means no solution)
		float newdis = GetDistance();
		if (std::abs(newdis - dis) < 0.1f)
			return;
		++iterations;
		dis = newdis;
	}
}

void IKAnimatorCmp::UpdatePath(float t)
{
	if (t < 0 || t > 1)
		return;

	// Interpolate the rotation of every manipulator node with SLERP
	for (auto& n : mManipulator)
		n.mAnimNode->mLocalTransform.mQ = Utilities::LERP(n.mAnimNode->mLocalTransform.mQ, n.mLocalTr.mQ, t);
}

void IKAnimatorCmp::IdentifyManipulator(AnimationInstanceNode& node)
{
	// There are two additional parent nodes that we dont want to have
	// as manipulator nodes
	if (!node.mParent->mParent)
		return;

	// Store the manipulator nodes in ascending order of parentship
	mManipulator.push_back({});
	mManipulator.back().mAnimNode = node.mParent;
	mManipulator.back().mLocalTr = node.mLocalTransform;

	IdentifyManipulator(*node.mParent);
}

bool IKAnimatorCmp::UpdateManipulator()
{
	// Parent transform is the transform of the entity owning the animation
	VQS_Transform tr = GetTransform();

	// Iterate in reverse order (descending parentship)
	// Propagate the transforms on all the children and update their world transform
	for (auto itr = mManipulator.rbegin(); itr != mManipulator.rend(); ++itr)
	{
		auto& n = *(itr);
		n.mWorldTr = n.mLocalTr;
		n.mWorldTr.Concatenate(tr);
		tr = n.mWorldTr;
	}

	// Finally, update the End effector, which is not on the manipulator vector
	mEndEffector->UpdateNodeTransform(tr);

	// If the end effector is acceptably close, return true
	if (GetDistance() < 0.01f)
		return true;
	return false;
}

bool IKAnimatorCmp::CCDIteration()
{
	// Iterate the manipulator. Ascending order.
	for (auto& n : mManipulator)
	{
		// Get the two vectors as stated on the CCD algorithm
		Vec3 VCK = glm::normalize(mEndEffector->GetWorldPos() - n.mWorldTr.mV);
		Vec3 VDK = glm::normalize(mTargetPos - n.mWorldTr.mV);

		// Check if they are valid vectors, sometimes normalizing a 0 length vector
		// gives NAN
		if (VCK != VCK || VDK != VDK)
			continue;

		// Get the angle between them
		float angle = glm::degrees(glm::acos(glm::dot(VCK, VDK)));

		if (angle == 0)
			continue;

		// Get the rotation angle (a vector perpendicular to both)
		Vec3 VK = glm::normalize(glm::cross(VCK, VDK));

		// Rotate it in a world-space vector
		auto eu = n.mLocalTr.mQ.GetEuler();
		n.mLocalTr.RotateIn(n.mAnimNode->mParent->GetWorldTransform(), VK, angle);

		// Apply constraints of the current node
		eu = n.mLocalTr.mQ.GetEuler();
		n.mAnimNode->mAnimationNode->mRotationConstraint.ApplyConstraint(eu);
		n.mLocalTr.mQ = FTEQUAT(eu);

		// Every time we move a node, we have to update the manipulator node's world transform
		// An efficiency optimization would be updating only the children of this node
		if (UpdateManipulator())
			return true;
	}
	return false;
}

float IKAnimatorCmp::GetDistance()
{
	return glm::length(mEndEffector->GetWorldPos() - mTargetPos);
}