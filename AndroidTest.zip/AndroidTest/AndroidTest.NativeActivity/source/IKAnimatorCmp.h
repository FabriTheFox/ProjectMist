#pragma once

#include "Component.h"
#include "Animation.h"
#include <string>

class Animation;

class IKAnimatorCmp :
	public Component,
	public std::enable_shared_from_this<IKAnimatorCmp>
{
	friend class Animation;
	COMPONENT_SERIALIZABLE_DECLARATION(IKAnimatorCmp)

public:
	IKAnimatorCmp() = default;

	// Tries to find a solution to move a node to a target position
	void FindPathTo(const std::string& name, const Vec3& pos);

	// Interpolates between initial animation position and the solution found
	void UpdatePath(float t);

private:
	// Stores the manipulator nodes in a vector
	void IdentifyManipulator(AnimationInstanceNode& node);

	// Performs an iteration of the CCD on all the manipulator
	bool CCDIteration();

	// Updates the world transform of the manipulator nodes
	bool UpdateManipulator();

	// Returns the distance between the end effector and the target position
	float GetDistance();

	// Definition for a manipulator node
	class ManipulatorNode
	{
	public:
		AnimationInstanceNode* mAnimNode;	// Pointer to the real animation node
		VQS_Transform mLocalTr;				// Local transform
		VQS_Transform mWorldTr;				// World transform
	};

	// We store the manipulator in a vector for efficiency and ease of use purposes
	std::vector<ManipulatorNode> mManipulator;

	// Store a pointer to the end effector
	AnimationInstanceNode* mEndEffector;

	// Pointer to the animation owned by AnimatorCmp
	AnimationInstance* mAnimationInstance;
	// Target position for the end effector
	Vec3 mTargetPos;
};