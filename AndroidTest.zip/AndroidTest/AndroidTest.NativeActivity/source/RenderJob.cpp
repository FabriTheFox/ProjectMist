#include "RenderJob.h"
#include "Cluster.h"

RenderJob::RenderJob(SystemConfig& config, Layer& layer) :
	mLayer(layer),
	mCamera(*layer.GetCamera()),
	mResolution(config.GetValue<IVec2>("resolution"))
{
	mConfig = config;

	if (!mConfig.GetValue<bool>("enable_gi"))
	{
		GetPhotonMap().mStatus = RT_PhotonMap::PM_FINISHED;
		GetIrradianceCache().mStatus = RT_IrradianceCache::IC_FINISHED;
	}

	if (mConfig.GetValue<unsigned>("gi_method") != 1)
		GetPhotonMap().mStatus = RT_PhotonMap::PM_FINISHED;

	if (!mConfig.GetValue<bool>("enable_irr_caching"))
		GetIrradianceCache().mStatus = RT_IrradianceCache::IC_FINISHED;
}

RenderJob::~RenderJob()
{
	CleanMemory();
}

void RenderJob::LaunchRender()
{
	mStatus = RUNNING;
	SyncThreads();
	auto thread_num = mConfig.GetValue<unsigned>("num_threads");
	for (unsigned i = 0; i < thread_num; ++i)
		mThreads.emplace_back(std::thread(&RenderJob::ThreadWork, this));
}

void RenderJob::LaunchPhotonMapComputation()
{
	SyncThreads();
	mThreads.emplace_back(std::thread(&RT_PhotonMap::Launch, &mRTLayer.mPhotonMap, this));
}

void RenderJob::LaunchIrradianceCacheComputation()
{
	SyncThreads();
	mThreads.emplace_back(std::thread(&RT_IrradianceCache::Launch, &mRTLayer.mIrradianceCache, this));
}

void RenderJob::SyncThreads()
{
	for (auto& t : mThreads)
		t.join();
	mThreads.clear();
}

void RenderJob::SetupAndRender()
{
	mTimer.Start();

	SetupClusters();
	SetupProjectionPlane();

	mTexelArray.clear();
	mTexelArray.resize(mResolution.x * mResolution.y * 4);
	for (int i = 0; i < mResolution.x * mResolution.y; ++i)
		mTexelArray[(i * 4) + 3] = 255;

	mWorldToScreen = mCamera.GetPerspectiveMatrix() * mCamera.GetCameraMatrix();
	mRTLayer.Initialize(mLayer);

	if (!mConfig.GetValue<bool>("enable_gi"))
		mRTLayer.mGIMethod = RT_Layer::NONE;
	else if (mConfig.GetValue<unsigned>("gi_method") == 0)
		mRTLayer.mGIMethod = RT_Layer::MONTE_CARLO;
	else if (mConfig.GetValue<unsigned>("gi_method") == 1)
		mRTLayer.mGIMethod = RT_Layer::PHOTON_MAP;

	mRTLayer.mIrradianceCacheEnabled = mConfig.GetValue<bool>("enable_irr_caching");
	mRTLayer.mMontecarloSamples = mConfig.GetValue<unsigned>("montecarlo_samples");
	mRTLayer.mScatterGather = (mConfig.GetValue<unsigned>("photon_gather_method") == 1);
	mRTLayer.mGatherSamples = mConfig.GetValue<unsigned>("gather_samples");
}

void RenderJob::SetupClusters()
{
	auto cluster_size = mConfig.GetValue<unsigned>("cluster_size");
	auto samples_per_texel = mConfig.GetValue<unsigned>("samples_per_texel");

	unsigned Clus_width = (unsigned)glm::ceil(mResolution.x / (float)cluster_size);
	unsigned Clus_height = (unsigned)glm::ceil(mResolution.y / (float)cluster_size);

	mClustersAssigned = 0;
	mClusters.clear();

	for (unsigned y = 0; y < Clus_height; ++y)
	{
		for (unsigned x = 0; x < Clus_width; ++x)
		{
			IVec2 start = { cluster_size * x, cluster_size * y };
			IVec2 size = { cluster_size, cluster_size };
			if (x == Clus_width - 1)
				size.x = mResolution.x - ((Clus_width - 1) * cluster_size);
			if (y == Clus_height - 1)
				size.y = mResolution.y - ((Clus_height - 1) * cluster_size);

		RenderJob& th = *this;
		mClusters.emplace_back(th, start, size, samples_per_texel, Cluster::WAITING);
		}
	}

	std::vector<Vec2> route = { { 1, 0 },{ 0, -1 },{ -1, 0 },{ 0, 1 } };
	IVec2 coord = Vec2(Clus_width, Clus_height) / 2.f;
	mClusterIndices.push_back((coord.y * Clus_width) + coord.x);
	int i = 1;
	while (mClusterIndices.size() < mClusters.size())
	{
		int step = (i - 1) % 4;
		int size = (int)std::floor((i + 1) / 2.f);
		for (int j = 0; j < size; ++j)
		{
			coord += route[step];
			if (coord.x < 0 || coord.x >= (int)Clus_width ||
				coord.y < 0 || coord.y >= (int)Clus_height)
				continue;
			mClusterIndices.push_back((coord.y * Clus_width) + coord.x);
			if (mClusterIndices.size() == mClusters.size())
				break;
		}
		++i;
	}
}

void RenderJob::SetupProjectionPlane()
{
	auto projplane = mCamera.GetProjectionPlane();

	auto& orig = projplane[0];
	auto right = projplane[1] - projplane[0];
	auto down = projplane[2] - projplane[0];

	mTexelSizeX = right / (float)mResolution.x;
	mTexelSizeY = down / (float)mResolution.y;

	mProjPlanePositions.clear();
	mProjPlanePositions.resize(mResolution.x * mResolution.y);

	for (int y = 0; y < mResolution.y; ++y)
		for (int x = 0; x < mResolution.x; ++x)
			mProjPlanePositions[(y * mResolution.x) + x] =
			orig + (((float)y / mResolution.y) * down) + (((float)x / mResolution.x) * right);
}

int RenderJob::GetUnassignedCluster()
{
	if (mClustersAssigned >= mClusters.size())
		return -1;

	mMutex.lock();
	int index = mClusterIndices[mClustersAssigned];
	++mClustersAssigned;
	mMutex.unlock();

	return index;
}

void RenderJob::Update(Texture& tex)
{
	if (mStatus == FINISHED)
		return;
	if (mStatus == CANCELED)
	{
		mStatus = RenderJobStatus::FINISHED;
		return;
	}

	mClustersFinished = 0;
	for (auto& c : mClusters)
	{
		if (c.mState == Cluster::FINISHED)
			++mClustersFinished;
	}

	if (!mPaused)
		mTimer.Update();
	else
		mTimer.Start();

	tex.Load(&mTexelArray[0], mResolution.x, mResolution.y);
	if (mClustersFinished >= mClusters.size())
	{
		CleanMemory();
		mStatus = RenderJobStatus::FINISHED;
		return;
	}

	UpdateSubStatus();
}

void RenderJob::UpdateSubStatus()
{
	auto& pm = GetPhotonMap();
	auto& ic = GetIrradianceCache();

	// Photon mapping
	if (mConfig.GetValue<unsigned>("gi_method") == 1)
	{
		if (pm.mStatus == RT_PhotonMap::PM_WAITING)
			LaunchPhotonMapComputation();
	}

	// Irradiance cache
	if (mConfig.GetValue<bool>("enable_irr_caching"))
	{
		if (pm.mStatus == RT_PhotonMap::PM_FINISHED && ic.mStatus == RT_IrradianceCache::IC_WAITING)
			LaunchIrradianceCacheComputation();
	}
	
	// Render
	if (mStatus != RUNNING)
	{
		if (pm.mStatus == RT_PhotonMap::PM_FINISHED && ic.mStatus == RT_IrradianceCache::IC_FINISHED)
			LaunchRender();
	}
}

void RenderJob::RenderClusterHighlights()
{
	if (mStatus == RenderJobStatus::FINISHED)
		return;
	for (auto& c : mClusters)
		c.RenderHighlight();
}

void RenderJob::Interrupt()
{
	mClustersAssigned = (int)mClusters.size();
	for (auto& c : mClusters)
		c.Interrupt();
	mStatus = CANCELED;
}

void RenderJob::Pause(bool pause)
{
	for (auto& c : mClusters)
		c.Pause(pause);
	mPaused = pause;
	auto st = mStatus;
	if (pause)
		st = PAUSED;
	else
		mStatus = st;
}

void RenderJob::CleanMemory()
{
	for (auto& t : mThreads)
		t.join();
	mThreads.clear();
	mTexelArray.clear();
	mProjPlanePositions.clear();
	mClusters.clear();
	mClusterIndices.clear();
}

void RenderJob::ThreadWork()
{
	int cluster_index = GetUnassignedCluster();
	while (cluster_index > -1)
	{
		mClusters[cluster_index].Render();
		cluster_index = GetUnassignedCluster();
	}
}

Layer& RenderJob::GetLayer() { return mLayer; }
RT_Layer& RenderJob::GetRTLayer() { return mRTLayer; }
RT_PhotonMap& RenderJob::GetPhotonMap() { return mRTLayer.mPhotonMap; }
RT_IrradianceCache& RenderJob::GetIrradianceCache() { return mRTLayer.mIrradianceCache; }