#include "System.h"

void SystemConfig::Clear()
{
	for (auto& s : mVariables)
		if (s.second.mData)
			delete[] s.second.mData;
	for (auto& s : mLastVariables)
		if (s.second.mData)
			delete[] s.second.mData;
}

SystemConfig::~SystemConfig()
{
	Clear();
}

SystemConfig::SystemConfig(const SystemConfig& rhs)
{
	Clear();

	for (auto& s : rhs.mVariables)
	{
		auto& data = mVariables[s.first];
		data.mData = new char[s.second.mDataSize];
		data.mDataSize = s.second.mDataSize;
		data.mType = s.second.mType;
		for (unsigned i = 0; i < data.mDataSize; ++i)
			((char*)data.mData)[i] = ((char*)s.second.mData)[i];
	}
}

SystemConfig& SystemConfig::operator= (const SystemConfig& rhs)
{
	Clear();

	for (auto& s : rhs.mVariables)
	{
		auto& data = mVariables[s.first];
		data.mData = new char[s.second.mDataSize];
		data.mDataSize = s.second.mDataSize;
		data.mType = s.second.mType;
		for (unsigned i = 0; i < data.mDataSize; ++i)
			((char*)data.mData)[i] = ((char*)s.second.mData)[i];
	}

	return *this;
}

bool SystemConfig::HasChanged() { return mHasChanged; }

void SystemConfig::Update()
{
	mHasChanged = false;

	for (auto& s : mVariables)
	{
		auto& v = s.second;
		auto& l = mLastVariables[s.first];

		if (v.mData == nullptr || l.mData == nullptr)
		{
			mHasChanged = true;
			continue;
		}

		for (unsigned i = 0; i < v.mDataSize; ++i)
		{
			if (*((char*)v.mData + i) != *((char*)l.mData + i))
			{
				mHasChanged = true;
				break;
			}
		}
	}

	if (!mHasChanged)
		return;

	for (auto& s : mVariables)
	{
		auto& v = s.second;
		auto& l = mLastVariables[s.first];
		if (l.mData)
			delete[] l.mData;
		l = v;
		l.mData = new char[v.mDataSize];
		for (unsigned i = 0; i < v.mDataSize; ++i)
			*((char*)l.mData + i) = *((char*)v.mData + i);
	}
}
