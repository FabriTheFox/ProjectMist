#pragma once

#include "Importer.h"

class Importer_Shader : public Importer
{
public:
	IMPORTER_DECLARATION(Importer_Shader)
	void Import(const std::string& name, const std::string& path) override;
private:
};