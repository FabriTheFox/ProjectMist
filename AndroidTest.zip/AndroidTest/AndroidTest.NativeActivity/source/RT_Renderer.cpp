#include "RT_Renderer.h"
#include "RT_Layer.h"
#include "Utilities.h"
#include "Math.h"

#include "FoxTracerEngine.h"
#include "GraphicSystem.h"

void RT_Renderer::EmitPhoton(RT_PhotonMap& map, RT_PhotonMap::PhotonData& photon, FTEIntersection::IntersectionResult& at, RT_Renderer::RenderData& data)
{
	at.mNormal = glm::normalize(at.mNormal);
	auto dir = glm::normalize(at.mIntersectionPoint - at.mOriginPoint);

	auto absorbed = photon;
	absorbed.mNormal = at.mNormal;
	float dot = glm::max(glm::dot(-dir, at.mNormal), 0.f);
	absorbed.mColor = absorbed.mColor * Vec3(data.mpRT_Renderable->mModulationColor) * (dot);

	if (mpLayer->mScatterGather || !data.mFirstBounce)
		map.AddPhoton(at.mIntersectionPoint, absorbed);
	data.mFirstBounce = false;
	--data.mBounces;

	const float diff_prob = 0.8f;
	const float spec_prob = 0.1f;
	//const float abs_prob = 0.2f;

	float decision = Utilities::Random(0.f, 1.f);

	// diffuse
	if (decision < diff_prob)
	{
		Vec3 rdir;
		do {
			rdir = glm::normalize(Vec3{ Utilities::Random(-1.f, 1.f) , Utilities::Random(-1.f, 1.f) , Utilities::Random(-1.f, 1.f) });
		} while (glm::dot(rdir, at.mNormal) < 0);

		auto ph = photon;
		ph.mColor = ph.mColor * Vec3(data.mpRT_Renderable->mModulationColor) * (1 - dot) * (1.f / diff_prob);
		mpLayer->EmitPhoton(map, ph, at.mIntersectionPoint + (rdir * 0.01f), rdir, data);
	}

	// spec
	else if (decision < diff_prob + spec_prob)
	{
		Vec3 rdir = glm::normalize(glm::reflect(dir, at.mNormal));
		auto ph = photon;
		ph.mColor = ph.mColor * Vec3(data.mpRT_Renderable->mModulationColor) * (1 - dot) * (1.f / spec_prob);
		mpLayer->EmitPhoton(map, ph, at.mIntersectionPoint + (rdir * 0.01f), rdir, data);
	}

	// absorbed
	else {}
}

FTEIntersection::IntersectionResult RT_Renderer::GetNearestIntersection(const Vec3& start, const Vec3& dir, RenderData& data)
{
	FTEIntersection::IntersectionResult nearest;
	for (auto& ren : mRenderables)
	{
		auto res = ren.TraceRay(start, dir);
		if (ren.mVisible && res.mDis < nearest.mDis)
		{
			nearest = res;
			data.mpRT_Renderable = &ren;
		}
	}
	return nearest;
}

FTEIntersection::IntersectionResult RT_Renderer::GetNearestIntersection_Shadow(const Vec3& start, const Vec3& dir, RenderData& data)
{
	FTEIntersection::IntersectionResult nearest;
	for (auto& ren : mRenderables)
	{
		auto res = ren.TraceRay(start, dir);
		if (ren.mCastsShadow && ren.mVisible && res.mDis < nearest.mDis)
		{
			nearest = res;
			data.mpRT_Renderable = &ren;
		}
	}
	return nearest;
}

Vec4 RT_Renderer::Render(FTEIntersection::IntersectionResult& res, RenderData& data)
{
	return (this->*mRenderFN)(res, data);
}

Vec4 RT_Renderer::Render_Basic(FTEIntersection::IntersectionResult& res, RenderData& data)
{
	UNUSED_PARAM(res);
	return data.mpRT_Renderable->mModulationColor;
}

Vec4 RT_Renderer::Render_Phong(FTEIntersection::IntersectionResult& res, RenderData& data)
{
	res.mNormal = glm::normalize(res.mNormal);
	Color color = { 0, 0, 0, 0 };
	for (auto& l : mpLayer->mLights)
		color.mColor += l.ComputeColor(res, data);
	color.ClampMaxTo(1.f);
	return color;
}

Vec4 RT_Renderer::Render_ReflectivePhong(FTEIntersection::IntersectionResult& res, RenderData& data)
{
	--data.mBounces;
	res.mNormal = glm::normalize(res.mNormal);

	auto dir = glm::normalize(res.mIntersectionPoint - res.mOriginPoint);
	auto reflected = glm::normalize(glm::reflect(dir, res.mNormal));

	Color color = { 0, 0, 0, 0 };
	for (auto& l : mpLayer->mLights)
		color.mColor += l.ComputeColor(res, data);

	color.mColor = color.mColor * 0.2f;
	color.mColor += 0.8f * mpLayer->ComputeColor(res.mIntersectionPoint + (reflected * 0.01f), reflected, { 0, 0, 0, 1 }, data);

	color.ClampMaxTo(1.f);

	return color;
}

Vec4 RT_Renderer::Render_RefractivePhong(FTEIntersection::IntersectionResult& res, RenderData& data)
{
	--data.mBounces;
	res.mNormal = glm::normalize(res.mNormal);

	float ratio = (1 / 1.1f);
	if (res.mIsBackFace)
		ratio = 1 / ratio;

	auto dir = glm::normalize(res.mIntersectionPoint - res.mOriginPoint);
	auto refract_vec = glm::normalize(FTEIntersection::Refract(dir, res.mNormal, ratio));
	auto reflect_vec = glm::normalize(glm::reflect(dir, res.mNormal));

	float absorption = 0.1f;
	float reflectiveness = (1 - absorption) * (1.f - glm::max(glm::dot(-dir, res.mNormal), 0.f));
	float refractiveness = (1 - absorption - reflectiveness);

	Color color = { 0, 0, 0, 0 };

	for (auto& l : mpLayer->mLights)
		color.mColor += l.ComputeColor(res, data);

	Vec4 refracted = mpLayer->ComputeColor(res.mIntersectionPoint + (refract_vec * 0.05f), refract_vec, { 0, 0, 0, 1 }, data);
	Vec4 reflected = mpLayer->ComputeColor(res.mIntersectionPoint + (reflect_vec * 0.05f), reflect_vec, { 0, 0, 0, 1 }, data);

	color.mColor *= absorption;
	color.mColor += reflectiveness * reflected;
	color.mColor += refractiveness * refracted;

	color.ClampMaxTo(1.f);

	return color;
}