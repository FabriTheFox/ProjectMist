#include "Importer_Model.h"
#include "FBX_SDK.h"
#include "AssetSystem.h"

Mesh GetGeometry(const std::string & node_name, FbxMesh* pMesh)
{
	UNUSED_PARAM(node_name);

	int i, j, lPolygonCount = pMesh->GetPolygonCount();
	FbxVector4* lControlPoints = pMesh->GetControlPoints();

	Mesh newMesh;

	std::vector<Vertex> vertices;
	vertices.resize(lPolygonCount * 3);
	std::vector<unsigned> indices;

	for (int i = 0; i < pMesh->GetDeformerCount(); ++i)
	{
		// skin
		FbxSkin *pSkin = (FbxSkin*)pMesh->GetDeformer(i, FbxDeformer::eSkin);
		if (pSkin == NULL)
			continue;

		// bone count
		int ncBones = pSkin->GetClusterCount();

		// iterate bones
		for (int boneIndex = 0; boneIndex < ncBones; ++boneIndex)
		{
			// cluster
			FbxCluster* cluster = pSkin->GetCluster(boneIndex);

			// bone ref
			FbxNode* pBone = cluster->GetLink();
			UNUSED_PARAM(pBone);

			// Get the bind pose
			FbxAMatrix bindPoseMatrix, transformMatrix;
			cluster->GetTransformMatrix(transformMatrix);
			cluster->GetTransformLinkMatrix(bindPoseMatrix);

			// decomposed transform components
			//vS = bindPoseMatrix.GetS();
			//vR = bindPoseMatrix.GetR();
			//vT = bindPoseMatrix.GetT();

			int *pVertexIndices = cluster->GetControlPointIndices();
			double *pVertexWeights = cluster->GetControlPointWeights();

			// Iterate through all the vertices, which are affected by the bone
			int ncVertexIndices = cluster->GetControlPointIndicesCount();

			for (int iBoneVertexIndex = 0; iBoneVertexIndex < ncVertexIndices; iBoneVertexIndex++)
			{
				// vertex
				int niVertex = pVertexIndices[iBoneVertexIndex];
				UNUSED_PARAM(niVertex);

				// weight
				float fWeight = (float)pVertexWeights[iBoneVertexIndex];
				UNUSED_PARAM(fWeight);
			}
		}
	}

	int vertexId = 0;
	for (i = 0; i < lPolygonCount; i++)
	{
		int lPolygonSize = pMesh->GetPolygonSize(i);

		if (lPolygonSize != 3)
			__debugbreak();

		for (j = 0; j < lPolygonSize; j++)
		{
			// Vertex coordinates
			int lControlPointIndex = pMesh->GetPolygonVertex(i, j);
			auto& pos = lControlPoints[lControlPointIndex];
			vertices[(i * 3) + j].mPosition = Vec3{ pos[0], pos[1], pos[2] };

			// Texture Coords
			for (int l = 0; l < pMesh->GetElementUVCount(); ++l)
			{
				::FbxGeometryElementUV* leUV = pMesh->GetElementUV(l);

				fbxsdk_2015_1::FbxVector2 vec2;
				int id;

				Vec2* texcoord = nullptr;
				switch (l)
				{
				case 0:
					texcoord = &vertices[(i * 3) + j].mTexCoord;
					break;
				case 1:
					texcoord = &vertices[(i * 3) + j].mTexCoord;
					break;
				case 2:
					texcoord = &vertices[(i * 3) + j].mTexCoord;
					break;
				default:
					break;
				}

				switch (leUV->GetMappingMode())
				{
				case FbxGeometryElement::eByControlPoint:
					switch (leUV->GetReferenceMode())
					{
					case FbxGeometryElement::eDirect:
						vec2 = leUV->GetDirectArray().GetAt(lControlPointIndex);
						*texcoord = Vec2{ vec2.mData[0], vec2.mData[1] };
						break;
					case FbxGeometryElement::eIndexToDirect:
						id = leUV->GetIndexArray().GetAt(lControlPointIndex);
						vec2 = leUV->GetDirectArray().GetAt(id);
						*texcoord = Vec2{ vec2.mData[0], vec2.mData[1] };
						break;
					}
					break;

				case FbxGeometryElement::eByPolygonVertex:
					int lTextureUVIndex = pMesh->GetTextureUVIndex(i, j);
					switch (leUV->GetReferenceMode())
					{
					case FbxGeometryElement::eDirect:
					case FbxGeometryElement::eIndexToDirect:
						vec2 = leUV->GetDirectArray().GetAt(lTextureUVIndex);
						*texcoord = Vec2{ vec2.mData[0], vec2.mData[1] };
						break;
					}
				}

				// Flip the y corrdinate of the uv (for opengl)
				texcoord->y = 1 - texcoord->y;
			}

			// Normals
			for (int l = 0; l < pMesh->GetElementNormalCount(); ++l)
			{
				::FbxGeometryElementNormal* leNormal = pMesh->GetElementNormal(l);
				fbxsdk_2015_1::FbxVector4 normal;

				switch (leNormal->GetMappingMode())
				{
				case FbxGeometryElement::eByPolygonVertex:
					switch (leNormal->GetReferenceMode())
					{
					case FbxGeometryElement::eDirect:
						normal = leNormal->GetDirectArray().GetAt(vertexId);
						vertices[(i * 3) + j].mNormal = Vec3{ normal.mData[0], normal.mData[1], normal.mData[2] };
						break;
					case FbxGeometryElement::eIndexToDirect:
						int id = leNormal->GetIndexArray().GetAt(vertexId);
						normal = leNormal->GetDirectArray().GetAt(id);
						vertices[(i * 3) + j].mNormal = Vec3{ normal.mData[0], normal.mData[1], normal.mData[2] };
						break;
					}
					break;

				case FbxGeometryElement::eByControlPoint:
					normal = leNormal->GetDirectArray().GetAt(lControlPointIndex);
					vertices[(i * 3) + j].mNormal = Vec3{ normal.mData[0], normal.mData[1], normal.mData[2] };
					break;

				default:
					PRINT_WARNING << "Unsupported mapping mode in model. Blame Fabri!";
					break;
				}

			}

			/*// Tangents
			for (int l = 0; l < pMesh->GetElementTangentCount(); ++l)
			{
			::FbxGeometryElementTangent* leTangent = pMesh->GetElementTangent(l);
			fbxsdk_2015_1::FbxVector4 tangent;

			switch (leTangent->GetMappingMode())
			{
			case FbxGeometryElement::eByPolygonVertex:
			switch (leTangent->GetReferenceMode())
			{
			case FbxGeometryElement::eDirect:
			tangent = leTangent->GetDirectArray().GetAt(vertexId);
			vertices[(i * 3) + j].mTangent = Vec3{ tangent.mData[0], tangent.mData[1], tangent.mData[2] };
			break;
			case FbxGeometryElement::eIndexToDirect:
			int id = leTangent->GetIndexArray().GetAt(vertexId);
			tangent = leTangent->GetDirectArray().GetAt(id);
			vertices[(i * 3) + j].mTangent = Vec3{ tangent.mData[0], tangent.mData[1], tangent.mData[2] };
			break;
			}
			break;

			case FbxGeometryElement::eByControlPoint:
			tangent = leTangent->GetDirectArray().GetAt(lControlPointIndex);
			vertices[(i * 3) + j].mTangent = Vec3{ tangent.mData[0], tangent.mData[1], tangent.mData[2] };
			break;

			default:
			PRINT_WARNING << "Unsupported mapping mode in model. Blame Fabri!";
			break;
			}
			}

			// Binormals
			for (int l = 0; l < pMesh->GetElementBinormalCount(); ++l)
			{
			::FbxGeometryElementBinormal* leBinormal = pMesh->GetElementBinormal(l);
			fbxsdk_2015_1::FbxVector4 binormal;

			switch (leBinormal->GetMappingMode())
			{
			case FbxGeometryElement::eByPolygonVertex:
			switch (leBinormal->GetReferenceMode())
			{
			case FbxGeometryElement::eDirect:
			binormal = leBinormal->GetDirectArray().GetAt(vertexId);
			vertices[(i * 3) + j].mBinormal = Vec3{ binormal.mData[0], binormal.mData[1], binormal.mData[2] };
			break;
			case FbxGeometryElement::eIndexToDirect:
			int id = leBinormal->GetIndexArray().GetAt(vertexId);
			binormal = leBinormal->GetDirectArray().GetAt(id);
			vertices[(i * 3) + j].mBinormal = Vec3{ binormal.mData[0], binormal.mData[1], binormal.mData[2] };
			break;
			}
			break;

			case FbxGeometryElement::eByControlPoint:
			binormal = leBinormal->GetDirectArray().GetAt(lControlPointIndex);
			vertices[(i * 3) + j].mBinormal = Vec3{ binormal.mData[0], binormal.mData[1], binormal.mData[2] };
			break;

			default:
			PRINT_WARNING << "Unsupported mapping mode in model. Blame Fabri!";
			break;
			}
			}*/
			vertexId++;
		}

		//ComputeTangentsAndBinormals(vertices[(i * 3) + 0], vertices[(i * 3) + 1], vertices[(i * 3) + 2]);
	}

	indices.reserve(vertices.size());
	for (unsigned i = 0; i < vertices.size(); ++i)
		indices.push_back(i);

	newMesh.UploadToGpu(vertices, indices);
	return newMesh;
}

void ProcessNode(FbxNode* pNode, Model& model)
{
	if (pNode->GetMesh())
	{
		auto mesh = GetGeometry(pNode->GetName(), pNode->GetMesh());
		mesh.mName = pNode->GetName();

		model.mMeshes.push_back(mesh);

		Transform& tr = model.mMeshes.back().mLocalTransform;
		tr.mPosition = {pNode->LclTranslation.Get().mData[0], pNode->LclTranslation.Get().mData[1], pNode->LclTranslation.Get().mData[2]};
		tr.mScale = { pNode->LclScaling.Get().mData[0], pNode->LclScaling.Get().mData[1], pNode->LclScaling.Get().mData[2] };
		tr.mRotation = { pNode->LclRotation.Get().mData[0], pNode->LclRotation.Get().mData[1], pNode->LclRotation.Get().mData[2] };

		//LoadMaterials(pNode->GetMesh(), mesh);
	}

	for (int i = 0; i < pNode->GetChildCount(); i++)
		ProcessNode(pNode->GetChild(i), model);
}

void Importer_Model::Import(const std::string& name, const std::string& path)
{
	if (FbxScene * lScene = LoadFBXScene(path))
	{
		auto& sys = FoxTracerEngine::GetSystem<AssetSystem>();

		FbxNode* lNode = lScene->GetRootNode();
		if (lNode)
		{
			//if (!lNode->GetChild(0)->GetMesh())
			//	return;
			auto& asset = sys.RegisterAsset<Model>(name);
			ProcessNode(lNode->GetChild(0), asset);
		}
		lScene->Destroy();
	}
	else
		PRINT_WARNING << "Could not load the model \"" << path << "\".";
}

void Importer_Model::LoadFBXModel(void* pNode, Asset* asset)
{
	ProcessNode((FbxNode*)pNode, *((Model*)asset));
}