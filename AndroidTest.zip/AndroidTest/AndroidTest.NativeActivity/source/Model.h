#pragma once

#include "DataTypes.h"
#include <vector>

struct Vertex
{
	Vec3 mPosition;
	Vec2 mTexCoord;
	Vec3 mNormal;
};

struct Mesh
{
	void Draw(unsigned mode = 4);
	void DrawInstanced(unsigned count);
	void UploadToGpu(const std::vector<Vertex>& vertices, const std::vector<unsigned>& indices);
	void UploadToGpuUpdate(const std::vector<Vertex>& vertices, const std::vector<unsigned>& indices);

	unsigned mIndiceCount{0};
	unsigned mVertexCount{0};
	unsigned mVAO, mVBO, mEBO;

	//Mat4 mTransform;
	std::vector<Vertex> mVertices; 
	std::vector<unsigned> mIndices;
};

class Model
{	
public:
	Model() = default;

	void Draw(unsigned mode = 4);
	void DrawInstanced(unsigned count);

//private:
	std::vector<Mesh> mMeshes;
};