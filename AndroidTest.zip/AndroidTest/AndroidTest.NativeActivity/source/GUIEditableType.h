#pragma once

#include "ImGUIHeaders.h"
#include <string>

namespace FTEGUI
{
	class IGUIEditable
	{
	public:
		virtual void Show(void* data, const std::string& name) = 0;
	};

	template <typename T>
	class GUIEditableType : public IGUIEditable
	{
	public:
		virtual void Show(void* data, const std::string& name) override { return false; }
	};

	// INT =================================================================
	class Int_Drag : public GUIEditableType<int>
	{
	public:
		Int_Drag(float speed = 1.f, int min = 0, int max = 0, const char* format = "%.0f") : mSpeed(speed), mMin(min), mMax(max), mFormat(format) {}
		void Show(void* data, const std::string& name) override { ImGui::DragInt(name.c_str(), (int*)data, mSpeed, mMin, mMax, mFormat.c_str());}

		std::string mFormat;
		float mSpeed;
		int mMin, mMax;
	};

	class Int_Slider : public GUIEditableType<int>
	{
	public:
		Int_Slider(int min = 0, int max = 0, const char* format = "%.0f") : mMin(min), mMax(max), mFormat(format) {}
		void Show(void* data, const std::string& name) override { ImGui::SliderInt(name.c_str(), (int*)data, mMin, mMax, mFormat.c_str()); }

		std::string mFormat;
		int mMin, mMax;
	};
	// INT =================================================================


	// FLOAT =================================================================
	class Float_Drag : public GUIEditableType<float>
	{
	public:
		Float_Drag(float speed = 1.f, int min = 0, int max = 0, const char* format = "%.0f") : mSpeed(speed), mMin(min), mMax(max), mFormat(format) {}
		void Show(void* data, const std::string& name) override { ImGui::DragFloat(name.c_str(), (float*)data, mSpeed, mMin, mMax, mFormat.c_str()); }

		std::string mFormat;
		float mSpeed;
		int mMin, mMax;
	};

	class Float_Slider : public GUIEditableType<float>
	{
	public:
		Float_Slider(int min = 0, int max = 0, const char* format = "%.0f") : mMin(min), mMax(max), mFormat(format) {}
		void Show(void* data, const std::string& name) override { ImGui::SliderFloat(name.c_str(), (float*)data, mMin, mMax, mFormat.c_str()); }

		std::string mFormat;
		int mMin, mMax;
	};
	// FLOAT =================================================================

}