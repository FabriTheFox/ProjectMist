#include "RT_Light.h"
#include "RT_Layer.h"
#include "Utilities.h"
#include <thread>

std::vector<std::thread> RT_Light::mThreads;

void RT_Light::EmitPhotons(RT_PhotonMap& map, RT_Renderer::RenderData& data, unsigned photon_num, unsigned photon_intensity)
{
	unsigned threads = 1;
	unsigned photons_each = photon_num / threads;
	for (unsigned i = 0; i < threads; ++i)
		mThreads.emplace_back(std::thread(&RT_Light::ThreadEmitPhotons, this, photons_each, photon_num, &map, data, photon_intensity));

	for (auto& t : mThreads)
		t.join();
	mThreads.clear();
}

void RT_Light::ThreadEmitPhotons(unsigned num, unsigned photon_num, RT_PhotonMap* map, RT_Renderer::RenderData& data, unsigned photon_intensity)
{
	Vec3 total_int = mDiffuse * 100000.f * (float)photon_intensity;
	long double total_area = photon_num * map->GetArea();
	Vec3 intensity = total_int / (float)total_area;

	for (unsigned i = 0; i < num; ++i)
	{
		Vec3 dir = { Utilities::Random(-1.f, 1.f) , Utilities::Random(-1.f, 1.f) , Utilities::Random(-1.f, 1.f) };
		dir = glm::normalize(dir);

		RT_PhotonMap::PhotonData photon;
		photon.mColor = intensity;

		RT_Renderer::RenderData d = data;
		mpLayer->EmitPhoton(*map, photon, mPosition, dir, d);
	}
}

const unsigned shadow_samples = 1;
float RT_Light::ComputeShadow(const Vec3& start)
{
	return ComputeShadowSample(start, mPosition);

	float shadow = 0;
	for (unsigned i = 0; i < shadow_samples; ++i)
	{
		Vec3 off = { Utilities::Random(-1.f, 1.f) , Utilities::Random(-1.f, 1.f) , Utilities::Random(-1.f, 1.f) };
		shadow += ComputeShadowSample(start, mPosition + off);
	}

	return shadow / shadow_samples;
}

float RT_Light::ComputeShadowSample(const Vec3& start, const Vec3& end)
{
	Vec3 lightdir = end - start;
	Vec3 dir = glm::normalize(lightdir);

	RT_Renderer::RenderData d;
	auto result = mpLayer->TraceShadowRay(start + (dir * 0.001f), dir, d);

	if (result.HasCollided())
	{
		float length = glm::length(lightdir);
		if (length > result.mDis)
			return 0.f;
	}

	return 1;
}

Vec4 RT_Light::ComputeColor_Omni(FTEIntersection::IntersectionResult& inters, RT_Renderer::RenderData& data)
{
	Vec3 disvec = mPosition - inters.mIntersectionPoint;
	float dis = glm::dot(disvec, disvec);
	if (dis > (mAttenuation.mOuterRadius * mAttenuation.mOuterRadius))
		return Vec4{ 0, 0, 0, 1 };

	float att = 1 - glm::smoothstep(mAttenuation.mInnerRadius * mAttenuation.mInnerRadius, mAttenuation.mOuterRadius * mAttenuation.mOuterRadius, dis);
	att = glm::pow(att, 5);

	Vec3 lightdir = glm::normalize(disvec);
	float diff = (float)std::fmax(glm::dot(inters.mNormal, lightdir), 0) * att;

	Vec3 viewdir = glm::normalize(mpLayer->mpCamera->GetTransform().mPosition - inters.mIntersectionPoint);
	Vec3 halfdir = glm::normalize(viewdir + lightdir);
	float spec = (float)glm::pow(std::fmax(glm::dot(halfdir, inters.mNormal), 0), 128) * att;

	Vec3 color = ((diff * mDiffuse) + (spec * mSpecular));
	color = color * Vec3(data.mpRT_Renderable->mModulationColor) * ComputeShadow(inters.mIntersectionPoint);

	if (data.mGIBounces > 0)
	{
		--data.mGIBounces;

		if (mpLayer->mGIMethod == RT_Layer::NONE)
			color += (mAmbient * att) * Vec3(data.mpRT_Renderable->mModulationColor);
		else if (mpLayer->mGIMethod == RT_Layer::PHOTON_MAP)
			color += mpLayer->ComputeGIAt(inters);
		else if (mpLayer->mGIMethod == RT_Layer::MONTE_CARLO)
		{
			Vec4 gi;
			for (unsigned i = 0; i < mpLayer->mMontecarloSamples; ++i)
			{
				RT_Renderer::RenderData d = data;
				d.mBounces = 1;
				Vec3 dir = glm::normalize(Vec3{ Utilities::Random(-1.f, 1.f) , Utilities::Random(-1.f, 1.f) , Utilities::Random(-1.f, 1.f) });
				if (glm::dot(dir, inters.mNormal) < 0)
					dir = -dir;
				gi += mpLayer->ComputeColor(inters.mIntersectionPoint + (dir * 0.01f), dir, { 0, 0, 0, 0 }, d);
			}

			gi /= mpLayer->mMontecarloSamples;
			color += Vec3(gi);
		}
	}

	return Vec4(color, 1);
}