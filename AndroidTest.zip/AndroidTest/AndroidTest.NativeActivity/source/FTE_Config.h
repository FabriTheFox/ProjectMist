#pragma once


#define FTE_ENABLE_GL_DEBUG			0
#define FTE_WINDOWS_CONSOLE_OUTPUT	0