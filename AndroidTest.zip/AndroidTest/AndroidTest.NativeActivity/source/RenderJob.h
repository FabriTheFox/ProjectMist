#pragma once

#include "Layer.h"
#include "RT_Layer.h"
#include "RT_IrradianceCache.h"

#include <thread>
#include <mutex>

class RenderJob
{
	NON_COPYABLE(RenderJob)
	friend class Cluster;
	friend class RT_PhotonMap;
	friend class RT_IrradianceCache;

public:
	enum RenderJobStatus
	{
		WAITING,
		RUNNING,
		FINISHED,
		PAUSED,
		CANCELED
	};

	~RenderJob();
	RenderJob(SystemConfig& config, Layer& layer);

	void SetupAndRender();
	void Update(Texture& tex);
	void RenderClusterHighlights();

	void Interrupt();
	void Pause(bool pause);

	Layer& GetLayer();
	RT_Layer& GetRTLayer();
	RT_PhotonMap& GetPhotonMap();
	RT_IrradianceCache& GetIrradianceCache();

	RenderJobStatus mStatus{ WAITING };
	Utilities::Timer mTimer;

private:
	void UpdateSubStatus();
	void LaunchRender();
	void LaunchPhotonMapComputation();
	void LaunchIrradianceCacheComputation();
	void SyncThreads();

	void ThreadWork();
	void SetupClusters();
	void SetupProjectionPlane();
	int GetUnassignedCluster();

	void CleanMemory();

	// Heavy data
	std::vector<unsigned char> mTexelArray;
	std::vector<int> mClusterIndices;
	std::vector<Vec3> mProjPlanePositions;
	std::vector<Cluster> mClusters;
	std::vector<std::thread> mThreads;

	// Photon map data
	Mat4 mWorldToScreen;
	std::vector<unsigned char> mPhotonTexelArray;

	Camera& mCamera;
	Layer& mLayer;
	RT_Layer mRTLayer;

	std::mutex mMutex;

	// Config
	SystemConfig mConfig;
	IVec2 mResolution;
	Vec3 mTexelSizeX;
	Vec3 mTexelSizeY;

	// flags
	unsigned mClustersAssigned{ 0 };
	unsigned mClustersFinished{ 0 };
	bool mPaused{ false };
};