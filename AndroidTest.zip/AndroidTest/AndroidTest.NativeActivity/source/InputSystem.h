#pragma once

#include "System.h"

const unsigned MAX_SCANCODES = 512; // SDL_NUM_SCANCODES = 512

const unsigned MOUSE_LEFT = 1;
const unsigned MOUSE_MIDDLE = 2;
const unsigned MOUSE_RIGHT = 3;

class InputSystem : public System
{
	RTTI_DECLARATION(InputSystem)

public:
	void Initialize() override;
	void Update() override;
	void StartOfFrame();

	void EnableInput(bool enable);

	bool KeyTriggered(unsigned key);
	bool KeyPressed(unsigned key);
	bool KeyReleased(unsigned key);

	bool MouseTriggered(char button);
	bool MousePressed(char button);
	bool MouseReleased(char button);

	const Vec2& GetMouseMotion();

	void ProcessSDLEvent(void* ev);
	IVec2 GetMousePosition();

private:
	void ResetInput();

	char mCurrentKeys[MAX_SCANCODES];
	char mPreviousKeys[MAX_SCANCODES];

	char mCurrentMouse[6];
	char mPreviousMouse[6];

	Vec2 mMouseMotion;
	bool mEnableInput{true};
};