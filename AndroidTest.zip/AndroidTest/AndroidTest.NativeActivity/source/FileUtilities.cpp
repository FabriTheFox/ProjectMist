#include "FileUtilities.h"

#include <Windows.h>

namespace FileUtilities
{
	std::string SelectFile()
	{
		OPENFILENAME ofn;       // common dialog box structure
		WCHAR szFile[260];       // buffer for file name
		HWND hwnd = nullptr;              // owner window
		HANDLE hf;              // file handle

								// Initialize OPENFILENAME
		ZeroMemory(&ofn, sizeof(ofn));
		ofn.lStructSize = sizeof(ofn);
		ofn.hwndOwner = hwnd;
		ofn.lpstrFile = szFile;
		// Set lpstrFile[0] to '\0' so that GetOpenFileName does not 
		// use the contents of szFile to initialize itself.
		ofn.lpstrFile[0] = '\0';
		ofn.nMaxFile = sizeof(szFile);
		ofn.lpstrFilter = L"*.fbx;";
		ofn.nFilterIndex = 0;
		ofn.lpstrFileTitle = NULL;
		ofn.nMaxFileTitle = 0;
		ofn.lpstrInitialDir = NULL;
		ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_EXTENSIONDIFFERENT;

		if (GetOpenFileName(&ofn) == TRUE)
		{
			hf = CreateFile(ofn.lpstrFile,
				GENERIC_READ,
				0,
				(LPSECURITY_ATTRIBUTES)NULL,
				OPEN_EXISTING,
				FILE_ATTRIBUTE_NORMAL,
				(HANDLE)NULL);
		}
			
		std::string name;
		name.resize(200);
		WideCharToMultiByte(CP_ACP, WC_COMPOSITECHECK, ofn.lpstrFile, -1, (char*)name.data(), 200, NULL, NULL);

		return {name.c_str()};
	}
}

