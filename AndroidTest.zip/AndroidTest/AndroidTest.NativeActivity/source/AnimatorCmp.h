#pragma once

#include "Component.h"
#include "Animation.h"
#include <string>

class Animation;

class AnimatorCmp :
	public Component,
	public std::enable_shared_from_this<AnimatorCmp>
{
	friend class Animation;
	COMPONENT_SERIALIZABLE_DECLARATION(AnimatorCmp)

public:
	AnimatorCmp() = default;
	void Update();
	void Load(SerDataPack& data) override;

	void Pause(bool pause);							// Pause animation
	void Stop();									// Reset and pause
	void Reset();
	void Play();
	void Loop(bool loop);
	void SetSpeed(float speed);
	void PlayAnimation(const std::string& name);
	void PlayAnimation(WK_PTR<Animation> anim);
	void SetAnimationAt(float t);

//private:
	float mCurrentFrame{ 0 };
	bool mCompleted{ false };
	bool mPaused{ false };
	bool mLoop{ true };
	float mSpeed{ 1.f };
	float mCurrentTime{ 0 };

	std::string mAnimation;
	AnimationInstance mAnimationInstance;
};