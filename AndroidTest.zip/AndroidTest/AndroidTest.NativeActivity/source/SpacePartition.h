#pragma once

#include "DataTypes.h"
#include "Intersection.h"
#include <vector>

class AABB
{
public:
	AABB() = default;
	AABB(const std::vector<Vec3>& points);
	AABB(const std::vector<FTEIntersection::Triangle>& triangles);

	Vec3 mCenter;
	Vec3 mExtent;

	void MakeItCube();

	bool IsPointInside(const Vec3& point);
	bool AABB::IsSphereInside(const Vec3& c, float radius);
	bool IsCollidingWithAABB(const AABB& bb);

	std::vector<AABB> SplitByAAPlane(const Vec2& aaplane);

	float GetArea();
	float GetSurfaceArea();
};