#include "Importer_Scene.h"
#include "FBX_SDK.h"

#include "Model.h"
#include "AssetSystem.h"

#include "Importer_Animation.h"
#include "Importer_Model.h"

#include "AssetSystem.h"

void LoadModels(FbxScene* pScene)
{
	auto importer = Importer_Model::GetInstance().lock();
	auto& sys = FoxTracerEngine::GetSystem<AssetSystem>();

	FbxNode* lNode = pScene->GetRootNode();
	if (lNode)
	{
		for (int i = 0; i < lNode->GetChildCount(); i++)
		{
			if (!lNode->GetChild(i)->GetMesh())
				continue;

			auto& asset = sys.RegisterAsset<Model>(lNode->GetName());
			importer->LoadFBXModel(lNode->GetChild(i), &asset);
		}
	}
}

void LoadAnimations(FbxScene* pScene)
{
	auto importer = Importer_Animation::GetInstance().lock();
	auto& sys = FoxTracerEngine::GetSystem<AssetSystem>();

	int num = pScene->GetSrcObjectCount<FbxAnimStack>();
	for (int i = 0; i < num; i++)
	{
		FbxAnimStack* lAnimStack = pScene->GetSrcObject<FbxAnimStack>(i);
		auto name = std::string(lAnimStack->GetName());
		Utilities::RemoveCharFromString(name, ' ');
		auto& asset = sys.RegisterAsset<Animation>(name);
		importer->LoadFBXAnimation(lAnimStack, pScene, &asset);
	}
}

void Importer_Scene::Import(const std::string& name, const std::string& path)
{
	UNUSED_PARAM(name);

	if (FbxScene * lScene = LoadFBXScene(path))
	{
		LoadModels(lScene);
		LoadAnimations(lScene);
		lScene->Destroy();
	}
	else
		PRINT_WARNING << "Could not load the scene \"" << path << "\".";
}