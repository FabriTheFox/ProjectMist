#include "RT_Renderable.h"

FTEIntersection::IntersectionResult RT_Renderable::TraceRay_Sphere(const Vec3& start, const Vec3& dir)
{
	return FTEIntersection::Ray_Sphere(mTransform.mPosition, mTransform.mScale.x * 0.5f, start, dir);
}

FTEIntersection::IntersectionResult RT_Renderable::TraceRay_AACube(const Vec3& start, const Vec3& dir)
{
	return FTEIntersection::Ray_AABB(mTransform.mPosition, mTransform.mScale * 0.5f, start, dir);
}

FTEIntersection::IntersectionResult RT_Renderable::TraceRay_OCube(const Vec3& start, const Vec3& dir)
{
	return FTEIntersection::Ray_OBB(mWorldToModel, start, dir);
}

FTEIntersection::IntersectionResult RT_Renderable::TraceRay_Ellipsoid(const Vec3& start, const Vec3& dir)
{
	return FTEIntersection::Ray_Ellipsoid(mWorldToModel, start, dir);
}

FTEIntersection::IntersectionResult RT_Renderable::TraceRay_Mesh(const Vec3& start, const Vec3& dir)
{
	return mKDTree->TraceRay(start, dir);
}