#pragma once

#include "DataTypes.h"

using Vector3 = glm::fvec3;
using Matrix4 = glm::fmat4x4;

namespace FTE_Quat
{
	class FTEQuat
	{
	public:
		// Ctor
		FTEQuat(const float& xx, const float& yy, const float& zz, const float& ww) : x(xx), y(yy), z(zz), w(ww) {}
		// Converts to quat from euler representation
		FTEQuat(const Vector3& v);
		// Default ctor
		FTEQuat() = default;

		Vector3 GetEuler();

		// Basic quaternion property functions
		FTEQuat& Normalize();
		FTEQuat Conjugate() const;
		FTEQuat Inverse() const;

		// Converts the quaternion to matrix representation. Used for rendering.
		Matrix4 GetRotationMatrix() const;

		// Quat/float multiplication
		FTEQuat& operator*= (const FTEQuat& rhs);
		FTEQuat& operator*= (const float& rhs);

		// Quat addition/substraction
		FTEQuat& operator-= (const FTEQuat& rhs);
		FTEQuat& operator+= (const FTEQuat& rhs);

		float x{0};		// i
		float y{0};		// j
		float z{0};		// k

		float w{1};		// s (1 by default)
	};

	// Quat * quat
	FTEQuat operator* (const FTEQuat& lhs, const FTEQuat& rhs);
	// Quat * float
	FTEQuat operator* (const FTEQuat& lhs, const float& rhs);
	// float * quat
	FTEQuat operator* (const float& lhs, const FTEQuat& rhs);
	// quat * vector3
	Vector3 operator* (const FTEQuat& lhs, const Vector3& rhs);
	// vector * quat
	Vector3 operator* (const Vector3& lhs, const FTEQuat& rhs);

	// Quat +- quat
	FTEQuat operator- (const FTEQuat& lhs, const FTEQuat& rhs);
	FTEQuat operator+ (const FTEQuat& lhs, const FTEQuat& rhs);

	// quat dot quat
	float Dot(const FTEQuat& lhs, const FTEQuat& rhs);

	// Slerp for quaternions
	FTEQuat Slerp(FTEQuat q0, FTEQuat q1, float t);
}

using FTEQUAT = FTE_Quat::FTEQuat;