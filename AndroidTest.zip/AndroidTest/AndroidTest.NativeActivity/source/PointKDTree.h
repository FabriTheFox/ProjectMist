#pragma once

#include "RTTI.h"
#include "Intersection.h"
#include "SpacePartition.h"
#include <mutex>

template <typename T>
class PointKDTree
{
	NON_COPYABLE(PointKDTree<T>)

public:
	struct KDTData
	{
		KDTData() = default;
		KDTData(const Vec3& pos, const T& d) : mPosition(pos), mData(d) {}

		Vec3 mPosition;
		T mData;
	};

	struct Stats
	{
		unsigned mTotalElements{0};
		unsigned mNodes{0};
		unsigned mPlaneSplits{0};
		unsigned mDuplicatedElements{0};
		float mAvgElementsPerNode{0};
	};

	PointKDTree() = default;
	~PointKDTree();

	unsigned BuildKDTree(std::vector<KDTData>& data, unsigned maxlevel, bool able_to_render = false);

	void RenderTree(unsigned maxlevel, bool drawparents, const std::string& layer);
	void DeleteTree();

	std::vector<KDTData> GetNearData(const Vec3& pos)
	{
		mMaxRadiusSQ = mMaxRadius * mMaxRadius;

		std::vector<PointKDTree<T>::KDTData> vector;
		GetNearDataNode(pos, mRoot, vector);

		return vector;
	}

	Stats GetStats() { return mStats; }

	float& GetIntersectionCost();
	float& GetTraverseCost();
	float& GetMaxRadius();
	unsigned GetLevel();
	unsigned GetElementNum();

private:
	struct KDNode
	{
		FTEIntersection::IntersectionResult TraceRay(const Vec3& start, const Vec3& dir);

		AABB mBoundingVolume;
		Vec2 mPlane;

		KDNode* mChildLeft{ nullptr };
		KDNode* mChildRight{ nullptr };

		unsigned mLevel{ 0 };
		std::vector<unsigned> mDataIndices;
	};

	struct KDEvent
	{
		bool operator< (const KDEvent& rhs) const;

		unsigned mIndex;
		unsigned mDIndex;
		float mPosition;
	};

	struct NodeToRender
	{
		NodeToRender(const AABB& aabb, const unsigned& level) : mBoundingVolume(aabb), mLevel(level) {}
		AABB mBoundingVolume;
		unsigned mLevel;
	};

	void InternalBuild(const std::vector<unsigned>& triangles, KDNode* node);
	Vec2 GetSplittingPlane(const std::vector<unsigned>& triangles, KDNode* node);
	void GenerateEventList(const std::vector<unsigned>& triangles, unsigned axis, std::vector<KDEvent>& evlist, const AABB& aabb);
	void DeleteNode(KDNode* node);
	void GetNearDataNode(const Vec3& pos, KDNode* node, std::vector<KDTData>& vec);

	Stats mStats;
	std::mutex mMutex;

	unsigned mMaxLevel;
	unsigned mTreeLevel;

	float mIntersectionCost{ 0.1f };
	float mTraverseCost{ 1.f };
	float mMaxRadius{ 1.f };
	float mMaxRadiusSQ{ 1.f };
	bool mAbleToRender{ false };

	KDNode* mRoot{ nullptr };
	std::vector<KDEvent> mCurrEventList;
	std::vector<NodeToRender> mNodesToRender;

	std::vector<KDTData> mData;
};

#include "PointKDTree.inl"