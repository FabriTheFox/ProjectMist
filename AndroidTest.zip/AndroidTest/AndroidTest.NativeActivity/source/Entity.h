#pragma once

#include "DataTypes.h"
#include "Transform.h"
#include <map>
#include <string>
#include "RTTI.h"

class Component;
class EntitySpace;

class Entity : 
	public Base,
	public std::enable_shared_from_this<Entity>
{
	RTTI_DECLARATION(Entity)

	friend class EntitySpace;

public:

	static SHD_PTR<Entity> Create(const std::string& name = "Entity", const std::string& space = "");
	static SHD_PTR<Base> CreateB();

	Entity(const std::string& name = "Entity");

	void Destroy();

	void SetName(const std::string& name);
	const std::string& GetName();

	void SetSpace(const std::string& space);
	const std::string& GetSpace();

	void AddComponent(SHD_PTR<Component> comp);
	void RemoveAllComponents();

	template <typename T>
	void RemoveComponent()
	{
		auto itr = mComponentMap.find(T::ClassType_.mType);
		if (itr == mComponentMap.end())
		{
			PRINT_WARNING << "Component not found" << std::endl;
			return;
		}
		mComponentMap.erase(itr);
	}

	template <typename T>
	SHD_PTR<T> GetComponent()
	{
		auto itr = mComponentMap.find(T::RTTI_.mTypehash);
		if (itr == mComponentMap.end())
			return nullptr;
		return SHD_CAST(T)(itr->second);
	}

	SHD_PTR<Base> GetComponent(const size_t type);

	std::map<size_t, SHD_PTR<Component>>& GetComponents() { return mComponentMap; }

	Transform& GetTransform();

	void Load(SerDataPack& data) override;

private:
	std::string mName;
	std::string mSpace;
	std::map<size_t, SHD_PTR<Component>> mComponentMap;

protected:
	Transform mTransform;
};