#include "Shader.h"
#include <fstream>
#include "../glm/gtc/type_ptr.hpp"

Shader::~Shader()
{
	Free();
}

void Shader::Free()
{
	glDeleteProgram(mProgram);
}

void Shader::Bind()
{
	glUseProgram(mProgram);
}

void Shader::Unbind()
{
	glUseProgram(0);
}

const int& Shader::GetProgram()
{
	return mProgram;
}

int Shader::GetUniformLocation(const std::string& name)
{
	auto itr = mUniformLocations.find(name);
	if (itr == mUniformLocations.end())
	{
        int loc = glGetUniformLocation(GetProgram(), name.c_str());
		mUniformLocations[name] = loc;
		return loc;
	}
	return itr->second;
}

std::string Shader::LoadShader(const std::string& path)
{
    std::string Shader;
    std::string Line;
    std::ifstream myfile(path);

    if (myfile.is_open())
    {
        while (getline(myfile, Line))
            Shader += (Line + '\n');
        myfile.close();
    }
    return Shader;
}

void Shader::CreateProgram(const std::string vtxshpath, const std::string frgshpath, const std::string geomshpath)
{
	GLuint program = glCreateProgram();

    GLint VertexSh_ = CreateShader(GL_VERTEX_SHADER, vtxshpath);
    GLint FragmentSh_ = CreateShader(GL_FRAGMENT_SHADER, frgshpath);
	GLint GeometrySh_ = -1;

	glAttachShader(program, VertexSh_);
	glAttachShader(program, FragmentSh_);

	if (geomshpath != "")
	{
        GeometrySh_ = CreateShader(GL_GEOMETRY_SHADER, geomshpath);
		glAttachShader(program, GeometrySh_);
	}

	glLinkProgram(program);

	GLint status;
	glGetProgramiv(program, GL_LINK_STATUS, &status);

	if (status == GL_FALSE)
	{
		GLint infoLogLength;
		glGetProgramiv(program, GL_INFO_LOG_LENGTH, &infoLogLength);

		char *strInfoLog = new char[infoLogLength + 1];
		glGetProgramInfoLog(program, infoLogLength, NULL, strInfoLog);
		//PRINT_ERROR << "Shader Linker failure : " << strInfoLog << std::endl;
		delete[] strInfoLog;
	}

	if (geomshpath != "")
		glDetachShader(program, GeometrySh_);
	glDetachShader(program, VertexSh_);
	glDetachShader(program, FragmentSh_);

	if (geomshpath != "")
		glDeleteShader(GeometrySh_);
	glDeleteShader(VertexSh_);
	glDeleteShader(FragmentSh_);

	mProgram = program;
}

int Shader::CreateShader(unsigned int shadertype, const std::string &path)
{
	GLuint shader = glCreateShader(shadertype);
	const char *strFileData = path.c_str();
	glShaderSource(shader, 1, &strFileData, NULL);

	glCompileShader(shader);

	GLint status;
	glGetShaderiv(shader, GL_COMPILE_STATUS, &status);

	if (status == GL_FALSE)
	{
		GLint infoLogLength;
		glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &infoLogLength);

		GLchar *strInfoLog = new GLchar[infoLogLength + 1];
		glGetShaderInfoLog(shader, infoLogLength, NULL, strInfoLog);

		//PRINT_ERROR << "Shader compile failure : " << strInfoLog << std::endl;
		delete[] strInfoLog;
	}

	return shader;
}

void Shader::SetUniformfloat(const std::string& name, float data)
{
	Bind();
	glUniform1f(GetUniformLocation(name), data);
}

void Shader::SetUniformfloatVec(const std::string& name, float* data, unsigned count)
{
	Bind();
	glUniform1fv(GetUniformLocation(name), count,  data);
}

void Shader::SetUniformInt(const std::string& name, int data)
{
	Bind();
	glUniform1i(GetUniformLocation(name), data);
}

void Shader::SetUniformIntVec(const std::string& name, int* data, unsigned count)
{
	Bind();
	glUniform1iv(GetUniformLocation(name), count, data);
}

void Shader::SetUniformVec2(const std::string& name, const Vec2& data)
{
	Bind();
	glUniform2f(GetUniformLocation(name), data.x, data.y);
}

void Shader::SetUniformVec2Vec(const std::string& name, Vec2* data, unsigned count)
{
	Bind();
	glUniform2fv(GetUniformLocation(name), count, glm::value_ptr(*data));
}

void Shader::SetUniformVec3(const std::string& name, const Vec3& data)
{
	Bind();
	glUniform3f(GetUniformLocation(name), data.x, data.y, data.z);
}

void Shader::SetUniformVec3Vec(const std::string& name, Vec3* data, unsigned count)
{
	Bind();
	glUniform3fv(GetUniformLocation(name), count, glm::value_ptr(*data));
}

void Shader::SetUniformVec4(const std::string& name, const Vec4& data)
{
	Bind();
	glUniform4f(GetUniformLocation(name), data.x, data.y, data.z, data.w);
}

void Shader::SetUniformVec4Vec(const std::string& name, Vec4* data, unsigned count)
{
	Bind();
	glUniform3fv(GetUniformLocation(name), count, glm::value_ptr(*data));
}

void Shader::SetUniformMat4(const std::string& name, const Mat4& data)
{
	Bind();
	glUniformMatrix4fv(GetUniformLocation(name), 1, GL_FALSE, glm::value_ptr(data));
}

void Shader::SetUniformMat4Vec(const std::string& name, Mat4* data, unsigned count)
{
	Bind();
	glUniformMatrix4fv(GetUniformLocation(name), count, GL_FALSE, glm::value_ptr(*data));
}